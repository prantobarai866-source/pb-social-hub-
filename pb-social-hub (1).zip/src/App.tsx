/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Navbar } from './components/Navbar';
import { SidebarLeft } from './components/SidebarLeft';
import { SidebarRight } from './components/SidebarRight';
import { StoriesSection } from './components/StoriesSection';
import { CreatePostBox } from './components/CreatePostBox';
import { ReelsShelf } from './components/ReelsShelf';
import { MobileBottomNav } from './components/MobileBottomNav';
import { PostCard } from './components/PostCard';
import { SkeletonFeed } from './components/SkeletonFeed';
import { ReelsView } from './components/ReelsView';
import { GamingView } from './components/GamingView';
import { GroupsView } from './components/GroupsView';
import { ProfileView } from './components/ProfileView';
import { FriendsView } from './components/FriendsView';
import { CallOverlayModal } from './components/CallOverlayModal';
import { MessengerDock } from './components/MessengerDock';
import { GoogleAuthModal, GoogleLogo } from './components/GoogleAuthModal';
import { SettingsModal } from './components/SettingsModal';
import { CreateReelModal } from './components/CreateReelModal';
import { ErrorBoundary } from './components/ErrorBoundary';
import { motion, AnimatePresence } from 'motion/react';
import {
  RefreshCw,
  Sparkles,
  AlertCircle,
  X,
  Layers,
  Image as ImageIcon,
  Video,
  FileText,
  BarChart2,
} from 'lucide-react';

const MainLayout: React.FC = () => {
  const {
    activeTab,
    setActiveTab,
    selectedUserId,
    setSelectedUserId,
    posts,
    language,
    isLoggedIn,
    currentUser,
    setIsGoogleAuthModalOpen,
  } = useApp();

  const [searchQuery, setSearchQuery] = useState('');
  const [isLoadingFeed, setIsLoadingFeed] = useState(true);
  const [dismissOneTap, setDismissOneTap] = useState(false);
  const [postFilter, setPostFilter] = useState<'all' | 'photo' | 'video' | 'text' | 'poll'>('all');

  // Perceived performance: skeleton screen loader on initial mount or feed refresh
  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoadingFeed(false);
    }, 700);
    return () => clearTimeout(timer);
  }, []);

  const handleRefreshFeed = () => {
    setIsLoadingFeed(true);
    setTimeout(() => setIsLoadingFeed(false), 500);
  };

  // Filter posts if searching or filtering by media type
  const filteredPosts = posts.filter((post) => {
    // Post type filter
    if (postFilter === 'photo' && !(post.mediaType === 'image' && post.mediaUrl)) return false;
    if (postFilter === 'video' && !(post.mediaType === 'video' && post.mediaUrl)) return false;
    if (postFilter === 'text' && (post.mediaUrl || post.poll)) return false;
    if (postFilter === 'poll' && !post.poll) return false;

    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase();
    return (
      post.content.toLowerCase().includes(q) ||
      post.userName.toLowerCase().includes(q) ||
      (post.groupName && post.groupName.toLowerCase().includes(q))
    );
  });

  return (
    <div className="min-h-screen bg-slate-100 dark:bg-slate-950 text-slate-900 dark:text-slate-100 transition-colors flex flex-col font-sans">
      {/* Top Navbar */}
      <Navbar searchQuery={searchQuery} onSearchChange={setSearchQuery} />

      {/* Main Content Area */}
      <div className="flex-1 flex justify-center w-full max-w-[1600px] mx-auto">
        {/* Left Sidebar */}
        <SidebarLeft />

        {/* Center Dynamic Area with Framer-motion transitions */}
        <main className="flex-1 max-w-2xl px-2 sm:px-4 py-4 min-w-0">
          <AnimatePresence mode="wait">
            {activeTab === 'feed' && (
              <motion.div
                key="feed"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.2 }}
                className="space-y-4"
              >
                {/* Stories Bar */}
                <StoriesSection />

                {/* Create Post Card */}
                <CreatePostBox />

                {/* Reels Watch Shelf on Feed */}
                <ReelsShelf />

                {/* Post Category Filter Bar (All / Photo / Video / Text / Poll) */}
                <div className="flex items-center space-x-1.5 overflow-x-auto pb-1 scrollbar-none">
                  <button
                    onClick={() => setPostFilter('all')}
                    className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition-colors ${
                      postFilter === 'all'
                        ? 'bg-blue-600 text-white shadow-xs'
                        : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-800'
                    }`}
                  >
                    <Layers className="w-3.5 h-3.5" />
                    <span>{language === 'bn' ? 'সব পোস্ট' : 'All Posts'}</span>
                    <span className="text-[10px] opacity-80">({posts.length})</span>
                  </button>

                  <button
                    onClick={() => setPostFilter('photo')}
                    className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition-colors ${
                      postFilter === 'photo'
                        ? 'bg-blue-600 text-white shadow-xs'
                        : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-800'
                    }`}
                  >
                    <ImageIcon className="w-3.5 h-3.5 text-blue-500" />
                    <span>{language === 'bn' ? 'ছবি' : 'Photos'}</span>
                    <span className="text-[10px] opacity-80">
                      ({posts.filter((p) => p.mediaType === 'image' && p.mediaUrl).length})
                    </span>
                  </button>

                  <button
                    onClick={() => setPostFilter('video')}
                    className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition-colors ${
                      postFilter === 'video'
                        ? 'bg-purple-600 text-white shadow-xs'
                        : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-800'
                    }`}
                  >
                    <Video className="w-3.5 h-3.5 text-purple-500" />
                    <span>{language === 'bn' ? 'ভিডিও' : 'Videos'}</span>
                    <span className="text-[10px] opacity-80">
                      ({posts.filter((p) => p.mediaType === 'video' && p.mediaUrl).length})
                    </span>
                  </button>

                  <button
                    onClick={() => setPostFilter('text')}
                    className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition-colors ${
                      postFilter === 'text'
                        ? 'bg-emerald-600 text-white shadow-xs'
                        : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-800'
                    }`}
                  >
                    <FileText className="w-3.5 h-3.5 text-emerald-500" />
                    <span>{language === 'bn' ? 'টেক্সট স্ট্যাটাস' : 'Status'}</span>
                    <span className="text-[10px] opacity-80">
                      ({posts.filter((p) => !p.mediaUrl && !p.poll).length})
                    </span>
                  </button>

                  <button
                    onClick={() => setPostFilter('poll')}
                    className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition-colors ${
                      postFilter === 'poll'
                        ? 'bg-amber-600 text-white shadow-xs'
                        : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-800'
                    }`}
                  >
                    <BarChart2 className="w-3.5 h-3.5 text-amber-500" />
                    <span>{language === 'bn' ? 'পোল' : 'Polls'}</span>
                    <span className="text-[10px] opacity-80">
                      ({posts.filter((p) => !!p.poll).length})
                    </span>
                  </button>
                </div>

                {/* Feed Header with Refresh Indicator */}
                <div className="flex items-center justify-between px-2 py-1 text-xs text-slate-500 dark:text-slate-400">
                  <span className="font-semibold uppercase tracking-wider">
                    {language === 'bn' ? 'ফিড ও সাম্প্রতিক পোস্ট' : 'Latest Feed Updates'}
                  </span>
                  <button
                    onClick={handleRefreshFeed}
                    className="flex items-center space-x-1 hover:text-blue-600 transition-colors"
                    title="Refresh feed"
                  >
                    <RefreshCw className={`w-3.5 h-3.5 ${isLoadingFeed ? 'animate-spin text-blue-600' : ''}`} />
                    <span>{language === 'bn' ? 'রিফ্রেশ' : 'Refresh'}</span>
                  </button>
                </div>

                {/* Skeleton Screen Loader or Post Feed */}
                {isLoadingFeed ? (
                  <SkeletonFeed />
                ) : filteredPosts.length === 0 ? (
                  <div className="bg-white dark:bg-slate-900 rounded-2xl p-12 text-center border border-slate-200 dark:border-slate-800 shadow-sm space-y-3">
                    <AlertCircle className="w-10 h-10 mx-auto text-slate-400" />
                    <h3 className="font-bold text-sm text-slate-700 dark:text-slate-200">
                      {language === 'bn' ? 'কোনো পোস্ট পাওয়া যায়নি' : 'No posts found'}
                    </h3>
                    <p className="text-xs text-slate-400 max-w-xs mx-auto">
                      {searchQuery
                        ? 'Try searching with different keywords.'
                        : 'Your feed is clear. Share an update or snapshot with your friends!'}
                    </p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {filteredPosts.map((post) => (
                      <PostCard
                        key={post.id}
                        post={post}
                        onViewProfile={(uid) => {
                          setSelectedUserId(uid);
                          setActiveTab('profile');
                        }}
                      />
                    ))}
                  </div>
                )}
              </motion.div>
            )}

            {activeTab === 'reels' && (
              <motion.div
                key="reels"
                initial={{ opacity: 0, scale: 0.98 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.98 }}
                transition={{ duration: 0.2 }}
              >
                <ReelsView />
              </motion.div>
            )}

            {activeTab === 'groups' && (
              <motion.div
                key="groups"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.2 }}
              >
                <GroupsView />
              </motion.div>
            )}

            {activeTab === 'gaming' && (
              <motion.div
                key="gaming"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.2 }}
              >
                <GamingView />
              </motion.div>
            )}

            {activeTab === 'friends' && (
              <motion.div
                key="friends"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.2 }}
              >
                <FriendsView />
              </motion.div>
            )}

            {activeTab === 'profile' && (
              <motion.div
                key="profile"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.2 }}
              >
                <ProfileView userId={selectedUserId || undefined} />
              </motion.div>
            )}
          </AnimatePresence>
        </main>

        {/* Right Sidebar */}
        <SidebarRight />
      </div>

      {/* Floating Messenger Dock */}
      <MessengerDock />

      {/* Interactive Audio/Video Call Overlay */}
      <CallOverlayModal />

      {/* Google Authentication Dialog */}
      <GoogleAuthModal />

      {/* Platform Settings Modal */}
      <SettingsModal />

      {/* Create & Release Reel Modal */}
      <CreateReelModal />

      {/* Mobile Bottom Navigation Bar (Watch Reels, Feed, Create, Friends, Games) */}
      <MobileBottomNav />

      {/* Google One Tap Sign-In Widget (when logged out or on demand) */}
      {!isLoggedIn && !dismissOneTap && (
        <div className="fixed top-20 right-4 sm:right-6 z-45 max-w-xs w-full bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 p-4 animate-in slide-in-from-top-4 duration-300">
          <div className="flex items-start justify-between">
            <div className="flex items-center space-x-2">
              <GoogleLogo className="w-5 h-5" />
              <span className="text-xs font-bold text-slate-800 dark:text-white">
                Sign in with Google
              </span>
            </div>
            <button
              onClick={() => setDismissOneTap(true)}
              className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-2">
            Continue to BondhuNet as <span className="font-semibold">{currentUser?.name || 'User'}</span>
          </p>

          <button
            onClick={() => setIsGoogleAuthModalOpen(true)}
            className="w-full mt-3 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-semibold shadow-xs transition-colors flex items-center justify-center space-x-2"
          >
            <span>Continue with Google</span>
          </button>
        </div>
      )}
    </div>
  );
};

export default function App() {
  return (
    <ErrorBoundary>
      <AppProvider>
        <MainLayout />
      </AppProvider>
    </ErrorBoundary>
  );
}
