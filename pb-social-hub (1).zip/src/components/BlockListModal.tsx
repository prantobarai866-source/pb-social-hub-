import React from 'react';
import { useApp } from '../context/AppContext';
import { INITIAL_FRIENDS } from '../data/initialData';
import { X, UserX, Check, ShieldAlert } from 'lucide-react';

interface BlockListModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const BlockListModal: React.FC<BlockListModalProps> = ({ isOpen, onClose }) => {
  const { blockedUserIds, unblockUser, language } = useApp();

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4 animate-in fade-in duration-150">
      <div className="relative w-full max-w-md bg-white dark:bg-slate-900 rounded-3xl p-5 border border-slate-200 dark:border-slate-800 shadow-2xl space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 rounded-full bg-red-50 dark:bg-red-950/40 text-red-600 flex items-center justify-center">
              <UserX className="w-4 h-4" />
            </div>
            <h3 className="font-bold text-slate-900 dark:text-white text-base">
              {language === 'bn' ? 'ব্লক করা ব্যবহারকারীদের তালিকা' : 'Blocked Users'}
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-full text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {blockedUserIds.length === 0 ? (
          <div className="py-8 text-center text-slate-400 text-xs">
            <ShieldAlert className="w-8 h-8 mx-auto mb-2 opacity-40 text-slate-400" />
            <p>{language === 'bn' ? 'আপনি কাউকে ব্লক করেননি।' : 'You have not blocked any users.'}</p>
          </div>
        ) : (
          <div className="space-y-2 max-h-60 overflow-y-auto">
            {blockedUserIds.map((userId) => {
              const userObj = INITIAL_FRIENDS.find((f) => f.id === userId);
              return (
                <div
                  key={userId}
                  className="flex items-center justify-between p-3 bg-slate-50 dark:bg-slate-800/60 rounded-2xl"
                >
                  <div className="flex items-center space-x-2.5">
                    <img
                      src={userObj?.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100'}
                      alt={userObj?.name || 'Blocked user'}
                      className="w-8 h-8 rounded-full object-cover"
                    />
                    <div>
                      <p className="text-xs font-bold text-slate-900 dark:text-white">
                        {userObj?.name || userId}
                      </p>
                      <p className="text-[10px] text-slate-400">Blocked</p>
                    </div>
                  </div>

                  <button
                    onClick={() => unblockUser(userId)}
                    className="px-3 py-1 bg-slate-200 dark:bg-slate-700 hover:bg-slate-300 dark:hover:bg-slate-600 text-slate-800 dark:text-slate-200 text-xs font-semibold rounded-xl transition-colors"
                  >
                    Unblock
                  </button>
                </div>
              );
            })}
          </div>
        )}

        <div className="pt-2 text-right">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 text-xs font-semibold rounded-xl"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
