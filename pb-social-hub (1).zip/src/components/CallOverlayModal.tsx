import React, { useState, useEffect, useRef } from 'react';
import { useApp } from '../context/AppContext';
import {
  Mic,
  MicOff,
  Video as VideoIcon,
  VideoOff,
  PhoneOff,
  FlipHorizontal,
  Maximize2,
  Minimize2,
  Volume2,
  PhoneCall,
} from 'lucide-react';

export const CallOverlayModal: React.FC = () => {
  const { activeCall, endCall, toggleCallMute, toggleCallVideo } = useApp();
  const [callDuration, setCallDuration] = useState(0);
  const [localStream, setLocalStream] = useState<MediaStream | null>(null);
  const [facingMode, setFacingMode] = useState<'user' | 'environment'>('user');
  const [isFullscreen, setIsFullscreen] = useState(false);

  const localVideoRef = useRef<HTMLVideoElement | null>(null);

  // Call timer
  useEffect(() => {
    if (!activeCall) {
      setCallDuration(0);
      return;
    }

    const timer = setInterval(() => {
      setCallDuration((prev) => prev + 1);
    }, 1000);

    return () => clearInterval(timer);
  }, [activeCall]);

  // Request actual camera & audio for video calls
  useEffect(() => {
    let stream: MediaStream | null = null;

    const setupMedia = async () => {
      if (!activeCall || activeCall.type !== 'video') return;

      try {
        if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
          stream = await navigator.mediaDevices.getUserMedia({
            video: { facingMode: facingMode },
            audio: true,
          });
          setLocalStream(stream);
          if (localVideoRef.current) {
            localVideoRef.current.srcObject = stream;
          }
        }
      } catch (e) {
        console.warn('Could not acquire local camera for call:', e);
      }
    };

    setupMedia();

    return () => {
      if (stream) {
        stream.getTracks().forEach((track) => track.stop());
      }
    };
  }, [activeCall?.type, facingMode, activeCall?.active]);

  // Cleanup stream on endCall
  const handleEndCall = () => {
    if (localStream) {
      localStream.getTracks().forEach((t) => t.stop());
      setLocalStream(null);
    }
    endCall();
  };

  const handleToggleMute = () => {
    if (localStream) {
      localStream.getAudioTracks().forEach((t) => (t.enabled = !t.enabled));
    }
    toggleCallMute();
  };

  const handleToggleVideo = () => {
    if (localStream) {
      localStream.getVideoTracks().forEach((t) => (t.enabled = !t.enabled));
    }
    toggleCallVideo();
  };

  const formatDuration = (secs: number) => {
    const m = Math.floor(secs / 60)
      .toString()
      .padStart(2, '0');
    const s = (secs % 60).toString().padStart(2, '0');
    return `${m}:${s}`;
  };

  if (!activeCall || !activeCall.active) return null;

  return (
    <div
      className={`fixed z-50 transition-all duration-300 ${
        isFullscreen
          ? 'inset-0 bg-slate-950 flex items-center justify-center p-0'
          : 'bottom-6 right-6 w-96 max-w-[calc(100vw-2rem)] h-[520px] rounded-3xl overflow-hidden shadow-2xl border border-slate-800 bg-slate-950 flex flex-col justify-between animate-in fade-in slide-in-from-bottom-6'
      }`}
    >
      {/* Remote feed area */}
      <div className="relative flex-1 w-full h-full bg-slate-900 flex items-center justify-center overflow-hidden">
        {/* Remote Partner Video simulation / Avatar */}
        {activeCall.type === 'video' ? (
          <div className="relative w-full h-full">
            <img
              src={activeCall.partnerAvatar}
              alt={activeCall.partnerName}
              className="w-full h-full object-cover filter brightness-90"
            />
            <div className="absolute inset-0 bg-linear-to-t from-black/80 via-transparent to-black/60" />
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center space-y-4 p-8 text-center">
            <div className="relative">
              <img
                src={activeCall.partnerAvatar}
                alt={activeCall.partnerName}
                className="w-28 h-28 rounded-full object-cover ring-4 ring-blue-500 shadow-2xl animate-pulse"
              />
              <div className="absolute -bottom-1 -right-1 w-8 h-8 rounded-full bg-emerald-500 text-white flex items-center justify-center ring-2 ring-slate-900">
                <Volume2 className="w-4 h-4 animate-bounce" />
              </div>
            </div>

            <div>
              <h3 className="text-white font-bold text-lg">{activeCall.partnerName}</h3>
              <p className="text-emerald-400 text-xs font-semibold mt-1">
                Audio Call Connected · {formatDuration(callDuration)}
              </p>
            </div>
          </div>
        )}

        {/* Local Camera stream picture-in-picture (for video calls) */}
        {activeCall.type === 'video' && (
          <div className="absolute top-4 right-4 w-28 h-40 bg-black rounded-2xl overflow-hidden border-2 border-white/20 shadow-xl z-20">
            {activeCall.isVideoOff ? (
              <div className="w-full h-full bg-slate-800 flex items-center justify-center text-white/50 text-[10px]">
                Camera Off
              </div>
            ) : (
              <video
                ref={localVideoRef}
                autoPlay
                playsInline
                muted
                className="w-full h-full object-cover scale-x-[-1]"
              />
            )}
          </div>
        )}

        {/* Top Floating Status bar */}
        <div className="absolute top-4 left-4 z-20 flex items-center space-x-2">
          <div className="bg-black/60 backdrop-blur-md px-3 py-1.5 rounded-full border border-white/10 flex items-center space-x-2 text-white">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
            <span className="text-xs font-semibold">{formatDuration(callDuration)}</span>
          </div>

          <button
            onClick={() => setIsFullscreen(!isFullscreen)}
            className="p-1.5 rounded-full bg-black/60 hover:bg-black/80 backdrop-blur-md text-white border border-white/10"
            title={isFullscreen ? 'Exit Fullscreen' : 'Fullscreen'}
          >
            {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
          </button>
        </div>

        {/* Partner Info for Video Call */}
        {activeCall.type === 'video' && (
          <div className="absolute bottom-24 left-4 z-20 text-white drop-shadow-md">
            <h4 className="font-bold text-base">{activeCall.partnerName}</h4>
            <p className="text-xs text-white/80">HD Video · Encrypted</p>
          </div>
        )}
      </div>

      {/* Floating Call Action Controls Bar */}
      <div className="p-4 bg-slate-900/90 backdrop-blur-md border-t border-slate-800 flex items-center justify-center space-x-4">
        {/* Toggle Mute Mic */}
        <button
          onClick={handleToggleMute}
          className={`p-3.5 rounded-full backdrop-blur-md transition-colors ${
            activeCall.isMuted
              ? 'bg-red-500 text-white'
              : 'bg-white/15 hover:bg-white/25 text-white'
          }`}
          title={activeCall.isMuted ? 'Unmute microphone' : 'Mute microphone'}
        >
          {activeCall.isMuted ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
        </button>

        {/* Toggle Video Camera */}
        {activeCall.type === 'video' && (
          <button
            onClick={handleToggleVideo}
            className={`p-3.5 rounded-full backdrop-blur-md transition-colors ${
              activeCall.isVideoOff
                ? 'bg-red-500 text-white'
                : 'bg-white/15 hover:bg-white/25 text-white'
            }`}
            title={activeCall.isVideoOff ? 'Turn video on' : 'Turn video off'}
          >
            {activeCall.isVideoOff ? (
              <VideoOff className="w-5 h-5" />
            ) : (
              <VideoIcon className="w-5 h-5" />
            )}
          </button>
        )}

        {/* Flip camera */}
        {activeCall.type === 'video' && (
          <button
            onClick={() => setFacingMode((prev) => (prev === 'user' ? 'environment' : 'user'))}
            className="p-3.5 rounded-full bg-white/15 hover:bg-white/25 text-white transition-colors"
            title="Flip camera"
          >
            <FlipHorizontal className="w-5 h-5" />
          </button>
        )}

        {/* End Call Button */}
        <button
          onClick={handleEndCall}
          className="p-3.5 rounded-full bg-red-600 hover:bg-red-700 text-white shadow-lg transition-transform active:scale-95"
          title="End Call"
        >
          <PhoneOff className="w-5 h-5" />
        </button>
      </div>
    </div>
  );
};
