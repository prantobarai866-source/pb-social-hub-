import React, { useState, useRef } from 'react';
import { useApp } from '../context/AppContext';
import { CameraCaptureModal } from './CameraCaptureModal';
import { EmojiPicker } from './EmojiPicker';
import {
  Camera,
  Image as ImageIcon,
  Smile,
  X,
  Sparkles,
  Send,
  BarChart2,
  Clock,
  Plus,
  Trash2,
  Calendar,
  CheckCircle,
  Film,
  Palette,
  Video as VideoIcon,
} from 'lucide-react';

const GRADIENT_PRESETS = [
  { id: 'grad_none', label: 'Plain', class: '' },
  { id: 'grad_sunset', label: 'Sunset', class: 'bg-gradient-to-tr from-pink-500 via-rose-500 to-amber-500 text-white' },
  { id: 'grad_ocean', label: 'Ocean', class: 'bg-gradient-to-tr from-blue-600 via-indigo-600 to-cyan-500 text-white' },
  { id: 'grad_emerald', label: 'Emerald', class: 'bg-gradient-to-tr from-emerald-600 via-teal-600 to-green-500 text-white' },
  { id: 'grad_purple', label: 'Purple', class: 'bg-gradient-to-tr from-purple-700 via-fuchsia-600 to-pink-600 text-white' },
  { id: 'grad_dark', label: 'Midnight', class: 'bg-gradient-to-tr from-slate-900 via-purple-950 to-slate-900 text-white' },
];

interface CreatePostBoxProps {
  groupId?: string;
  placeholder?: string;
}

export const CreatePostBox: React.FC<CreatePostBoxProps> = ({ groupId, placeholder }) => {
  const { currentUser, addPost, language, setIsCreateReelModalOpen } = useApp();
  const [content, setContent] = useState('');
  const [mediaUrl, setMediaUrl] = useState<string | undefined>(undefined);
  const [mediaType, setMediaType] = useState<'image' | 'video' | undefined>(undefined);
  const [isCameraOpen, setIsCameraOpen] = useState(false);
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const [feeling, setFeeling] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [bgGradient, setBgGradient] = useState<string | undefined>(undefined);
  const [showColorPalette, setShowColorPalette] = useState(false);

  // Poll Creation state
  const [isCreatingPoll, setIsCreatingPoll] = useState(false);
  const [pollQuestion, setPollQuestion] = useState('');
  const [pollOptions, setPollOptions] = useState<string[]>(['', '']);

  // Schedule Post state
  const [isScheduling, setIsScheduling] = useState(false);
  const [scheduledDateTime, setScheduledDateTime] = useState<string>('');

  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const isVideo = file.type.startsWith('video/');
    const reader = new FileReader();
    reader.onloadend = () => {
      setMediaUrl(reader.result as string);
      setMediaType(isVideo ? 'video' : 'image');
    };
    reader.readAsDataURL(file);
  };

  const handleCameraCapture = (dataUrl: string) => {
    setMediaUrl(dataUrl);
    setMediaType('image');
  };

  const handleEmojiSelect = (emoji: string) => {
    setContent((prev) => prev + emoji);
  };

  // Poll handlers
  const handleAddPollOption = () => {
    if (pollOptions.length < 5) {
      setPollOptions((prev) => [...prev, '']);
    }
  };

  const handleRemovePollOption = (index: number) => {
    if (pollOptions.length > 2) {
      setPollOptions((prev) => prev.filter((_, i) => i !== index));
    }
  };

  const handlePollOptionChange = (index: number, val: string) => {
    setPollOptions((prev) => {
      const updated = [...prev];
      updated[index] = val;
      return updated;
    });
  };

  const handleResetPoll = () => {
    setIsCreatingPoll(false);
    setPollQuestion('');
    setPollOptions(['', '']);
  };

  // Quick schedule presets
  const handleQuickSchedule = (hoursAhead: number) => {
    const target = new Date(Date.now() + hoursAhead * 60 * 60 * 1000);
    const localIso = new Date(target.getTime() - target.getTimezoneOffset() * 60000)
      .toISOString()
      .slice(0, 16);
    setScheduledDateTime(localIso);
  };

  const hasValidPoll =
    isCreatingPoll &&
    pollQuestion.trim().length > 0 &&
    pollOptions.filter((o) => o.trim().length > 0).length >= 2;

  const canSubmit =
    (!isSubmitting &&
      (content.trim().length > 0 ||
        !!mediaUrl ||
        hasValidPoll));

  const handleSubmit = () => {
    if (!canSubmit) return;

    setIsSubmitting(true);
    let finalContent = content.trim();
    if (feeling) {
      finalContent = `${feeling}\n\n${finalContent}`;
    }

    // Prepare poll data if enabled
    const pollData = hasValidPoll
      ? {
          question: pollQuestion.trim(),
          options: pollOptions.filter((o) => o.trim().length > 0),
        }
      : undefined;

    addPost(
      finalContent,
      mediaUrl,
      mediaType,
      groupId,
      pollData,
      scheduledDateTime ? new Date(scheduledDateTime).toISOString() : undefined,
      bgGradient
    );

    // Reset state
    setContent('');
    setMediaUrl(undefined);
    setMediaType(undefined);
    setBgGradient(undefined);
    setShowColorPalette(false);
    setFeeling(null);
    setShowEmojiPicker(false);
    handleResetPoll();
    setScheduledDateTime('');
    setIsScheduling(false);
    setIsSubmitting(false);
  };

  const userFirstName = (currentUser?.name || 'User').split(' ')[0];
  const defaultPlaceholder =
    language === 'bn'
      ? `কী ভাবছেন, ${userFirstName}?`
      : `What's on your mind, ${userFirstName}?`;

  // Minimum schedule time (5 minutes from now)
  const minDateTime = new Date(Date.now() + 5 * 60 * 1000 - new Date().getTimezoneOffset() * 60000)
    .toISOString()
    .slice(0, 16);

  return (
    <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-sm border border-slate-200 dark:border-slate-800 p-4 mb-4 transition-all">
      {/* Top row: Avatar + Input */}
      <div className="flex items-start space-x-3">
        <img
          src={currentUser.avatar}
          alt={currentUser.name}
          className="w-10 h-10 rounded-full object-cover ring-2 ring-slate-100 dark:ring-slate-800 flex-shrink-0"
        />

        <div className="flex-1 min-w-0">
          {bgGradient ? (
            <div className={`w-full ${bgGradient} rounded-2xl p-5 min-h-[130px] flex items-center justify-center transition-all shadow-inner relative`}>
              <textarea
                value={content}
                onChange={(e) => setContent(e.target.value)}
                placeholder={
                  language === 'bn' ? 'এখানে আপনার কথা লিখুন...' : 'Write what is on your mind...'
                }
                rows={3}
                className="w-full bg-transparent text-white placeholder-white/70 text-center font-bold text-sm sm:text-base resize-none border-none outline-none leading-relaxed"
              />
              <button
                onClick={() => setBgGradient(undefined)}
                className="absolute top-2 right-2 p-1 rounded-full bg-black/30 hover:bg-black/50 text-white"
                title="Remove background"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          ) : (
            <textarea
              value={content}
              onChange={(e) => setContent(e.target.value)}
              placeholder={placeholder || defaultPlaceholder}
              rows={content.length > 80 ? 3 : 2}
              className="w-full bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-white placeholder-slate-400 dark:placeholder-slate-500 rounded-2xl px-4 py-2.5 text-sm resize-none focus:outline-none focus:ring-2 focus:ring-blue-500 border-none transition-all"
            />
          )}

          {/* Color Gradient Swatches Bar */}
          {showColorPalette && (
            <div className="flex items-center space-x-2 mt-2 p-2 bg-slate-100 dark:bg-slate-800/80 rounded-xl flex-wrap gap-y-1 animate-in fade-in duration-150">
              <span className="text-[11px] font-semibold text-slate-500 dark:text-slate-400 mr-1">
                {language === 'bn' ? 'রঙিন স্ট্যাটাস:' : 'Color Theme:'}
              </span>
              {GRADIENT_PRESETS.map((p) => (
                <button
                  key={p.id}
                  onClick={() => {
                    setBgGradient(p.class || undefined);
                    if (p.class) {
                      setMediaUrl(undefined);
                      setMediaType(undefined);
                    }
                  }}
                  className={`w-5 h-5 rounded-full transition-transform active:scale-90 ${
                    p.class ? p.class.split(' ')[0] : 'bg-slate-300 dark:bg-slate-600'
                  } ${
                    (!bgGradient && !p.class) || bgGradient === p.class
                      ? 'ring-2 ring-blue-500 scale-110'
                      : 'border border-white dark:border-slate-800'
                  }`}
                  title={p.label}
                />
              ))}
            </div>
          )}

          {/* Quick Suggestions for Photo, Video, and Gradient Text */}
          {!mediaUrl && !bgGradient && (
            <div className="flex items-center space-x-2 mt-2 pt-2 border-t border-dashed border-slate-100 dark:border-slate-800 text-[11px] text-slate-500 flex-wrap gap-y-1">
              <span className="font-semibold text-slate-600 dark:text-slate-400">
                {language === 'bn' ? 'নমুনা যুক্ত করুন:' : 'Sample:'}
              </span>
              <button
                type="button"
                onClick={() => {
                  setMediaUrl('https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=1200&auto=format&fit=crop&q=80');
                  setMediaType('image');
                  setBgGradient(undefined);
                }}
                className="px-2 py-0.5 rounded-lg bg-blue-50 dark:bg-blue-950/40 text-blue-600 dark:text-blue-400 hover:bg-blue-100 font-medium transition-colors"
              >
                📸 {language === 'bn' ? 'ছবি' : 'Photo'}
              </button>
              <button
                type="button"
                onClick={() => {
                  setMediaUrl('https://assets.mixkit.co/videos/preview/mixkit-waves-in-the-water-1164-large.mp4');
                  setMediaType('video');
                  setBgGradient(undefined);
                }}
                className="px-2 py-0.5 rounded-lg bg-purple-50 dark:bg-purple-950/40 text-purple-600 dark:text-purple-400 hover:bg-purple-100 font-medium transition-colors"
              >
                🎥 {language === 'bn' ? 'ভিডিও' : 'Video'}
              </button>
              <button
                type="button"
                onClick={() => {
                  setBgGradient('bg-gradient-to-tr from-pink-500 via-rose-500 to-amber-500 text-white');
                  setShowColorPalette(true);
                  setMediaUrl(undefined);
                  setMediaType(undefined);
                }}
                className="px-2 py-0.5 rounded-lg bg-amber-50 dark:bg-amber-950/40 text-amber-700 dark:text-amber-400 hover:bg-amber-100 font-medium transition-colors"
              >
                🎨 {language === 'bn' ? 'রঙিন লেখা' : 'Gradient'}
              </button>
            </div>
          )}

          {feeling && (
            <div className="inline-flex items-center space-x-1.5 px-3 py-1 bg-amber-50 dark:bg-amber-950/40 text-amber-700 dark:text-amber-300 rounded-full text-xs font-medium mt-2">
              <span>{feeling}</span>
              <button onClick={() => setFeeling(null)} className="hover:opacity-75">
                <X className="w-3 h-3" />
              </button>
            </div>
          )}

          {/* Media Preview if attached */}
          {mediaUrl && (
            <div className="relative mt-3 rounded-xl overflow-hidden border border-slate-200 dark:border-slate-700 bg-black/5 max-h-80">
              {mediaType === 'video' ? (
                <video src={mediaUrl} controls className="w-full max-h-80 object-contain rounded-xl" />
              ) : (
                <img src={mediaUrl} alt="Upload preview" className="w-full max-h-80 object-cover rounded-xl" />
              )}
              <button
                onClick={() => {
                  setMediaUrl(undefined);
                  setMediaType(undefined);
                }}
                className="absolute top-2 right-2 p-1.5 bg-black/70 hover:bg-black/90 text-white rounded-full transition-transform active:scale-95 shadow-md"
                title="Remove media"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          )}

          {/* Interactive Poll Builder Box */}
          {isCreatingPoll && (
            <div className="mt-3 p-3.5 bg-blue-50/50 dark:bg-slate-800/80 rounded-xl border border-blue-200 dark:border-blue-900/50 space-y-3 animate-in fade-in duration-150">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2 text-xs font-bold text-blue-700 dark:text-blue-300">
                  <BarChart2 className="w-4 h-4" />
                  <span>{language === 'bn' ? 'পোল তৈরি করুন' : 'Create a Poll'}</span>
                </div>
                <button
                  onClick={handleResetPoll}
                  className="p-1 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-lg hover:bg-slate-200/50 dark:hover:bg-slate-700 transition-colors"
                  title="Remove Poll"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Poll Question Input */}
              <input
                type="text"
                value={pollQuestion}
                onChange={(e) => setPollQuestion(e.target.value)}
                placeholder={language === 'bn' ? 'আপনার প্রশ্ন লিখুন...' : 'Ask a question...'}
                className="w-full bg-white dark:bg-slate-900 text-slate-900 dark:text-white placeholder-slate-400 rounded-lg px-3 py-2 text-xs font-medium border border-slate-200 dark:border-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
              />

              {/* Multiple Choice Options List */}
              <div className="space-y-2">
                {pollOptions.map((opt, idx) => (
                  <div key={idx} className="flex items-center space-x-2">
                    <span className="w-5 text-center text-xs text-slate-400 font-semibold">
                      {idx + 1}.
                    </span>
                    <input
                      type="text"
                      value={opt}
                      onChange={(e) => handlePollOptionChange(idx, e.target.value)}
                      placeholder={
                        language === 'bn' ? `অপশন ${idx + 1}` : `Option ${idx + 1}`
                      }
                      className="flex-1 bg-white dark:bg-slate-900 text-slate-900 dark:text-white placeholder-slate-400 rounded-lg px-3 py-1.5 text-xs border border-slate-200 dark:border-slate-700 focus:outline-none focus:ring-1 focus:ring-blue-500"
                    />
                    {pollOptions.length > 2 && (
                      <button
                        onClick={() => handleRemovePollOption(idx)}
                        className="p-1.5 text-slate-400 hover:text-red-500 rounded-lg hover:bg-red-50 dark:hover:bg-red-950/40 transition-colors"
                        title="Delete option"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                ))}
              </div>

              {pollOptions.length < 5 && (
                <button
                  onClick={handleAddPollOption}
                  className="flex items-center space-x-1.5 text-xs font-semibold text-blue-600 dark:text-blue-400 hover:text-blue-700 px-2 py-1 rounded-lg hover:bg-blue-100/60 dark:hover:bg-blue-950/50 transition-colors"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>{language === 'bn' ? '+ আরেকটি অপশন যোগ করুন' : '+ Add another option'}</span>
                </button>
              )}
            </div>
          )}

          {/* Schedule Post Picker Panel */}
          {isScheduling && (
            <div className="mt-3 p-3.5 bg-amber-50/50 dark:bg-slate-800/80 rounded-xl border border-amber-200 dark:border-amber-900/50 space-y-3 animate-in fade-in duration-150">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2 text-xs font-bold text-amber-700 dark:text-amber-300">
                  <Clock className="w-4 h-4" />
                  <span>{language === 'bn' ? 'পোস্ট শিডিউল করুন' : 'Schedule Post'}</span>
                </div>
                <button
                  onClick={() => {
                    setIsScheduling(false);
                    setScheduledDateTime('');
                  }}
                  className="p-1 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-lg hover:bg-slate-200/50 dark:hover:bg-slate-700 transition-colors"
                  title="Cancel schedule"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="flex flex-col sm:flex-row sm:items-center gap-2">
                <input
                  type="datetime-local"
                  min={minDateTime}
                  value={scheduledDateTime}
                  onChange={(e) => setScheduledDateTime(e.target.value)}
                  className="bg-white dark:bg-slate-900 text-slate-900 dark:text-white px-3 py-1.5 text-xs font-medium rounded-lg border border-slate-200 dark:border-slate-700 focus:outline-none focus:ring-2 focus:ring-amber-500"
                />

                {/* Quick Presets */}
                <div className="flex items-center space-x-1.5 flex-wrap gap-1">
                  <button
                    onClick={() => handleQuickSchedule(12)}
                    className="px-2 py-1 text-[11px] rounded-lg bg-amber-100 dark:bg-amber-950/60 text-amber-800 dark:text-amber-200 hover:bg-amber-200/80 font-medium transition-colors"
                  >
                    +12h
                  </button>
                  <button
                    onClick={() => handleQuickSchedule(24)}
                    className="px-2 py-1 text-[11px] rounded-lg bg-amber-100 dark:bg-amber-950/60 text-amber-800 dark:text-amber-200 hover:bg-amber-200/80 font-medium transition-colors"
                  >
                    Tomorrow
                  </button>
                  <button
                    onClick={() => handleQuickSchedule(48)}
                    className="px-2 py-1 text-[11px] rounded-lg bg-amber-100 dark:bg-amber-950/60 text-amber-800 dark:text-amber-200 hover:bg-amber-200/80 font-medium transition-colors"
                  >
                    In 2 days
                  </button>
                </div>
              </div>

              {scheduledDateTime && (
                <div className="flex items-center space-x-1.5 text-[11px] text-amber-700 dark:text-amber-300 font-semibold">
                  <CheckCircle className="w-3.5 h-3.5 text-emerald-500" />
                  <span>
                    {language === 'bn' ? 'পোস্ট প্রকাশিত হবে: ' : 'Will be published on: '}
                    {new Date(scheduledDateTime).toLocaleString([], {
                      month: 'short',
                      day: 'numeric',
                      year: 'numeric',
                      hour: '2-digit',
                      minute: '2-digit',
                    })}
                  </span>
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Emoji Picker Popover */}
      {showEmojiPicker && (
        <div className="relative mt-3 z-30">
          <div className="absolute left-0 bottom-full mb-2">
            <EmojiPicker
              onSelect={handleEmojiSelect}
              onClose={() => setShowEmojiPicker(false)}
            />
          </div>
        </div>
      )}

      {/* Hidden file input */}
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*,video/*"
        onChange={handleFileUpload}
        className="hidden"
      />

      {/* Action Buttons Row */}
      <div className="mt-3 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between flex-wrap gap-2">
        <div className="flex items-center space-x-1 sm:space-x-1.5 flex-wrap">
          {/* Live Camera Button */}
          <button
            onClick={() => setIsCameraOpen(true)}
            className="flex items-center space-x-1.5 px-2.5 py-1.5 rounded-xl text-slate-700 dark:text-slate-300 hover:bg-emerald-50 dark:hover:bg-emerald-950/40 hover:text-emerald-600 dark:hover:text-emerald-400 text-xs font-semibold transition-colors"
            title="Take photo with camera"
          >
            <Camera className="w-4 h-4 text-emerald-500" />
            <span className="hidden sm:inline">
              {language === 'bn' ? 'ক্যামেরা' : 'Camera'}
            </span>
          </button>

          {/* Photo / Video upload */}
          <button
            onClick={() => fileInputRef.current?.click()}
            className="flex items-center space-x-1.5 px-2.5 py-1.5 rounded-xl text-slate-700 dark:text-slate-300 hover:bg-blue-50 dark:hover:bg-blue-950/40 hover:text-blue-600 dark:hover:text-blue-400 text-xs font-semibold transition-colors"
            title="Attach Photo or Video"
          >
            <ImageIcon className="w-4 h-4 text-blue-500" />
            <span className="hidden sm:inline">
              {language === 'bn' ? 'ছবি/ভিডিও' : 'Photo/Video'}
            </span>
          </button>

          {/* Color Background Text Toggle */}
          <button
            onClick={() => setShowColorPalette(!showColorPalette)}
            className={`flex items-center space-x-1.5 px-2.5 py-1.5 rounded-xl text-xs font-semibold transition-colors ${
              showColorPalette || bgGradient
                ? 'bg-purple-100 dark:bg-purple-950/60 text-purple-600 dark:text-purple-400'
                : 'text-slate-700 dark:text-slate-300 hover:bg-purple-50 dark:hover:bg-purple-950/40 hover:text-purple-600 dark:hover:text-purple-400'
            }`}
            title="Colored Status Background"
          >
            <Palette className="w-4 h-4 text-purple-500" />
            <span className="hidden sm:inline">
              {language === 'bn' ? 'রঙিন' : 'Color'}
            </span>
          </button>

          {/* Reel Upload button */}
          <button
            onClick={() => setIsCreateReelModalOpen(true)}
            className="flex items-center space-x-1.5 px-2.5 py-1.5 rounded-xl text-slate-700 dark:text-slate-300 hover:bg-pink-50 dark:hover:bg-pink-950/40 hover:text-pink-600 dark:hover:text-pink-400 text-xs font-semibold transition-colors"
            title="Create & Upload Reel"
          >
            <Film className="w-4 h-4 text-pink-500" />
            <span className="hidden sm:inline">
              {language === 'bn' ? 'রিল' : 'Reel'}
            </span>
          </button>

          {/* Create Poll Button */}
          <button
            onClick={() => setIsCreatingPoll(!isCreatingPoll)}
            className={`flex items-center space-x-1.5 px-2.5 py-1.5 rounded-xl text-xs font-semibold transition-colors ${
              isCreatingPoll
                ? 'bg-blue-100 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400'
                : 'text-slate-700 dark:text-slate-300 hover:bg-blue-50 dark:hover:bg-blue-950/40 hover:text-blue-600 dark:hover:text-blue-400'
            }`}
            title="Create Poll"
          >
            <BarChart2 className="w-4 h-4 text-indigo-500" />
            <span className="hidden md:inline">
              {language === 'bn' ? 'পোল' : 'Poll'}
            </span>
          </button>

          {/* Schedule Post Button */}
          <button
            onClick={() => setIsScheduling(!isScheduling)}
            className={`flex items-center space-x-1.5 px-2.5 py-1.5 rounded-xl text-xs font-semibold transition-colors ${
              isScheduling || scheduledDateTime
                ? 'bg-amber-100 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400'
                : 'text-slate-700 dark:text-slate-300 hover:bg-amber-50 dark:hover:bg-amber-950/40 hover:text-amber-600 dark:hover:text-amber-400'
            }`}
            title="Schedule Post"
          >
            <Clock className="w-4 h-4 text-amber-500" />
            <span className="hidden md:inline">
              {language === 'bn' ? 'শিডিউল' : 'Schedule'}
            </span>
          </button>

          {/* Emoji Picker toggle */}
          <button
            onClick={() => setShowEmojiPicker(!showEmojiPicker)}
            className="flex items-center space-x-1.5 px-2.5 py-1.5 rounded-xl text-slate-700 dark:text-slate-300 hover:bg-amber-50 dark:hover:bg-amber-950/40 hover:text-amber-600 dark:hover:text-amber-400 text-xs font-semibold transition-colors"
            title="Insert Emoji"
          >
            <Smile className="w-4 h-4 text-amber-500" />
            <span className="hidden sm:inline">
              {language === 'bn' ? 'ইমোজি' : 'Emoji'}
            </span>
          </button>

          {/* Feelings quick picker */}
          <button
            onClick={() =>
              setFeeling(
                feeling
                  ? null
                  : language === 'bn'
                  ? '✨ খুব খুশি অনুভূতি করছে'
                  : '✨ feeling energized & excited'
              )
            }
            className="flex items-center space-x-1.5 px-2.5 py-1.5 rounded-xl text-slate-700 dark:text-slate-300 hover:bg-purple-50 dark:hover:bg-purple-950/40 hover:text-purple-600 dark:hover:text-purple-400 text-xs font-semibold transition-colors"
            title="Feeling / Activity"
          >
            <Sparkles className="w-4 h-4 text-purple-500" />
            <span className="hidden lg:inline">
              {language === 'bn' ? 'অনুভূতি' : 'Feeling'}
            </span>
          </button>
        </div>

        {/* Submit button */}
        <div className="flex items-center space-x-2">
          <button
            onClick={handleSubmit}
            disabled={!canSubmit}
            className={`flex items-center space-x-1.5 px-4 py-1.5 rounded-xl text-xs font-semibold shadow-sm transition-all active:scale-95 cursor-pointer disabled:cursor-not-allowed ${
              scheduledDateTime
                ? 'bg-amber-600 hover:bg-amber-700 text-white disabled:opacity-50'
                : 'bg-blue-600 hover:bg-blue-700 text-white disabled:opacity-50 disabled:hover:bg-blue-600'
            }`}
          >
            {scheduledDateTime ? (
              <>
                <Calendar className="w-3.5 h-3.5" />
                <span>{language === 'bn' ? 'শিডিউল করুন' : 'Schedule'}</span>
              </>
            ) : (
              <>
                <Send className="w-3.5 h-3.5" />
                <span>{language === 'bn' ? 'পোস্ট করুন' : 'Post'}</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Live Camera Modal */}
      <CameraCaptureModal
        isOpen={isCameraOpen}
        onClose={() => setIsCameraOpen(false)}
        onCapture={handleCameraCapture}
      />
    </div>
  );
};
