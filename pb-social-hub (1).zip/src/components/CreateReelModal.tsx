import React, { useState, useRef } from 'react';
import { useApp } from '../context/AppContext';
import {
  X,
  Film,
  Upload,
  Music,
  Sparkles,
  Check,
  Play,
  Pause,
  Hash,
  Video,
} from 'lucide-react';

const SAMPLE_REEL_VIDEOS = [
  {
    title: 'Dhaka City Lights',
    url: 'https://assets.mixkit.co/videos/preview/mixkit-city-traffic-at-night-aerial-view-41551-large.mp4',
  },
  {
    title: 'Nature River Drone',
    url: 'https://assets.mixkit.co/videos/preview/mixkit-tree-branches-in-the-breeze-1188-large.mp4',
  },
  {
    title: 'Coding & Coffee',
    url: 'https://assets.mixkit.co/videos/preview/mixkit-hands-of-a-man-working-on-a-computer-43286-large.mp4',
  },
];

const TRENDING_AUDIOS = [
  'Original Audio - Pranto',
  'Coke Studio Bangla - Shob Loke Koy',
  'Lo-Fi Monsoon Rain Beats',
  'Aesthetic Acoustic Vibes',
];

export const CreateReelModal: React.FC = () => {
  const {
    isCreateReelModalOpen,
    setIsCreateReelModalOpen,
    addReel,
    currentUser,
    language,
    setActiveTab,
  } = useApp();

  const [videoUrl, setVideoUrl] = useState('');
  const [caption, setCaption] = useState('');
  const [audioTrack, setAudioTrack] = useState(TRENDING_AUDIOS[0]);
  const [isPlaying, setIsPlaying] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  if (!isCreateReelModalOpen) return null;

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onloadend = () => {
      setVideoUrl(reader.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handleAddHashtag = (tag: string) => {
    setCaption((prev) => (prev ? `${prev} ${tag}` : tag));
  };

  const handleSubmit = () => {
    if (!videoUrl || !caption.trim()) return;

    setIsSubmitting(true);
    addReel(videoUrl, caption.trim(), audioTrack);

    setTimeout(() => {
      setIsSubmitting(false);
      setIsCreateReelModalOpen(false);
      setVideoUrl('');
      setCaption('');
      setActiveTab('reels');
    }, 400);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/75 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="relative w-full max-w-xl bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 dark:border-slate-800">
          <div className="flex items-center space-x-2.5">
            <div className="w-8 h-8 rounded-xl bg-linear-to-tr from-pink-500 to-rose-500 text-white flex items-center justify-center">
              <Film className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-base text-slate-900 dark:text-white">
                {language === 'bn' ? 'নতুন রিল তৈরি ও আপলোড' : 'Create & Upload Reel'}
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                {language === 'bn' ? 'ছোট ভিডিও শেয়ার করুন সবার সাথে' : 'Share engaging vertical short videos'}
              </p>
            </div>
          </div>

          <button
            onClick={() => setIsCreateReelModalOpen(false)}
            className="p-2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto p-5 sm:p-6 space-y-4">
          {/* Video Preview or Upload Box */}
          {videoUrl ? (
            <div className="relative rounded-2xl overflow-hidden bg-black aspect-9/16 max-h-[340px] mx-auto flex items-center justify-center shadow-lg border border-slate-800">
              <video
                src={videoUrl}
                autoPlay
                loop
                muted
                playsInline
                className="w-full h-full object-cover"
              />
              <button
                onClick={() => setVideoUrl('')}
                className="absolute top-3 right-3 p-1.5 bg-black/70 hover:bg-black/90 text-white rounded-full transition-transform active:scale-95"
                title="Remove video"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          ) : (
            <div className="space-y-3">
              <div
                onClick={() => fileInputRef.current?.click()}
                className="border-2 border-dashed border-slate-300 dark:border-slate-700 hover:border-pink-500 dark:hover:border-pink-500 rounded-2xl p-8 text-center cursor-pointer transition-colors bg-slate-50/50 dark:bg-slate-800/40 group"
              >
                <div className="w-12 h-12 rounded-2xl bg-pink-100 dark:bg-pink-950/60 text-pink-600 dark:text-pink-400 flex items-center justify-center mx-auto mb-3 group-hover:scale-105 transition-transform">
                  <Upload className="w-6 h-6" />
                </div>
                <h4 className="font-semibold text-sm text-slate-800 dark:text-slate-200">
                  {language === 'bn' ? 'ভিডিও ফাইল সিলেক্ট করুন' : 'Select a video file to upload'}
                </h4>
                <p className="text-xs text-slate-400 mt-1">
                  MP4, WebM or MOV up to 60 seconds (vertical 9:16 recommended)
                </p>
                <button
                  type="button"
                  className="mt-3 px-4 py-1.5 bg-pink-600 text-white rounded-xl text-xs font-semibold hover:bg-pink-700 transition-colors"
                >
                  {language === 'bn' ? 'ডিভাইস থেকে ব্রাউজ করুন' : 'Browse Device'}
                </button>
              </div>

              {/* Sample Videos Preset */}
              <div>
                <p className="text-xs font-semibold text-slate-500 mb-2">
                  {language === 'bn' ? 'অথবা দ্রুত ডেমো ভিডিও বাছুন:' : 'Or choose a ready sample video:'}
                </p>
                <div className="grid grid-cols-3 gap-2">
                  {SAMPLE_REEL_VIDEOS.map((sample, i) => (
                    <button
                      key={i}
                      type="button"
                      onClick={() => setVideoUrl(sample.url)}
                      className="p-2 bg-slate-100 dark:bg-slate-800 hover:bg-pink-50 dark:hover:bg-pink-950/40 rounded-xl text-left border border-slate-200 dark:border-slate-700 transition-all text-xs font-medium"
                    >
                      <Video className="w-3.5 h-3.5 text-pink-500 mb-1" />
                      <span className="line-clamp-1 text-slate-700 dark:text-slate-300">
                        {sample.title}
                      </span>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          <input
            ref={fileInputRef}
            type="file"
            accept="video/*"
            onChange={handleFileUpload}
            className="hidden"
          />

          {/* Caption Input */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              {language === 'bn' ? 'ক্যাপশন লিখুন' : 'Reel Caption'}
            </label>
            <textarea
              rows={2}
              value={caption}
              onChange={(e) => setCaption(e.target.value)}
              placeholder={
                language === 'bn'
                  ? 'আপনার রিল সম্পর্কে কিছু লিখুন এবং হ্যাশট্যাগ দিন...'
                  : 'Write a catchy caption with hashtags...'
              }
              className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-3 text-xs text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-pink-500 resize-none"
            />

            {/* Quick Hashtag pills */}
            <div className="flex items-center space-x-1.5 mt-2 flex-wrap gap-1">
              {['#viral', '#reels', '#bangla', '#explore', '#bondhunet'].map((tag) => (
                <button
                  key={tag}
                  type="button"
                  onClick={() => handleAddHashtag(tag)}
                  className="px-2 py-0.5 bg-slate-100 dark:bg-slate-800 hover:bg-pink-100 dark:hover:bg-pink-950/60 hover:text-pink-600 text-[11px] font-semibold text-slate-600 dark:text-slate-300 rounded-md transition-colors"
                >
                  {tag}
                </button>
              ))}
            </div>
          </div>

          {/* Audio Soundtrack Selection */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1 flex items-center space-x-1.5">
              <Music className="w-3.5 h-3.5 text-pink-500" />
              <span>{language === 'bn' ? 'অডিও ট্র্যাক' : 'Audio Track'}</span>
            </label>
            <div className="space-y-1.5">
              {TRENDING_AUDIOS.map((track) => (
                <button
                  key={track}
                  type="button"
                  onClick={() => setAudioTrack(track)}
                  className={`w-full p-2.5 rounded-xl border text-xs font-medium text-left flex items-center justify-between transition-colors ${
                    audioTrack === track
                      ? 'border-pink-500 bg-pink-50/50 dark:bg-pink-950/30 text-pink-700 dark:text-pink-300'
                      : 'border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300'
                  }`}
                >
                  <span className="truncate">{track}</span>
                  {audioTrack === track && <Check className="w-3.5 h-3.5 text-pink-600 flex-shrink-0 ml-2" />}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-4 bg-slate-50 dark:bg-slate-800/80 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
          <button
            type="button"
            onClick={() => setIsCreateReelModalOpen(false)}
            className="px-4 py-2 text-xs font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-xl transition-colors"
          >
            {language === 'bn' ? 'বাতিল' : 'Cancel'}
          </button>

          <button
            type="button"
            onClick={handleSubmit}
            disabled={!videoUrl || !caption.trim() || isSubmitting}
            className="px-6 py-2 bg-linear-to-r from-pink-600 to-rose-600 hover:from-pink-700 hover:to-rose-700 text-white rounded-xl text-xs font-semibold shadow-md transition-all active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed flex items-center space-x-2"
          >
            {isSubmitting ? (
              <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
            ) : (
              <>
                <Sparkles className="w-3.5 h-3.5" />
                <span>{language === 'bn' ? 'রিল প্রকাশ করুন' : 'Publish Reel'}</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
