import React, { useState, useRef } from 'react';
import { useApp } from '../context/AppContext';
import { CameraCaptureModal } from './CameraCaptureModal';
import {
  X,
  Camera,
  Image as ImageIcon,
  Video,
  Upload,
  Sparkles,
  Check,
} from 'lucide-react';

interface CreateStoryModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const CreateStoryModal: React.FC<CreateStoryModalProps> = ({ isOpen, onClose }) => {
  const { addStory, language } = useApp();
  const [mediaUrl, setMediaUrl] = useState<string | null>(null);
  const [mediaType, setMediaType] = useState<'image' | 'video'>('image');
  const [caption, setCaption] = useState('');
  const [isCameraOpen, setIsCameraOpen] = useState(false);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  if (!isOpen) return null;

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const isVid = file.type.startsWith('video/');
    const reader = new FileReader();
    reader.onloadend = () => {
      setMediaUrl(reader.result as string);
      setMediaType(isVid ? 'video' : 'image');
    };
    reader.readAsDataURL(file);
  };

  const handlePublish = () => {
    if (!mediaUrl) return;
    addStory(mediaUrl, mediaType, caption.trim() || undefined);
    setMediaUrl(null);
    setCaption('');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 animate-in fade-in duration-200">
      <div className="relative w-full max-w-md bg-white dark:bg-slate-900 rounded-3xl overflow-hidden shadow-2xl border border-slate-200 dark:border-slate-800 flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-slate-100 dark:border-slate-800">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 rounded-full bg-linear-to-tr from-amber-500 to-pink-500 text-white flex items-center justify-center">
              <Sparkles className="w-4 h-4" />
            </div>
            <h3 className="font-bold text-slate-900 dark:text-white text-base">
              {language === 'bn' ? 'স্টোরি তৈরি করুন' : 'Create Story'}
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full text-slate-400 hover:text-slate-600 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content area */}
        <div className="p-4 flex-1 flex flex-col items-center justify-center min-h-[380px] bg-slate-900 relative">
          {mediaUrl ? (
            <div className="relative w-full h-[360px] rounded-2xl overflow-hidden flex items-center justify-center bg-black">
              {mediaType === 'video' ? (
                <video
                  src={mediaUrl}
                  controls
                  autoPlay
                  loop
                  playsInline
                  className="w-full h-full object-cover"
                />
              ) : (
                <img
                  src={mediaUrl}
                  alt="Story preview"
                  className="w-full h-full object-cover"
                />
              )}

              {/* Caption Overlay */}
              {caption && (
                <div className="absolute bottom-4 left-4 right-4 bg-black/60 backdrop-blur-md p-2.5 rounded-xl text-white text-center text-xs font-medium">
                  {caption}
                </div>
              )}

              <button
                onClick={() => setMediaUrl(null)}
                className="absolute top-3 right-3 p-1.5 bg-black/60 text-white rounded-full hover:bg-black/80"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          ) : (
            <div className="flex flex-col items-center space-y-4 text-center p-6">
              <div className="w-16 h-16 rounded-full bg-slate-800 text-slate-400 flex items-center justify-center">
                <Upload className="w-8 h-8" />
              </div>
              <div>
                <h4 className="font-semibold text-white text-base">
                  {language === 'bn' ? 'ছবি বা ভিডিও স্টোরি আপলোড করুন' : 'Share a photo or video story'}
                </h4>
                <p className="text-xs text-slate-400 mt-1 max-w-xs">
                  {language === 'bn'
                    ? '২৪ ঘণ্টার জন্য আপনার বন্ধুদের সাথে মুহূর্ত শেয়ার করুন'
                    : 'Disappears after 24 hours. Supports both photos and short clips!'}
                </p>
              </div>

              <div className="flex items-center space-x-3 pt-2">
                <button
                  onClick={() => setIsCameraOpen(true)}
                  className="flex items-center space-x-2 px-4 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-semibold shadow-md transition-colors"
                >
                  <Camera className="w-4 h-4" />
                  <span>{language === 'bn' ? 'ক্যামেরা ফটো' : 'Take Photo'}</span>
                </button>

                <button
                  onClick={() => fileInputRef.current?.click()}
                  className="flex items-center space-x-2 px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-semibold transition-colors"
                >
                  <Video className="w-4 h-4 text-pink-400" />
                  <span>{language === 'bn' ? 'গ্যালারি / ভিডিও' : 'Upload Video/Photo'}</span>
                </button>
              </div>
            </div>
          )}

          <input
            ref={fileInputRef}
            type="file"
            accept="image/*,video/*"
            onChange={handleFileUpload}
            className="hidden"
          />
        </div>

        {/* Footer with caption input and Share button */}
        {mediaUrl && (
          <div className="p-4 border-t border-slate-100 dark:border-slate-800 bg-white dark:bg-slate-900 space-y-3">
            <input
              type="text"
              value={caption}
              onChange={(e) => setCaption(e.target.value)}
              placeholder={language === 'bn' ? 'স্টোরিতে ক্যাপশন যোগ করুন...' : 'Add a caption...'}
              className="w-full px-3.5 py-2 text-xs bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-white rounded-xl border-none focus:outline-none focus:ring-1 focus:ring-blue-500"
            />

            <div className="flex items-center justify-between">
              <button
                onClick={() => setMediaUrl(null)}
                className="px-4 py-2 text-xs font-medium text-slate-500 hover:text-slate-700 dark:text-slate-400"
              >
                {language === 'bn' ? 'মুছে ফেলুন' : 'Discard'}
              </button>

              <button
                onClick={handlePublish}
                className="flex items-center space-x-1.5 px-5 py-2 bg-linear-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white rounded-xl text-xs font-semibold shadow-md transition-all active:scale-95"
              >
                <Check className="w-4 h-4" />
                <span>{language === 'bn' ? 'স্টোরি শেয়ার করুন' : 'Share to Story'}</span>
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Camera Capture Modal */}
      <CameraCaptureModal
        isOpen={isCameraOpen}
        onClose={() => setIsCameraOpen(false)}
        onCapture={(dataUrl) => {
          setMediaUrl(dataUrl);
          setMediaType('image');
        }}
      />
    </div>
  );
};
