import React, { useState } from 'react';
import { Smile, Search, Heart, Sparkles, Coffee, Dog, Flag } from 'lucide-react';

interface EmojiPickerProps {
  onSelect: (emoji: string) => void;
  onClose?: () => void;
}

const EMOJI_CATEGORIES = [
  {
    id: 'smileys',
    name: 'Smileys',
    icon: Smile,
    emojis: ['😀', '😃', '😄', '😁', '😆', '😅', '😂', '🤣', '🥹', '😊', '😇', '🙂', '😉', '😌', '😍', '🥰', '😘', '😋', '😜', '😎', '🤩', '🥳', '😏', '😒', '😞', '😢', '😭', '😤', '😡', '🤯', '😱', '🤫', '😴', '🫡'],
  },
  {
    id: 'gestures',
    name: 'Gestures',
    icon: Sparkles,
    emojis: ['👍', '👎', '👏', '🙌', '🤝', '👊', '✌️', '🫰', '🤞', '🤟', '🤘', '👌', '🤌', '👈', '👉', '👆', '👇', '✋', '👋', '✍️', '🙏', '💪', '🔥', '✨', '🎉', '💯'],
  },
  {
    id: 'hearts',
    name: 'Hearts',
    icon: Heart,
    emojis: ['❤️', '🧡', '💛', '💚', '💙', '💜', '🤎', '🖤', '🤍', '💖', '💗', '💓', '💞', '💕', '💘', '💝', '💟', '💔', '❤️‍🔥', '❤️‍🩹', '💌'],
  },
  {
    id: 'nature',
    name: 'Nature',
    icon: Dog,
    emojis: ['🐱', '🐶', '🦊', '🐼', '🦁', '🐯', '🐸', '🐵', '🌸', '🌺', '🌻', '🌹', '🌷', '🌱', '🌿', '🌴', '🍀', '🍁', '🍂', '☀️', '⭐', '🌙', '⚡', '🌊', '🌈'],
  },
  {
    id: 'food',
    name: 'Food',
    icon: Coffee,
    emojis: ['☕', '🍵', '🧋', '🍕', '🍔', '🍟', '🌭', '🥪', '🍜', '🍱', '🍙', '🍣', '🍦', '🍩', '🍪', '🎂', '🍰', '🍫', '🍓', '🍉', '🍎', '🥭', '🥑'],
  },
  {
    id: 'flags',
    name: 'Flags',
    icon: Flag,
    emojis: ['🇧🇩', '🇺🇸', '🇬🇧', '🇨🇦', '🇦🇺', '🇯🇵', '🇰🇷', '🇩🇪', '🇫🇷', '🇮🇹', '🇧🇷', '🇦🇷', '🇮🇳', '🇵🇰', '🇸🇦', '🇦🇪', '🇹🇷', '🏆', '🥇', '⚽', '🏏'],
  },
];

const SKIN_TONES = [
  { name: 'Default', tone: '' },
  { name: 'Light', tone: '🏻' },
  { name: 'Medium-Light', tone: '🏼' },
  { name: 'Medium', tone: '🏽' },
  { name: 'Medium-Dark', tone: '🏾' },
  { name: 'Dark', tone: '🏿' },
];

export const EmojiPicker: React.FC<EmojiPickerProps> = ({ onSelect, onClose }) => {
  const [selectedCategory, setSelectedCategory] = useState('smileys');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedSkinTone, setSelectedSkinTone] = useState('');

  // Support skin tone application to gesture emojis
  const applySkinTone = (emoji: string) => {
    const toneEligible = ['👍', '👎', '👏', '🙌', '👊', '✌️', '🤞', '🤟', '🤘', '👌', '👈', '👉', '👆', '👇', '✋', '👋', '✍️', '🙏', '💪', '🫡'];
    if (toneEligible.includes(emoji) && selectedSkinTone) {
      // replace or append modifier
      return emoji.replace(/[\u{1F3FB}-\u{1F3FF}]/u, '') + selectedSkinTone;
    }
    return emoji;
  };

  const currentCategoryObj = EMOJI_CATEGORIES.find((c) => c.id === selectedCategory);

  const filteredEmojis = searchQuery.trim()
    ? EMOJI_CATEGORIES.flatMap((c) => c.emojis).filter((emoji) => emoji.includes(searchQuery))
    : currentCategoryObj?.emojis || [];

  return (
    <div className="w-80 bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden z-50 animate-in fade-in zoom-in-95 duration-150">
      {/* Search & Skin Tone Bar */}
      <div className="p-3 border-b border-slate-100 dark:border-slate-800 space-y-2">
        <div className="relative flex items-center">
          <Search className="absolute left-2.5 w-3.5 h-3.5 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search emoji..."
            className="w-full pl-8 pr-3 py-1.5 text-xs bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-white rounded-lg border-none focus:outline-none focus:ring-1 focus:ring-blue-500"
          />
        </div>

        {/* Skin Tone Selector */}
        <div className="flex items-center justify-between pt-1">
          <span className="text-[11px] font-medium text-slate-500 dark:text-slate-400">Tone:</span>
          <div className="flex items-center space-x-1">
            {SKIN_TONES.map((t) => (
              <button
                key={t.name}
                onClick={() => setSelectedSkinTone(t.tone)}
                className={`w-5 h-5 rounded-full flex items-center justify-center text-xs transition-transform hover:scale-110 ${
                  selectedSkinTone === t.tone
                    ? 'ring-2 ring-blue-500 ring-offset-1 dark:ring-offset-slate-900'
                    : ''
                }`}
                title={t.name}
              >
                <span>{`👍${t.tone}`}</span>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Categories Bar */}
      {!searchQuery && (
        <div className="flex items-center justify-around px-2 py-1.5 bg-slate-50 dark:bg-slate-800/60 border-b border-slate-100 dark:border-slate-800">
          {EMOJI_CATEGORIES.map((cat) => {
            const Icon = cat.icon;
            const isActive = selectedCategory === cat.id;
            return (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`p-1.5 rounded-lg transition-colors ${
                  isActive
                    ? 'text-blue-600 bg-blue-50 dark:bg-blue-900/40'
                    : 'text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-200'
                }`}
                title={cat.name}
              >
                <Icon className="w-4 h-4" />
              </button>
            );
          })}
        </div>
      )}

      {/* Emoji Grid */}
      <div className="p-3 max-h-52 overflow-y-auto grid grid-cols-7 gap-1">
        {filteredEmojis.map((emoji, idx) => {
          const finalEmoji = applySkinTone(emoji);
          return (
            <button
              key={`${finalEmoji}_${idx}`}
              onClick={() => {
                onSelect(finalEmoji);
                if (onClose) onClose();
              }}
              className="w-9 h-9 flex items-center justify-center text-xl rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-transform active:scale-90"
            >
              {finalEmoji}
            </button>
          );
        })}
      </div>
    </div>
  );
};
