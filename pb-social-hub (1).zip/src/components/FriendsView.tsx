import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  Users,
  UserPlus,
  UserCheck,
  Search,
  MessageSquare,
  Phone,
  Video,
  UserX,
} from 'lucide-react';

export const FriendsView: React.FC = () => {
  const {
    friends,
    friendRequests,
    acceptFriendRequest,
    rejectFriendRequest,
    setActiveChatUser,
    startCall,
    setSelectedUserId,
    setActiveTab,
    blockUser,
    language,
  } = useApp();

  const [searchTerm, setSearchTerm] = useState('');
  const [activeSubTab, setActiveSubTab] = useState<'all' | 'requests'>('all');

  const filteredFriends = friends.filter((f) =>
    f.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    f.username.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="max-w-3xl mx-auto space-y-4 py-2 pb-12">
      {/* Header */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl p-5 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 dark:text-white flex items-center space-x-2">
            <Users className="w-5 h-5 text-blue-600" />
            <span>{language === 'bn' ? 'বন্ধু ও অনুরোধসমূহ' : 'Friends & Connections'}</span>
          </h2>
          <p className="text-xs text-slate-500">
            {friends.length} {language === 'bn' ? 'জন বন্ধু রয়েছে' : 'total friends on BondhuNet'}
          </p>
        </div>

        <div className="flex items-center space-x-2">
          {/* Sub-tabs */}
          <div className="bg-slate-100 dark:bg-slate-800 p-1 rounded-xl flex space-x-1 text-xs font-semibold">
            <button
              onClick={() => setActiveSubTab('all')}
              className={`px-3 py-1.5 rounded-lg transition-colors ${
                activeSubTab === 'all'
                  ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-xs'
                  : 'text-slate-500 hover:text-slate-800 dark:hover:text-white'
              }`}
            >
              {language === 'bn' ? 'সকল বন্ধু' : 'All Friends'} ({friends.length})
            </button>
            <button
              onClick={() => setActiveSubTab('requests')}
              className={`px-3 py-1.5 rounded-lg transition-colors flex items-center space-x-1 ${
                activeSubTab === 'requests'
                  ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-xs'
                  : 'text-slate-500 hover:text-slate-800 dark:hover:text-white'
              }`}
            >
              <span>{language === 'bn' ? 'অনুরোধ' : 'Requests'}</span>
              {friendRequests.length > 0 && (
                <span className="w-4 h-4 rounded-full bg-red-500 text-white text-[10px] flex items-center justify-center font-bold">
                  {friendRequests.length}
                </span>
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Requests Section */}
      {(activeSubTab === 'requests' || (friendRequests.length > 0 && activeSubTab === 'all')) && (
        <div className="bg-white dark:bg-slate-900 rounded-3xl p-5 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-sm text-slate-900 dark:text-white flex items-center space-x-2">
              <UserPlus className="w-4 h-4 text-blue-600" />
              <span>{language === 'bn' ? 'নতুন ফ্রেন্ড রিকোয়েস্ট' : 'Pending Friend Requests'}</span>
            </h3>
            <span className="text-xs font-bold text-blue-600">{friendRequests.length}</span>
          </div>

          {friendRequests.length === 0 ? (
            <p className="text-xs text-slate-400 py-4 text-center">No pending friend requests</p>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {friendRequests.map((req) => (
                <div
                  key={req.id}
                  className="flex items-center justify-between p-3.5 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200/60 dark:border-slate-700/50"
                >
                  <div className="flex items-center space-x-3">
                    <img src={req.avatar} alt={req.name} className="w-11 h-11 rounded-full object-cover" />
                    <div>
                      <h4 className="font-bold text-xs text-slate-900 dark:text-white">{req.name}</h4>
                      <p className="text-[11px] text-slate-400">{req.location || 'Dhaka'}</p>
                    </div>
                  </div>

                  <div className="flex items-center space-x-1.5">
                    <button
                      onClick={() => acceptFriendRequest(req.id)}
                      className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-semibold shadow-xs"
                    >
                      Confirm
                    </button>
                    <button
                      onClick={() => rejectFriendRequest(req.id)}
                      className="px-3 py-1.5 bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300 rounded-xl text-xs font-semibold"
                    >
                      Delete
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* All Friends List */}
      {activeSubTab === 'all' && (
        <div className="bg-white dark:bg-slate-900 rounded-3xl p-5 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
          <div className="flex items-center justify-between gap-4">
            <h3 className="font-bold text-sm text-slate-900 dark:text-white">
              {language === 'bn' ? 'বন্ধুদের তালিকা' : 'Your Friends'} ({filteredFriends.length})
            </h3>

            {/* Search */}
            <div className="relative w-48 sm:w-64">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search friends..."
                className="w-full bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-white text-xs pl-8 pr-3 py-1.5 rounded-xl border-none outline-none focus:ring-1 focus:ring-blue-500"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {filteredFriends.map((friend) => (
              <div
                key={friend.id}
                className="flex items-center justify-between p-3.5 bg-slate-50 dark:bg-slate-800/60 rounded-2xl hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
              >
                <div
                  onClick={() => {
                    setSelectedUserId(friend.id);
                    setActiveTab('profile');
                  }}
                  className="flex items-center space-x-3 cursor-pointer min-w-0"
                >
                  <div className="relative">
                    <img src={friend.avatar} alt={friend.name} className="w-11 h-11 rounded-full object-cover" />
                    {friend.isOnline && (
                      <span className="absolute bottom-0 right-0 w-3 h-3 bg-emerald-500 ring-2 ring-white dark:ring-slate-900 rounded-full" />
                    )}
                  </div>
                  <div className="min-w-0">
                    <h4 className="font-bold text-xs text-slate-900 dark:text-white truncate hover:underline">
                      {friend.name}
                    </h4>
                    <p className="text-[11px] text-slate-400">@{friend.username}</p>
                  </div>
                </div>

                <div className="flex items-center space-x-1.5">
                  <button
                    onClick={() => setActiveChatUser(friend)}
                    className="p-2 rounded-xl bg-blue-50 dark:bg-blue-950/40 text-blue-600 dark:text-blue-400 hover:bg-blue-100 transition-colors"
                    title="Message"
                  >
                    <MessageSquare className="w-4 h-4" />
                  </button>

                  <button
                    onClick={() => startCall(friend, 'audio')}
                    className="p-2 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 dark:text-emerald-400 hover:bg-emerald-100 transition-colors"
                    title="Audio Call"
                  >
                    <Phone className="w-4 h-4" />
                  </button>

                  <button
                    onClick={() => startCall(friend, 'video')}
                    className="p-2 rounded-xl bg-pink-50 dark:bg-pink-950/40 text-pink-600 dark:text-pink-400 hover:bg-pink-100 transition-colors"
                    title="Video Call"
                  >
                    <Video className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
