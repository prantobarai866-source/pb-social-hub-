import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import confetti from 'canvas-confetti';
import {
  Gamepad2,
  Users,
  Play,
  Trophy,
  RotateCcw,
  Sparkles,
  Swords,
  Bot,
  UserCheck,
  X,
  Plus,
} from 'lucide-react';

export const GamingView: React.FC = () => {
  const { gameRooms, joinGameRoom, currentUser, language } = useApp();
  const [activeRoomId, setActiveRoomId] = useState<string | null>(null);
  const [showLobbyModal, setShowLobbyModal] = useState(false);

  // Tic Tac Toe State
  const [board, setBoard] = useState<(string | null)[]>(Array(9).fill(null));
  const [isXNext, setIsXNext] = useState(true);
  const [winner, setWinner] = useState<string | null>(null);
  const [playMode, setPlayMode] = useState<'bot' | 'pvp'>('bot');
  const [scores, setScores] = useState({ x: 0, o: 0, ties: 0 });

  const checkWinner = (squares: (string | null)[]) => {
    const lines = [
      [0, 1, 2],
      [3, 4, 5],
      [6, 7, 8],
      [0, 3, 6],
      [1, 4, 7],
      [2, 5, 8],
      [0, 4, 8],
      [2, 4, 6],
    ];
    for (let i = 0; i < lines.length; i++) {
      const [a, b, c] = lines[i];
      if (squares[a] && squares[a] === squares[b] && squares[a] === squares[c]) {
        return squares[a];
      }
    }
    if (squares.every((sq) => sq !== null)) {
      return 'Tie';
    }
    return null;
  };

  const handleSquareClick = (index: number) => {
    if (board[index] || winner) return;

    const newBoard = [...board];
    newBoard[index] = isXNext ? 'X' : 'O';
    setBoard(newBoard);

    const winResult = checkWinner(newBoard);
    if (winResult) {
      setWinner(winResult);
      if (winResult === 'X') {
        setScores((s) => ({ ...s, x: s.x + 1 }));
        confetti({ particleCount: 50, spread: 70, origin: { y: 0.6 } });
      } else if (winResult === 'O') {
        setScores((s) => ({ ...s, o: s.o + 1 }));
      } else {
        setScores((s) => ({ ...s, ties: s.ties + 1 }));
      }
      return;
    }

    if (playMode === 'bot' && isXNext) {
      setIsXNext(false);
      // AI Bot move
      setTimeout(() => {
        const availableIndices = newBoard
          .map((val, idx) => (val === null ? idx : null))
          .filter((v): v is number => v !== null);

        if (availableIndices.length > 0) {
          const randomIndex = availableIndices[Math.floor(Math.random() * availableIndices.length)];
          newBoard[randomIndex] = 'O';
          setBoard([...newBoard]);

          const botWinResult = checkWinner(newBoard);
          if (botWinResult) {
            setWinner(botWinResult);
            if (botWinResult === 'O') {
              setScores((s) => ({ ...s, o: s.o + 1 }));
            } else if (botWinResult === 'Tie') {
              setScores((s) => ({ ...s, ties: s.ties + 1 }));
            }
          }
          setIsXNext(true);
        }
      }, 400);
    } else {
      setIsXNext(!isXNext);
    }
  };

  const resetGame = () => {
    setBoard(Array(9).fill(null));
    setIsXNext(true);
    setWinner(null);
  };

  return (
    <div className="max-w-3xl mx-auto space-y-4 py-2">
      {/* Gaming Zone Header */}
      <div className="bg-linear-to-r from-violet-600 via-indigo-600 to-purple-700 text-white rounded-3xl p-6 shadow-xl relative overflow-hidden">
        <div className="relative z-10 max-w-md">
          <div className="inline-flex items-center space-x-1.5 px-3 py-1 bg-white/20 backdrop-blur-md rounded-full text-xs font-semibold mb-3">
            <Gamepad2 className="w-3.5 h-3.5" />
            <span>BondhuNet Arcade</span>
          </div>
          <h2 className="text-2xl font-black mb-2">
            {language === 'bn' ? 'গেম জোন ও লাইভ লবি' : 'Game Lobby & Mini Games'}
          </h2>
          <p className="text-xs text-white/80 leading-relaxed mb-4">
            {language === 'bn'
              ? 'বন্ধুদের সাথে অনলাইনে টিক-ট্যাক-টো বা মিনি গেম খেলুন, অস্থায়ী রুম তৈরি করুন!'
              : 'Challenge friends to quick matches, join temporary rooms, or practice against AI bots!'}
          </p>

          <button
            onClick={() => setShowLobbyModal(true)}
            className="flex items-center space-x-2 px-5 py-2.5 bg-white hover:bg-slate-100 text-indigo-900 rounded-2xl text-xs font-bold shadow-lg transition-transform active:scale-95"
          >
            <Users className="w-4 h-4" />
            <span>{language === 'bn' ? 'গেম লবি খুলুন' : 'Open Game Lobby'}</span>
          </button>
        </div>

        {/* Ambient background decoration */}
        <div className="absolute right-4 -bottom-6 opacity-20 pointer-events-none">
          <Gamepad2 className="w-64 h-64" />
        </div>
      </div>

      {/* Featured Mini Game: Interactive Tic-Tac-Toe Arena */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200 dark:border-slate-800 shadow-sm">
        <div className="flex items-center justify-between pb-4 border-b border-slate-100 dark:border-slate-800 flex-wrap gap-3">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-2xl bg-indigo-50 dark:bg-indigo-950/50 text-indigo-600 flex items-center justify-center">
              <Swords className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-slate-900 dark:text-white text-base">
                Tic-Tac-Toe Arena
              </h3>
              <p className="text-xs text-slate-500">
                {playMode === 'bot' ? 'Single Player vs Bot' : 'Pass & Play with Friend'}
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            {/* Mode toggle */}
            <div className="bg-slate-100 dark:bg-slate-800 p-1 rounded-xl flex space-x-1">
              <button
                onClick={() => {
                  setPlayMode('bot');
                  resetGame();
                }}
                className={`px-3 py-1 rounded-lg text-xs font-semibold flex items-center space-x-1.5 transition-colors ${
                  playMode === 'bot'
                    ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-xs'
                    : 'text-slate-500 hover:text-slate-700'
                }`}
              >
                <Bot className="w-3.5 h-3.5" />
                <span>Vs Bot</span>
              </button>
              <button
                onClick={() => {
                  setPlayMode('pvp');
                  resetGame();
                }}
                className={`px-3 py-1 rounded-lg text-xs font-semibold flex items-center space-x-1.5 transition-colors ${
                  playMode === 'pvp'
                    ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-xs'
                    : 'text-slate-500 hover:text-slate-700'
                }`}
              >
                <Users className="w-3.5 h-3.5" />
                <span>2 Players</span>
              </button>
            </div>

            <button
              onClick={resetGame}
              className="p-2 text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition-colors"
              title="Reset board"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Scoreboard */}
        <div className="grid grid-cols-3 gap-3 my-4">
          <div className="bg-blue-50 dark:bg-blue-950/30 p-2.5 rounded-2xl text-center border border-blue-100 dark:border-blue-900/40">
            <span className="text-[11px] font-bold text-blue-600 block">
              Player X ({(currentUser?.name || 'Player').split(' ')[0]})
            </span>
            <span className="text-lg font-black text-slate-900 dark:text-white">{scores.x}</span>
          </div>
          <div className="bg-slate-50 dark:bg-slate-800/40 p-2.5 rounded-2xl text-center border border-slate-200 dark:border-slate-700">
            <span className="text-[11px] font-bold text-slate-500 block">Ties</span>
            <span className="text-lg font-black text-slate-900 dark:text-white">{scores.ties}</span>
          </div>
          <div className="bg-pink-50 dark:bg-pink-950/30 p-2.5 rounded-2xl text-center border border-pink-100 dark:border-pink-900/40">
            <span className="text-[11px] font-bold text-pink-600 block">
              {playMode === 'bot' ? 'AI Bot (O)' : 'Player O'}
            </span>
            <span className="text-lg font-black text-slate-900 dark:text-white">{scores.o}</span>
          </div>
        </div>

        {/* 3x3 Grid Board */}
        <div className="max-w-[260px] mx-auto grid grid-cols-3 gap-2.5 p-3 bg-slate-100 dark:bg-slate-800/80 rounded-2xl">
          {board.map((val, idx) => (
            <button
              key={idx}
              onClick={() => handleSquareClick(idx)}
              className="aspect-square bg-white dark:bg-slate-900 rounded-xl flex items-center justify-center text-3xl font-black text-slate-900 dark:text-white shadow-xs hover:bg-slate-50 dark:hover:bg-slate-800 active:scale-95 transition-all"
            >
              {val === 'X' && <span className="text-blue-600">X</span>}
              {val === 'O' && <span className="text-pink-500">O</span>}
            </button>
          ))}
        </div>

        {/* Winner or Turn Banner */}
        <div className="mt-4 text-center">
          {winner ? (
            <div className="inline-flex items-center space-x-2 px-4 py-2 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 rounded-full font-bold text-xs shadow-xs">
              <Trophy className="w-4 h-4 text-amber-500" />
              <span>
                {winner === 'Tie'
                  ? "It's a Draw Game!"
                  : `Winner: ${winner === 'X' ? (currentUser?.name || 'Player') : (playMode === 'bot' ? 'AI Bot' : 'Player O')}! 🎉`}
              </span>
            </div>
          ) : (
            <p className="text-xs text-slate-500">
              Current turn:{' '}
              <strong className="text-slate-800 dark:text-slate-200">
                {isXNext ? 'Player X' : (playMode === 'bot' ? 'AI Bot...' : 'Player O')}
              </strong>
            </p>
          )}
        </div>
      </div>

      {/* Game Lobby Modal */}
      {showLobbyModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 animate-in fade-in duration-150">
          <div className="relative w-full max-w-lg bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200 dark:border-slate-800 shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <div className="flex items-center space-x-2.5">
                <div className="w-9 h-9 rounded-2xl bg-indigo-50 dark:bg-indigo-950/50 text-indigo-600 flex items-center justify-center">
                  <Gamepad2 className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-slate-900 dark:text-white text-base">
                    {language === 'bn' ? 'অস্থায়ী গেম লবি' : 'Temporary Game Lobby'}
                  </h3>
                  <p className="text-xs text-slate-500">
                    Join an open room or start a fresh match
                  </p>
                </div>
              </div>
              <button
                onClick={() => setShowLobbyModal(false)}
                className="p-1.5 rounded-full text-slate-400 hover:text-slate-600 hover:bg-slate-100 dark:hover:bg-slate-800"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Room list */}
            <div className="space-y-2.5 max-h-72 overflow-y-auto">
              {gameRooms.map((room) => (
                <div
                  key={room.id}
                  className="flex items-center justify-between p-3.5 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200/60 dark:border-slate-700/40 hover:border-indigo-500 transition-all"
                >
                  <div>
                    <h4 className="font-semibold text-xs text-slate-900 dark:text-white">
                      {room.title}
                    </h4>
                    <p className="text-[11px] text-slate-500">
                      Hosted by: <span className="font-medium text-slate-700 dark:text-slate-300">{room.hostName}</span>
                    </p>
                  </div>

                  <div className="flex items-center space-x-3">
                    <span className="text-[11px] font-medium text-slate-500 flex items-center space-x-1">
                      <Users className="w-3.5 h-3.5" />
                      <span>{room.playersCount} / {room.maxPlayers}</span>
                    </span>

                    <button
                      onClick={() => {
                        joinGameRoom(room.id);
                        setShowLobbyModal(false);
                      }}
                      className="px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-semibold shadow-xs transition-colors"
                    >
                      Join Room
                    </button>
                  </div>
                </div>
              ))}
            </div>

            <div className="pt-2 flex items-center justify-between border-t border-slate-100 dark:border-slate-800">
              <button
                onClick={() => {
                  alert('New temporary playroom code: #RM-' + Math.floor(1000 + Math.random() * 9000));
                }}
                className="flex items-center space-x-1.5 text-xs text-indigo-600 dark:text-indigo-400 font-semibold hover:underline"
              >
                <Plus className="w-4 h-4" />
                <span>Create New Room</span>
              </button>

              <button
                onClick={() => setShowLobbyModal(false)}
                className="px-4 py-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 rounded-xl text-xs font-semibold"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
