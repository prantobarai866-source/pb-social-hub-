import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { GoogleAccount } from '../types';
import { X, UserPlus, Shield, ChevronRight, Check, ArrowLeft, Globe } from 'lucide-react';

export const GoogleLogo: React.FC<{ className?: string }> = ({ className = 'w-6 h-6' }) => (
  <svg className={className} viewBox="0 0 48 48">
    <path
      fill="#EA4335"
      d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"
    />
    <path
      fill="#4285F4"
      d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"
    />
    <path
      fill="#FBBC05"
      d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"
    />
    <path
      fill="#34A853"
      d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"
    />
  </svg>
);

export const GoogleAuthModal: React.FC = () => {
  const {
    isGoogleAuthModalOpen,
    setIsGoogleAuthModalOpen,
    googleAccounts,
    loginWithGoogleAccount,
    signInWithNewGoogleEmail,
    language,
    currentUser,
  } = useApp();

  const [view, setView] = useState<'picker' | 'new_email'>('picker');
  const [newEmail, setNewEmail] = useState('');
  const [newName, setNewName] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [selectedAccId, setSelectedAccId] = useState<string | null>(null);

  if (!isGoogleAuthModalOpen) return null;

  const handleSelectAccount = (account: GoogleAccount) => {
    setSelectedAccId(account.id);
    setIsProcessing(true);
    setTimeout(() => {
      loginWithGoogleAccount(account);
      setIsProcessing(false);
      setSelectedAccId(null);
    }, 700);
  };

  const handleCustomSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newEmail || !newEmail.includes('@')) return;
    setIsProcessing(true);
    setTimeout(() => {
      signInWithNewGoogleEmail(newEmail, newName || newEmail.split('@')[0]);
      setIsProcessing(false);
      setView('picker');
      setNewEmail('');
      setNewName('');
    }, 750);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/70 backdrop-blur-xs animate-in fade-in duration-200">
      {/* Authentic Google Sign-in Card */}
      <div className="relative w-full max-w-[440px] bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden font-sans">
        {/* Top Dismiss Button */}
        <button
          onClick={() => setIsGoogleAuthModalOpen(false)}
          className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors z-10"
          title="Close"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="p-8 sm:p-9">
          {/* Google Header */}
          <div className="flex flex-col items-center text-center mb-6">
            <GoogleLogo className="w-10 h-10 mb-3" />
            <h2 className="text-xl font-medium text-slate-900 dark:text-white">
              {language === 'bn' ? 'Google দিয়ে সাইন ইন করুন' : 'Sign in with Google'}
            </h2>
            <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">
              {language === 'bn' ? (
                <>
                  <span className="font-semibold text-blue-600">BondhuNet</span>-এ এগিয়ে যেতে একটি অ্যাকাউন্ট বেছে নিন
                </>
              ) : (
                <>
                  Choose an account to continue to <span className="font-semibold text-blue-600">BondhuNet</span>
                </>
              )}
            </p>
          </div>

          {/* View 1: Account Chooser */}
          {view === 'picker' ? (
            <div className="space-y-2">
              <div className="divide-y divide-slate-100 dark:divide-slate-800 border-y border-slate-100 dark:border-slate-800">
                {googleAccounts.map((account) => {
                  const isCurrent = currentUser.email === account.email;
                  const isSelected = selectedAccId === account.id;

                  return (
                    <button
                      key={account.id}
                      onClick={() => handleSelectAccount(account)}
                      disabled={isProcessing}
                      className="w-full py-3.5 px-3 flex items-center justify-between text-left hover:bg-slate-50 dark:hover:bg-slate-800/60 rounded-xl transition-colors group cursor-pointer"
                    >
                      <div className="flex items-center space-x-3.5 min-w-0">
                        <div className="relative">
                          <img
                            src={account.avatar}
                            alt={account.name}
                            className="w-10 h-10 rounded-full object-cover border border-slate-200 dark:border-slate-700"
                          />
                          <div className="absolute -bottom-1 -right-1 bg-white dark:bg-slate-900 rounded-full p-0.5 shadow-xs">
                            <GoogleLogo className="w-3.5 h-3.5" />
                          </div>
                        </div>
                        <div className="min-w-0">
                          <div className="flex items-center space-x-1.5">
                            <p className="text-sm font-medium text-slate-900 dark:text-white truncate">
                              {account.name}
                            </p>
                            {isCurrent && (
                              <span className="text-[10px] bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 font-semibold px-2 py-0.5 rounded-full">
                                {language === 'bn' ? 'বর্তমান' : 'Active'}
                              </span>
                            )}
                          </div>
                          <p className="text-xs text-slate-500 dark:text-slate-400 truncate">
                            {account.email}
                          </p>
                        </div>
                      </div>

                      <div className="flex-shrink-0 ml-2">
                        {isSelected ? (
                          <div className="w-5 h-5 border-2 border-blue-600 border-t-transparent rounded-full animate-spin" />
                        ) : (
                          <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-slate-600 dark:group-hover:text-slate-300 transition-colors" />
                        )}
                      </div>
                    </button>
                  );
                })}

                {/* Use another account option */}
                <button
                  onClick={() => setView('new_email')}
                  disabled={isProcessing}
                  className="w-full py-3.5 px-3 flex items-center space-x-3.5 text-left hover:bg-slate-50 dark:hover:bg-slate-800/60 rounded-xl transition-colors text-slate-700 dark:text-slate-300 group cursor-pointer"
                >
                  <div className="w-10 h-10 rounded-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-slate-600 dark:text-slate-300">
                    <UserPlus className="w-5 h-5" />
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-medium">
                      {language === 'bn' ? 'অন্য অ্যাকাউন্ট ব্যবহার করুন' : 'Use another account'}
                    </p>
                  </div>
                </button>
              </div>

              {/* Disclaimer text matching Google OAuth */}
              <div className="pt-4 text-[11px] leading-relaxed text-slate-500 dark:text-slate-400">
                <p>
                  {language === 'bn'
                    ? 'চালিয়ে যেতে Google আপনার নাম, ইমেইল ঠিকানা, ভাষা পছন্দ ও প্রোফাইল ছবি BondhuNet-এর সাথে শেয়ার করবে।'
                    : 'To continue, Google will share your name, email address, language preference, and profile picture with BondhuNet.'}
                </p>
              </div>
            </div>
          ) : (
            /* View 2: Enter another Google Account */
            <form onSubmit={handleCustomSubmit} className="space-y-4">
              <button
                type="button"
                onClick={() => setView('picker')}
                className="inline-flex items-center space-x-1.5 text-xs text-blue-600 dark:text-blue-400 font-medium hover:underline mb-1"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                <span>{language === 'bn' ? 'অ্যাকাউন্ট তালিকায় ফিরে যান' : 'Back to accounts'}</span>
              </button>

              <div className="space-y-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    {language === 'bn' ? 'ইমেইল বা ফোন নম্বর' : 'Email or phone'}
                  </label>
                  <input
                    type="email"
                    required
                    value={newEmail}
                    onChange={(e) => setNewEmail(e.target.value)}
                    placeholder="name@gmail.com"
                    className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    {language === 'bn' ? 'আপনার নাম' : 'Full Name (Optional)'}
                  </label>
                  <input
                    type="text"
                    value={newName}
                    onChange={(e) => setNewName(e.target.value)}
                    placeholder="e.g. Pranto"
                    className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>

              <div className="flex items-center justify-between pt-2">
                <button
                  type="button"
                  onClick={() => setView('picker')}
                  className="text-xs font-medium text-blue-600 dark:text-blue-400 hover:underline"
                >
                  {language === 'bn' ? 'বাতিল' : 'Cancel'}
                </button>

                <button
                  type="submit"
                  disabled={isProcessing || !newEmail}
                  className="px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-semibold transition-colors disabled:opacity-50 flex items-center space-x-1.5"
                >
                  {isProcessing ? (
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  ) : (
                    <span>{language === 'bn' ? 'পরবর্তী' : 'Next'}</span>
                  )}
                </button>
              </div>
            </form>
          )}
        </div>

        {/* Google Footer */}
        <div className="bg-slate-50 dark:bg-slate-800/80 px-8 py-3.5 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400">
          <div className="flex items-center space-x-1">
            <Globe className="w-3 h-3" />
            <span>English (United States)</span>
          </div>

          <div className="flex items-center space-x-3 font-medium">
            <span className="hover:underline cursor-pointer">Help</span>
            <span className="hover:underline cursor-pointer">Privacy</span>
            <span className="hover:underline cursor-pointer">Terms</span>
          </div>
        </div>
      </div>
    </div>
  );
};
