import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { CreatePostBox } from './CreatePostBox';
import { PostCard } from './PostCard';
import {
  Users,
  ShieldCheck,
  Plus,
  Lock,
  Globe,
  Check,
  X,
  UserCheck,
  Activity,
  MessageSquare,
  Sparkles,
} from 'lucide-react';

export const GroupsView: React.FC = () => {
  const {
    groups,
    joinGroup,
    leaveGroup,
    handleGroupJoinRequest,
    posts,
    currentUser,
    selectedGroupId,
    setSelectedGroupId,
    language,
  } = useApp();

  const [activeGroupTab, setActiveGroupTab] = useState<'recent_activity' | 'posts' | 'members' | 'about'>('recent_activity');

  const currentGroup = selectedGroupId
    ? groups.find((g) => g.id === selectedGroupId) || groups[0]
    : groups[0];

  const groupPosts = posts.filter((p) => p.groupId === currentGroup?.id);

  return (
    <div className="max-w-4xl mx-auto pb-12 space-y-4">
      {/* Groups List Banner Carousel */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl p-5 border border-slate-200 dark:border-slate-800 shadow-sm">
        <h3 className="font-bold text-sm text-slate-900 dark:text-white mb-3 flex items-center space-x-2">
          <Users className="w-4 h-4 text-blue-600" />
          <span>{language === 'bn' ? 'আপনার গ্রুপসমূহ' : 'Featured Communities & Groups'}</span>
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {groups.map((grp) => {
            const isSelected = grp.id === currentGroup?.id;
            return (
              <div
                key={grp.id}
                onClick={() => setSelectedGroupId(grp.id)}
                className={`p-3.5 rounded-2xl cursor-pointer border transition-all ${
                  isSelected
                    ? 'border-blue-500 bg-blue-50/50 dark:bg-blue-950/20 shadow-xs'
                    : 'border-slate-200/80 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/40'
                }`}
              >
                <div className="flex items-center space-x-2.5">
                  <div className="w-10 h-10 rounded-xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-xl flex-shrink-0">
                    {grp.icon}
                  </div>
                  <div className="min-w-0">
                    <h4 className="font-bold text-xs text-slate-900 dark:text-white truncate">
                      {grp.name}
                    </h4>
                    <p className="text-[11px] text-slate-400">
                      {grp.membersCount.toLocaleString()} members
                    </p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Selected Group Details Card */}
      {currentGroup && (
        <div className="bg-white dark:bg-slate-900 rounded-3xl overflow-hidden border border-slate-200 dark:border-slate-800 shadow-sm">
          {/* Cover */}
          <div className="relative h-48 sm:h-56 w-full bg-slate-800">
            <img
              src={currentGroup.coverImage}
              alt={currentGroup.name}
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-linear-to-t from-black/80 via-black/20 to-transparent" />

            <div className="absolute bottom-4 left-6 right-6 flex items-end justify-between text-white flex-wrap gap-3">
              <div className="flex items-center space-x-3">
                <div className="w-14 h-14 rounded-2xl bg-white/20 backdrop-blur-md flex items-center justify-center text-3xl shadow-lg">
                  {currentGroup.icon}
                </div>
                <div>
                  <h2 className="text-lg sm:text-xl font-black drop-shadow-md">
                    {currentGroup.name}
                  </h2>
                  <div className="flex items-center space-x-2 text-xs text-white/80 drop-shadow-xs mt-0.5">
                    <Globe className="w-3.5 h-3.5" />
                    <span>{currentGroup.privacy === 'public' ? 'Public Group' : 'Private Group'}</span>
                    <span>·</span>
                    <span>{currentGroup.membersCount.toLocaleString()} members</span>
                  </div>
                </div>
              </div>

              {/* Join / Leave Button */}
              <div>
                {currentGroup.isJoined ? (
                  <button
                    onClick={() => leaveGroup(currentGroup.id)}
                    className="flex items-center space-x-1.5 px-4 py-2 bg-white/20 hover:bg-white/30 backdrop-blur-md text-white rounded-xl text-xs font-semibold shadow-md transition-colors"
                  >
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Joined</span>
                  </button>
                ) : (
                  <button
                    onClick={() => joinGroup(currentGroup.id)}
                    className="flex items-center space-x-1.5 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-semibold shadow-md transition-colors"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Join Group</span>
                  </button>
                )}
              </div>
            </div>
          </div>

          {/* Group Navigation Tabs including 'Recent Activity' */}
          <div className="flex items-center space-x-1 px-6 border-b border-slate-100 dark:border-slate-800">
            <button
              onClick={() => setActiveGroupTab('recent_activity')}
              className={`py-3 px-4 text-xs font-bold border-b-2 flex items-center space-x-1.5 transition-colors ${
                activeGroupTab === 'recent_activity'
                  ? 'border-blue-600 text-blue-600 dark:text-blue-400'
                  : 'border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
              }`}
            >
              <Activity className="w-3.5 h-3.5" />
              <span>{language === 'bn' ? 'সাম্প্রতিক কার্যকলাপ' : 'Recent Activity'}</span>
              {currentGroup.joinRequests.length > 0 && (
                <span className="w-2 h-2 rounded-full bg-red-500" />
              )}
            </button>

            <button
              onClick={() => setActiveGroupTab('posts')}
              className={`py-3 px-4 text-xs font-bold border-b-2 transition-colors ${
                activeGroupTab === 'posts'
                  ? 'border-blue-600 text-blue-600 dark:text-blue-400'
                  : 'border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
              }`}
            >
              Discussion Posts ({groupPosts.length})
            </button>

            <button
              onClick={() => setActiveGroupTab('about')}
              className={`py-3 px-4 text-xs font-bold border-b-2 transition-colors ${
                activeGroupTab === 'about'
                  ? 'border-blue-600 text-blue-600 dark:text-blue-400'
                  : 'border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
              }`}
            >
              About
            </button>
          </div>

          {/* Tab: Recent Activity (Latest group feed + Join Requests queue) */}
          {activeGroupTab === 'recent_activity' && (
            <div className="p-6 space-y-6">
              {/* Admin Moderation Queue: Join Requests */}
              {currentGroup.isAdmin && currentGroup.joinRequests.length > 0 && (
                <div className="p-4 bg-amber-50/60 dark:bg-amber-950/20 rounded-2xl border border-amber-200/60 dark:border-amber-900/40">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center space-x-2">
                      <ShieldCheck className="w-4 h-4 text-amber-600 dark:text-amber-400" />
                      <h4 className="font-bold text-xs text-amber-900 dark:text-amber-200">
                        {language === 'bn' ? 'সদস্য যোগদানের অনুরোধ' : 'Pending Member Join Requests'} ({currentGroup.joinRequests.length})
                      </h4>
                    </div>
                    <span className="text-[10px] text-amber-700 dark:text-amber-400">
                      Admin Action Required
                    </span>
                  </div>

                  <div className="space-y-2">
                    {currentGroup.joinRequests.map((req) => (
                      <div
                        key={req.id}
                        className="flex items-center justify-between p-3 bg-white dark:bg-slate-900 rounded-xl shadow-xs"
                      >
                        <div className="flex items-center space-x-3">
                          <img
                            src={req.userAvatar}
                            alt={req.userName}
                            className="w-9 h-9 rounded-full object-cover"
                          />
                          <div>
                            <p className="font-bold text-xs text-slate-900 dark:text-white">
                              {req.userName}
                            </p>
                            <p className="text-[10px] text-slate-400">
                              Requested {req.requestedAt}
                            </p>
                          </div>
                        </div>

                        <div className="flex items-center space-x-2">
                          <button
                            onClick={() => handleGroupJoinRequest(currentGroup.id, req.id, true)}
                            className="flex items-center space-x-1 px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-semibold shadow-xs transition-colors"
                          >
                            <Check className="w-3.5 h-3.5" />
                            <span>Approve</span>
                          </button>
                          <button
                            onClick={() => handleGroupJoinRequest(currentGroup.id, req.id, false)}
                            className="p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                          >
                            <X className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Create Post in Group */}
              <CreatePostBox
                groupId={currentGroup.id}
                placeholder={`Post something in ${currentGroup.name}...`}
              />

              {/* Latest activity feed */}
              <div className="space-y-4">
                <h4 className="text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider">
                  Latest Group Activity
                </h4>

                {groupPosts.length === 0 ? (
                  <div className="p-8 text-center bg-slate-50 dark:bg-slate-800/40 rounded-2xl border border-slate-200 dark:border-slate-800 text-slate-400 text-xs">
                    No recent activity in this group yet. Be the first to share an update!
                  </div>
                ) : (
                  groupPosts.map((post) => <PostCard key={post.id} post={post} />)
                )}
              </div>
            </div>
          )}

          {/* Tab: Posts */}
          {activeGroupTab === 'posts' && (
            <div className="p-6 space-y-4">
              <CreatePostBox
                groupId={currentGroup.id}
                placeholder={`Write to ${currentGroup.name}...`}
              />
              {groupPosts.map((post) => (
                <PostCard key={post.id} post={post} />
              ))}
            </div>
          )}

          {/* Tab: About */}
          {activeGroupTab === 'about' && (
            <div className="p-6 space-y-4">
              <div>
                <h4 className="font-bold text-xs text-slate-700 dark:text-slate-300 uppercase tracking-wider mb-1">
                  Description
                </h4>
                <p className="text-sm text-slate-700 dark:text-slate-300 leading-relaxed">
                  {currentGroup.description}
                </p>
              </div>

              <div className="pt-3 border-t border-slate-100 dark:border-slate-800">
                <h4 className="font-bold text-xs text-slate-700 dark:text-slate-300 uppercase tracking-wider mb-2">
                  Group Information
                </h4>
                <div className="space-y-2 text-xs text-slate-600 dark:text-slate-400">
                  <div className="flex items-center space-x-2">
                    <Globe className="w-4 h-4 text-slate-400" />
                    <span><strong>Visibility:</strong> {currentGroup.privacy === 'public' ? 'Anyone can find and see posts' : 'Only members can see posts'}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Users className="w-4 h-4 text-slate-400" />
                    <span><strong>Members:</strong> {currentGroup.membersCount.toLocaleString()} total members</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <ShieldCheck className="w-4 h-4 text-slate-400" />
                    <span><strong>Admin:</strong> Tanvir Ahmed (Group Founder)</span>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
