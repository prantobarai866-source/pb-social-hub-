import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { EmojiPicker } from './EmojiPicker';
import {
  X,
  Minus,
  Phone,
  Video,
  Send,
  Smile,
  Image as ImageIcon,
  CheckCheck,
} from 'lucide-react';

export const MessengerDock: React.FC = () => {
  const {
    activeChatUser,
    setActiveChatUser,
    chatMessages,
    sendMessage,
    startCall,
    currentUser,
    language,
  } = useApp();

  const [messageText, setMessageText] = useState('');
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);

  if (!activeChatUser) return null;

  const messages = chatMessages[activeChatUser.id] || [];

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!messageText.trim()) return;
    sendMessage(activeChatUser.id, messageText.trim());
    setMessageText('');
    setShowEmojiPicker(false);
  };

  return (
    <div className="fixed bottom-4 right-4 z-40 w-80 sm:w-88 bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden animate-in slide-in-from-bottom-5 duration-200 flex flex-col">
      {/* Top Header */}
      <div className="p-3 bg-white dark:bg-slate-900 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between shadow-xs">
        <div className="flex items-center space-x-2.5 min-w-0">
          <div className="relative">
            <img
              src={activeChatUser.avatar}
              alt={activeChatUser.name}
              className="w-8 h-8 rounded-full object-cover ring-1 ring-slate-200 dark:ring-slate-700"
            />
            <span className="absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full bg-emerald-500 ring-2 ring-white dark:ring-slate-900" />
          </div>
          <div className="min-w-0">
            <h4 className="font-bold text-xs text-slate-900 dark:text-white truncate">
              {activeChatUser.name}
            </h4>
            <span className="text-[10px] text-emerald-600 dark:text-emerald-400 font-medium">
              Active now
            </span>
          </div>
        </div>

        <div className="flex items-center space-x-1">
          {/* Audio Call trigger */}
          <button
            onClick={() => startCall(activeChatUser, 'audio')}
            className="p-1.5 rounded-lg text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 hover:text-blue-600 transition-colors"
            title="Start Audio Call"
          >
            <Phone className="w-4 h-4" />
          </button>

          {/* Video Call trigger */}
          <button
            onClick={() => startCall(activeChatUser, 'video')}
            className="p-1.5 rounded-lg text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 hover:text-pink-600 transition-colors"
            title="Start Video Call"
          >
            <Video className="w-4 h-4" />
          </button>

          {/* Minimize */}
          <button
            onClick={() => setIsMinimized(!isMinimized)}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800"
          >
            <Minus className="w-4 h-4" />
          </button>

          {/* Close */}
          <button
            onClick={() => setActiveChatUser(null)}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Messages area (if not minimized) */}
      {!isMinimized && (
        <>
          <div className="p-3 h-64 overflow-y-auto space-y-2 bg-slate-50/50 dark:bg-slate-900/50">
            {messages.length === 0 ? (
              <div className="text-center py-8 text-slate-400 text-xs">
                Wave to start a conversation with {(activeChatUser?.name || 'Friend').split(' ')[0]} 👋
              </div>
            ) : (
              messages.map((msg) => {
                const isMe = msg.senderId === currentUser.id;
                return (
                  <div
                    key={msg.id}
                    className={`flex ${isMe ? 'justify-end' : 'justify-start'}`}
                  >
                    <div
                      className={`max-w-[80%] rounded-2xl px-3 py-1.5 text-xs ${
                        isMe
                          ? 'bg-blue-600 text-white rounded-br-xs'
                          : 'bg-slate-200 dark:bg-slate-800 text-slate-900 dark:text-white rounded-bl-xs'
                      }`}
                    >
                      <p className="whitespace-pre-wrap break-words">{msg.text}</p>
                      <div
                        className={`text-[9px] mt-0.5 flex items-center justify-end space-x-1 ${
                          isMe ? 'text-blue-100' : 'text-slate-400'
                        }`}
                      >
                        <span>{msg.createdAt}</span>
                        {isMe && <CheckCheck className="w-3 h-3" />}
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>

          {/* Emoji Popover */}
          {showEmojiPicker && (
            <div className="absolute bottom-14 right-2 z-50">
              <EmojiPicker
                onSelect={(emoji) => setMessageText((p) => p + emoji)}
                onClose={() => setShowEmojiPicker(false)}
              />
            </div>
          )}

          {/* Chat input */}
          <form
            onSubmit={handleSend}
            className="p-2 border-t border-slate-100 dark:border-slate-800 flex items-center space-x-1.5 bg-white dark:bg-slate-900"
          >
            <button
              type="button"
              onClick={() => setShowEmojiPicker(!showEmojiPicker)}
              className="p-1.5 text-slate-400 hover:text-amber-500 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            >
              <Smile className="w-4 h-4" />
            </button>

            <input
              type="text"
              value={messageText}
              onChange={(e) => setMessageText(e.target.value)}
              placeholder="Type a message..."
              className="flex-1 bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-white text-xs rounded-full px-3 py-2 border-none outline-none focus:ring-1 focus:ring-blue-500"
            />

            <button
              type="submit"
              disabled={!messageText.trim()}
              className="p-2 bg-blue-600 hover:bg-blue-700 disabled:opacity-40 text-white rounded-full transition-colors"
            >
              <Send className="w-3.5 h-3.5" />
            </button>
          </form>
        </>
      )}
    </div>
  );
};
