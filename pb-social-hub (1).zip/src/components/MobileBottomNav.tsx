import React from 'react';
import { useApp } from '../context/AppContext';
import { Home, Film, PlusCircle, Users, Gamepad2 } from 'lucide-react';

export const MobileBottomNav: React.FC = () => {
  const { activeTab, setActiveTab, setSelectedUserId, setIsCreateReelModalOpen, language } = useApp();

  return (
    <nav className="sm:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-t border-slate-200 dark:border-slate-800 px-3 py-1.5 flex items-center justify-around shadow-lg">
      {/* Home / Feed */}
      <button
        onClick={() => {
          setActiveTab('feed');
          setSelectedUserId(null);
        }}
        className={`flex flex-col items-center py-1 px-2 transition-colors ${
          activeTab === 'feed'
            ? 'text-blue-600 dark:text-blue-400 font-bold'
            : 'text-slate-500 dark:text-slate-400'
        }`}
      >
        <Home className="w-5 h-5" />
        <span className="text-[10px] mt-0.5">{language === 'bn' ? 'হোম' : 'Home'}</span>
      </button>

      {/* Watch Reels */}
      <button
        onClick={() => {
          setActiveTab('reels');
          setSelectedUserId(null);
        }}
        className={`relative flex flex-col items-center py-1 px-2 transition-colors ${
          activeTab === 'reels'
            ? 'text-pink-600 dark:text-pink-400 font-bold'
            : 'text-slate-500 dark:text-slate-400'
        }`}
      >
        <div className="relative">
          <Film className="w-5 h-5" />
          <span className="absolute -top-1 -right-2 px-1 py-0.2 text-[8px] font-extrabold bg-pink-500 text-white rounded-full animate-pulse">
            Hot
          </span>
        </div>
        <span className="text-[10px] mt-0.5">{language === 'bn' ? 'রিল দেখুন' : 'Reels'}</span>
      </button>

      {/* Quick Create Reel */}
      <button
        onClick={() => setIsCreateReelModalOpen(true)}
        className="flex flex-col items-center py-1 px-2 text-indigo-600 dark:text-indigo-400 active:scale-95 transition-transform"
      >
        <PlusCircle className="w-6 h-6" />
        <span className="text-[10px] mt-0.5 font-bold">{language === 'bn' ? 'তৈরি করুন' : 'Create'}</span>
      </button>

      {/* Friends */}
      <button
        onClick={() => {
          setActiveTab('friends');
          setSelectedUserId(null);
        }}
        className={`flex flex-col items-center py-1 px-2 transition-colors ${
          activeTab === 'friends'
            ? 'text-blue-600 dark:text-blue-400 font-bold'
            : 'text-slate-500 dark:text-slate-400'
        }`}
      >
        <Users className="w-5 h-5" />
        <span className="text-[10px] mt-0.5">{language === 'bn' ? 'বন্ধুরা' : 'Friends'}</span>
      </button>

      {/* Games */}
      <button
        onClick={() => {
          setActiveTab('gaming');
          setSelectedUserId(null);
        }}
        className={`flex flex-col items-center py-1 px-2 transition-colors ${
          activeTab === 'gaming'
            ? 'text-blue-600 dark:text-blue-400 font-bold'
            : 'text-slate-500 dark:text-slate-400'
        }`}
      >
        <Gamepad2 className="w-5 h-5" />
        <span className="text-[10px] mt-0.5">{language === 'bn' ? 'গেমস' : 'Games'}</span>
      </button>
    </nav>
  );
};
