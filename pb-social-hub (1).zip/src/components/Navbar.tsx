import React, { useState, useRef, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { NotificationDropdown } from './NotificationDropdown';
import { BlockListModal } from './BlockListModal';
import { GoogleLogo } from './GoogleAuthModal';
import {
  Home,
  Film,
  Users,
  Gamepad2,
  Search,
  Plus,
  MessageCircle,
  Bell,
  Sun,
  Moon,
  Globe,
  User,
  LogOut,
  Shield,
  Sparkles,
  Tv,
  CheckCircle2,
  Settings,
  Video,
} from 'lucide-react';

interface NavbarProps {
  onSearchChange?: (query: string) => void;
  searchQuery?: string;
}

export const Navbar: React.FC<NavbarProps> = ({ onSearchChange, searchQuery = '' }) => {
  const {
    currentUser,
    activeTab,
    setActiveTab,
    theme,
    toggleTheme,
    language,
    setLanguage,
    notifications,
    setSelectedUserId,
    setActiveChatUser,
    friends,
    isLoggedIn,
    setIsGoogleAuthModalOpen,
    setIsSettingsModalOpen,
    setIsCreateReelModalOpen,
    logout,
  } = useApp();

  const [isNotifOpen, setIsNotifOpen] = useState(false);
  const [isProfileMenuOpen, setIsProfileMenuOpen] = useState(false);
  const [isBlockListOpen, setIsBlockListOpen] = useState(false);
  const [isSearchFocused, setIsSearchFocused] = useState(false);

  const notifRef = useRef<HTMLDivElement | null>(null);
  const profileMenuRef = useRef<HTMLDivElement | null>(null);

  const unreadNotifsCount = notifications.filter((n) => !n.isRead).length;

  // Close menus on outside click
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (notifRef.current && !notifRef.current.contains(e.target as Node)) {
        setIsNotifOpen(false);
      }
      if (profileMenuRef.current && !profileMenuRef.current.contains(e.target as Node)) {
        setIsProfileMenuOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <header className="sticky top-0 z-40 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 transition-colors h-14 sm:h-16 px-3 sm:px-5 flex items-center justify-between">
      {/* Left: Brand Logo & Search Bar */}
      <div className="flex items-center space-x-2 sm:space-x-3">
        {/* Brand Logo */}
        <button
          onClick={() => {
            setActiveTab('feed');
            setSelectedUserId(null);
          }}
          className="flex items-center space-x-2 focus:outline-none group"
        >
          <div className="w-10 h-10 rounded-2xl bg-linear-to-tr from-blue-600 to-indigo-600 flex items-center justify-center text-white font-black text-xl shadow-md group-hover:scale-105 transition-transform">
            B
          </div>
          <span className="hidden md:inline font-black text-lg sm:text-xl text-slate-900 dark:text-white tracking-tight">
            Bondhu<span className="text-blue-600">Net</span>
          </span>
        </button>

        {/* Global Search Bar */}
        <div className="relative">
          <div className="flex items-center bg-slate-100 dark:bg-slate-800 rounded-full px-3 py-2 w-36 sm:w-60 md:w-72 focus-within:ring-2 focus-within:ring-blue-500 transition-all">
            <Search className="w-4 h-4 text-slate-400 mr-2 flex-shrink-0" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => onSearchChange && onSearchChange(e.target.value)}
              onFocus={() => setIsSearchFocused(true)}
              onBlur={() => setTimeout(() => setIsSearchFocused(false), 200)}
              placeholder={language === 'bn' ? 'বন্ধু বা পোস্ট খুঁজুন...' : 'Search BondhuNet...'}
              className="bg-transparent border-none outline-none text-xs text-slate-900 dark:text-white placeholder-slate-400 w-full"
            />
          </div>
        </div>
      </div>

      {/* Center: Navigation Tabs */}
      <nav className="hidden sm:flex items-center space-x-1 md:space-x-3 h-full">
        {/* Feed Tab */}
        <button
          onClick={() => {
            setActiveTab('feed');
            setSelectedUserId(null);
          }}
          className={`relative h-full px-4 md:px-7 flex items-center justify-center transition-colors ${
            activeTab === 'feed'
              ? 'text-blue-600 dark:text-blue-400'
              : 'text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white'
          }`}
          title="Newsfeed"
        >
          <Home className="w-6 h-6" />
          {activeTab === 'feed' && (
            <span className="absolute bottom-0 left-0 right-0 h-1 bg-blue-600 rounded-t-full" />
          )}
        </button>

        {/* Reels Tab */}
        <button
          onClick={() => {
            setActiveTab('reels');
            setSelectedUserId(null);
          }}
          className={`relative h-full px-4 md:px-6 flex items-center space-x-1.5 justify-center transition-colors ${
            activeTab === 'reels'
              ? 'text-pink-600 dark:text-pink-400 font-bold'
              : 'text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white'
          }`}
          title="Watch Reels"
        >
          <Film className="w-5 h-5 sm:w-6 sm:h-6" />
          <span className="hidden lg:inline text-xs font-bold">
            {language === 'bn' ? 'রিল দেখুন' : 'Reels'}
          </span>
          {activeTab === 'reels' && (
            <span className="absolute bottom-0 left-0 right-0 h-1 bg-pink-600 rounded-t-full" />
          )}
        </button>

        {/* Groups Tab */}
        <button
          onClick={() => {
            setActiveTab('groups');
            setSelectedUserId(null);
          }}
          className={`relative h-full px-4 md:px-7 flex items-center justify-center transition-colors ${
            activeTab === 'groups'
              ? 'text-blue-600 dark:text-blue-400'
              : 'text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white'
          }`}
          title="Groups"
        >
          <Users className="w-6 h-6" />
          {activeTab === 'groups' && (
            <span className="absolute bottom-0 left-0 right-0 h-1 bg-blue-600 rounded-t-full" />
          )}
        </button>

        {/* Gaming Tab */}
        <button
          onClick={() => {
            setActiveTab('gaming');
            setSelectedUserId(null);
          }}
          className={`relative h-full px-4 md:px-7 flex items-center justify-center transition-colors ${
            activeTab === 'gaming'
              ? 'text-blue-600 dark:text-blue-400'
              : 'text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white'
          }`}
          title="Gaming"
        >
          <Gamepad2 className="w-6 h-6" />
          {activeTab === 'gaming' && (
            <span className="absolute bottom-0 left-0 right-0 h-1 bg-blue-600 rounded-t-full" />
          )}
        </button>

        {/* Friends Tab */}
        <button
          onClick={() => {
            setActiveTab('friends');
            setSelectedUserId(null);
          }}
          className={`relative h-full px-4 md:px-7 flex items-center justify-center transition-colors ${
            activeTab === 'friends'
              ? 'text-blue-600 dark:text-blue-400'
              : 'text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white'
          }`}
          title="Friends"
        >
          <User className="w-6 h-6" />
          {activeTab === 'friends' && (
            <span className="absolute bottom-0 left-0 right-0 h-1 bg-blue-600 rounded-t-full" />
          )}
        </button>
      </nav>

      {/* Right: Actions, Notifications, Theme, Profile */}
      <div className="flex items-center space-x-1 sm:space-x-2">
        {/* Watch Reels direct button */}
        <button
          onClick={() => {
            setActiveTab('reels');
            setSelectedUserId(null);
          }}
          className={`flex items-center space-x-1.5 px-2.5 sm:px-3 py-1.5 rounded-xl text-xs font-bold transition-all active:scale-95 ${
            activeTab === 'reels'
              ? 'bg-pink-600 text-white shadow-md shadow-pink-600/30'
              : 'bg-pink-50 dark:bg-pink-950/40 text-pink-600 dark:text-pink-400 hover:bg-pink-100 dark:hover:bg-pink-900/50'
          }`}
          title="Watch Reels"
        >
          <Film className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">{language === 'bn' ? 'রিল দেখুন' : 'Reels'}</span>
        </button>

        {/* Create Reel Quick Action Button */}
        <button
          onClick={() => setIsCreateReelModalOpen(true)}
          className="hidden md:flex items-center space-x-1.5 px-3 py-1.5 bg-linear-to-r from-pink-600 to-rose-600 hover:from-pink-700 hover:to-rose-700 text-white rounded-xl text-xs font-semibold shadow-xs transition-all active:scale-95"
          title="Create & Upload Reel"
        >
          <Video className="w-3.5 h-3.5" />
          <span>{language === 'bn' ? '+ রিল' : '+ Reel'}</span>
        </button>

        {/* Language Toggle */}
        <button
          onClick={() => setLanguage(language === 'en' ? 'bn' : 'en')}
          className="px-2.5 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 text-xs font-bold transition-colors"
          title="Toggle Language (English / বাংলা)"
        >
          {language === 'en' ? 'বাং' : 'EN'}
        </button>

        {/* Theme Toggle */}
        <button
          onClick={toggleTheme}
          className="p-2 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors"
          title={theme === 'dark' ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
        >
          {theme === 'dark' ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4" />}
        </button>

        {/* Settings Button */}
        <button
          onClick={() => setIsSettingsModalOpen(true)}
          className="p-2 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors"
          title={language === 'bn' ? 'সেটিংস ও প্রাইভেসি' : 'Settings'}
        >
          <Settings className="w-4.5 h-4.5" />
        </button>

        {/* Messenger Icon button */}
        <button
          onClick={() => setActiveChatUser(friends[0] || null)}
          className="p-2 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors relative"
          title="Messenger"
        >
          <MessageCircle className="w-5 h-5" />
          <span className="absolute top-0 right-0 w-2.5 h-2.5 rounded-full bg-blue-600 ring-2 ring-white dark:ring-slate-900" />
        </button>

        {/* Notification Bell with Badge & Dropdown */}
        <div ref={notifRef} className="relative">
          <button
            onClick={() => setIsNotifOpen(!isNotifOpen)}
            aria-label="Activity Notifications"
            className={`p-2 rounded-full transition-all relative ${
              isNotifOpen
                ? 'bg-blue-100 dark:bg-blue-950 text-blue-600 dark:text-blue-400 ring-2 ring-blue-500/40 shadow-xs'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
            }`}
            title={language === 'bn' ? 'বিজ্ঞপ্তি ও সাম্প্রতিক অ্যাক্টিভিটি' : 'Activity Notifications'}
          >
            <Bell className={`w-5 h-5 ${isNotifOpen ? 'fill-current' : ''}`} />
            {unreadNotifsCount > 0 && (
              <span className="absolute -top-1 -right-1 min-w-[18px] h-[18px] flex items-center justify-center px-1 text-[10px] font-extrabold bg-red-500 text-white rounded-full ring-2 ring-white dark:ring-slate-900 shadow-sm animate-pulse">
                {unreadNotifsCount > 9 ? '9+' : unreadNotifsCount}
              </span>
            )}
          </button>

          <NotificationDropdown isOpen={isNotifOpen} onClose={() => setIsNotifOpen(false)} />
        </div>

        {/* Google Sign In / Profile Avatar Dropdown */}
        {!isLoggedIn ? (
          <button
            onClick={() => setIsGoogleAuthModalOpen(true)}
            className="flex items-center space-x-2 px-3 py-1.5 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-750 text-slate-800 dark:text-white rounded-xl text-xs font-semibold shadow-xs transition-all active:scale-95"
            title="Sign in with Google"
          >
            <GoogleLogo className="w-4 h-4" />
            <span className="hidden sm:inline">
              {language === 'bn' ? 'Google সাইন ইন' : 'Sign in'}
            </span>
          </button>
        ) : (
          <div ref={profileMenuRef} className="relative">
            <button
              onClick={() => setIsProfileMenuOpen(!isProfileMenuOpen)}
              className="flex items-center space-x-1 focus:outline-none group"
            >
              <div className="relative">
                <img
                  src={currentUser.avatar}
                  alt={currentUser.name}
                  className="w-9 h-9 rounded-full object-cover ring-2 ring-transparent group-hover:ring-blue-500 transition-all"
                />
                <div className="absolute -bottom-1 -right-1 bg-white dark:bg-slate-900 rounded-full p-0.5 shadow-xs">
                  <GoogleLogo className="w-3 h-3" />
                </div>
              </div>
            </button>

            {isProfileMenuOpen && (
              <div className="absolute right-0 top-full mt-2 w-72 bg-white dark:bg-slate-800 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-700 p-2 z-50 animate-in fade-in zoom-in-95 duration-100">
                {/* Profile Card Header */}
                <div
                  onClick={() => {
                    setActiveTab('profile');
                    setSelectedUserId(null);
                    setIsProfileMenuOpen(false);
                  }}
                  className="p-3 bg-slate-50 dark:bg-slate-700/50 hover:bg-slate-100 dark:hover:bg-slate-700 rounded-xl cursor-pointer transition-colors flex items-center space-x-3 mb-2"
                >
                  <img
                    src={currentUser.avatar}
                    alt={currentUser.name}
                    className="w-10 h-10 rounded-full object-cover"
                  />
                  <div className="min-w-0 flex-1">
                    <h4 className="font-bold text-xs text-slate-900 dark:text-white truncate">
                      {currentUser.name}
                    </h4>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate">
                      {currentUser.email || 'prantoofficial46@gmail.com'}
                    </p>
                    <span className="inline-flex items-center space-x-1 text-[10px] text-blue-600 dark:text-blue-400 font-semibold mt-0.5">
                      <GoogleLogo className="w-2.5 h-2.5" />
                      <span>Google Account</span>
                    </span>
                  </div>
                </div>

                {/* Menu items */}
                <div className="space-y-1">
                  {/* Settings & Privacy */}
                  <button
                    onClick={() => {
                      setIsSettingsModalOpen(true);
                      setIsProfileMenuOpen(false);
                    }}
                    className="w-full px-3 py-2 text-left text-xs font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 rounded-xl flex items-center space-x-2"
                  >
                    <Settings className="w-4 h-4 text-blue-500" />
                    <span>{language === 'bn' ? 'সেটিংস ও প্রাইভেসি' : 'Settings & Privacy'}</span>
                  </button>

                  {/* Switch Google Account */}
                  <button
                    onClick={() => {
                      setIsGoogleAuthModalOpen(true);
                      setIsProfileMenuOpen(false);
                    }}
                    className="w-full px-3 py-2 text-left text-xs font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 rounded-xl flex items-center space-x-2"
                  >
                    <GoogleLogo className="w-4 h-4" />
                    <span>{language === 'bn' ? 'গুগল অ্যাকাউন্ট পরিবর্তন' : 'Switch Google Account'}</span>
                  </button>

                  {/* Block List */}
                  <button
                    onClick={() => {
                      setIsBlockListOpen(true);
                      setIsProfileMenuOpen(false);
                    }}
                    className="w-full px-3 py-2 text-left text-xs font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 rounded-xl flex items-center space-x-2"
                  >
                    <Shield className="w-4 h-4 text-purple-500" />
                    <span>{language === 'bn' ? 'ব্লক লিস্ট পরিচালনা' : 'Manage Blocked Users'}</span>
                  </button>

                  {/* Theme Toggle */}
                  <button
                    onClick={() => {
                      toggleTheme();
                      setIsProfileMenuOpen(false);
                    }}
                    className="w-full px-3 py-2 text-left text-xs font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 rounded-xl flex items-center space-x-2"
                  >
                    {theme === 'dark' ? <Sun className="w-4 h-4 text-amber-500" /> : <Moon className="w-4 h-4 text-indigo-500" />}
                    <span>
                      {theme === 'dark'
                        ? language === 'bn' ? 'লাইট মোড চালু করুন' : 'Switch to Light Mode'
                        : language === 'bn' ? 'ডার্ক মোড চালু করুন' : 'Switch to Dark Mode'}
                    </span>
                  </button>

                  <div className="pt-1 border-t border-slate-100 dark:border-slate-700">
                    <button
                      onClick={() => {
                        setIsProfileMenuOpen(false);
                        logout();
                      }}
                      className="w-full px-3 py-2 text-left text-xs font-semibold text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/40 rounded-xl flex items-center space-x-2"
                    >
                      <LogOut className="w-4 h-4" />
                      <span>{language === 'bn' ? 'লগআউট' : 'Sign Out'}</span>
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Block List Modal */}
      <BlockListModal isOpen={isBlockListOpen} onClose={() => setIsBlockListOpen(false)} />
    </header>
  );
};
