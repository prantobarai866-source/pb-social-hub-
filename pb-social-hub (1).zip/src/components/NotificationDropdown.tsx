import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  Bell,
  Heart,
  MessageCircle,
  UserPlus,
  Share2,
  Check,
  CheckCheck,
  Flame,
  X,
  Shield,
  Sparkles,
  PlusCircle,
} from 'lucide-react';

interface NotificationDropdownProps {
  isOpen: boolean;
  onClose: () => void;
}

export const NotificationDropdown: React.FC<NotificationDropdownProps> = ({ isOpen, onClose }) => {
  const {
    notifications,
    markNotificationAsRead,
    markAllNotificationsAsRead,
    triggerActivityAlert,
    setSelectedUserId,
    setActiveTab,
    language,
  } = useApp();

  const [filter, setFilter] = useState<'all' | 'unread' | 'comments' | 'reactions'>('all');

  if (!isOpen) return null;

  const filteredNotifs = notifications.filter((n) => {
    if (filter === 'unread') return !n.isRead;
    if (filter === 'comments') return n.type === 'comment_post' || n.type === 'react_comment';
    if (filter === 'reactions') return n.type === 'like_post' || n.type === 'react_story' || !!n.reactionEmoji;
    return true;
  });

  const unreadCount = notifications.filter((n) => !n.isRead).length;

  const getNotifIcon = (type: string, reactionEmoji?: string) => {
    if (reactionEmoji) {
      return (
        <span className="w-5 h-5 rounded-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-xs shadow-xs">
          {reactionEmoji}
        </span>
      );
    }
    switch (type) {
      case 'like_post':
        return <Heart className="w-4 h-4 text-red-500 fill-red-500" />;
      case 'comment_post':
      case 'react_comment':
        return <MessageCircle className="w-4 h-4 text-blue-500" />;
      case 'friend_request':
      case 'friend_accept':
        return <UserPlus className="w-4 h-4 text-emerald-500" />;
      case 'share_post':
        return <Share2 className="w-4 h-4 text-purple-500" />;
      case 'system':
        return <Shield className="w-4 h-4 text-blue-500" />;
      default:
        return <Bell className="w-4 h-4 text-blue-500" />;
    }
  };

  const handleNotificationClick = (notif: typeof notifications[0]) => {
    markNotificationAsRead(notif.id);
    if (notif.type === 'friend_request' || notif.type === 'friend_accept') {
      setActiveTab('friends');
    } else if (notif.type === 'react_story') {
      setActiveTab('feed');
    } else if (notif.targetId?.startsWith('reel')) {
      setActiveTab('reels');
    } else {
      setActiveTab('feed');
    }
    onClose();
  };

  return (
    <div className="absolute right-0 top-full mt-2 w-80 sm:w-96 bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden z-50 animate-in fade-in zoom-in-95 duration-150">
      {/* Header */}
      <div className="p-4 pb-3 border-b border-slate-100 dark:border-slate-800">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center space-x-2">
            <h3 className="font-bold text-slate-900 dark:text-white text-lg">
              {language === 'bn' ? 'বিজ্ঞপ্তি ও অ্যালার্ট' : 'Activity Alerts'}
            </h3>
            {unreadCount > 0 && (
              <span className="px-2 py-0.5 text-xs font-semibold bg-red-500 text-white rounded-full">
                {unreadCount}
              </span>
            )}
          </div>

          <div className="flex items-center space-x-1">
            {unreadCount > 0 && (
              <button
                onClick={markAllNotificationsAsRead}
                className="text-xs text-blue-600 dark:text-blue-400 hover:underline font-medium flex items-center space-x-1 px-2 py-1 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                title="Mark all as read"
              >
                <CheckCheck className="w-3.5 h-3.5" />
                <span>{language === 'bn' ? 'সব পঠিত' : 'Mark all read'}</span>
              </button>
            )}
            <button
              onClick={onClose}
              className="p-1 rounded-full text-slate-400 hover:text-slate-600 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Filter Pills with comment & reaction categories */}
        <div className="flex items-center space-x-1.5 overflow-x-auto pb-1 scrollbar-none">
          <button
            onClick={() => setFilter('all')}
            className={`px-2.5 py-1 text-xs font-medium rounded-full whitespace-nowrap transition-colors ${
              filter === 'all'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
            }`}
          >
            {language === 'bn' ? 'সব' : 'All'}
          </button>
          <button
            onClick={() => setFilter('unread')}
            className={`px-2.5 py-1 text-xs font-medium rounded-full whitespace-nowrap transition-colors ${
              filter === 'unread'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
            }`}
          >
            {language === 'bn' ? 'অপঠিত' : 'Unread'} {unreadCount > 0 ? `(${unreadCount})` : ''}
          </button>
          <button
            onClick={() => setFilter('reactions')}
            className={`px-2.5 py-1 text-xs font-medium rounded-full whitespace-nowrap transition-colors ${
              filter === 'reactions'
                ? 'bg-red-500 text-white shadow-xs'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
            }`}
          >
            ❤️ {language === 'bn' ? 'রিঅ্যাকশন' : 'Reactions'}
          </button>
          <button
            onClick={() => setFilter('comments')}
            className={`px-2.5 py-1 text-xs font-medium rounded-full whitespace-nowrap transition-colors ${
              filter === 'comments'
                ? 'bg-indigo-600 text-white shadow-xs'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
            }`}
          >
            💬 {language === 'bn' ? 'মন্তব্য' : 'Comments'}
          </button>
        </div>

        {/* Quick Simulator Bar for testing comments & reactions */}
        <div className="flex items-center justify-between mt-2 pt-2 border-t border-slate-100 dark:border-slate-800/80 text-[11px] text-slate-500">
          <span className="font-semibold text-slate-600 dark:text-slate-400">
            {language === 'bn' ? 'অ্যালার্ট পরীক্ষা করুন:' : 'Test Alert:'}
          </span>
          <div className="flex items-center space-x-1.5">
            <button
              onClick={() => triggerActivityAlert('reaction')}
              className="px-2 py-0.5 rounded-md bg-red-50 dark:bg-red-950/40 text-red-600 dark:text-red-400 hover:bg-red-100 dark:hover:bg-red-900/60 font-medium transition-colors"
              title="Simulate Reaction on your post"
            >
              ❤️ {language === 'bn' ? '+ রিঅ্যাকশন' : '+ Reaction'}
            </button>
            <button
              onClick={() => triggerActivityAlert('comment')}
              className="px-2 py-0.5 rounded-md bg-blue-50 dark:bg-blue-950/40 text-blue-600 dark:text-blue-400 hover:bg-blue-100 dark:hover:bg-blue-900/60 font-medium transition-colors"
              title="Simulate Comment on your post"
            >
              💬 {language === 'bn' ? '+ মন্তব্য' : '+ Comment'}
            </button>
          </div>
        </div>
      </div>

      {/* Notification List */}
      <div className="max-h-96 overflow-y-auto divide-y divide-slate-100 dark:divide-slate-800/60">
        {filteredNotifs.length === 0 ? (
          <div className="py-10 text-center text-slate-400 dark:text-slate-500">
            <Bell className="w-8 h-8 mx-auto mb-2 opacity-40" />
            <p className="text-xs">
              {language === 'bn' ? 'কোনো নতুন বিজ্ঞপ্তি নেই' : 'No notifications to display'}
            </p>
          </div>
        ) : (
          filteredNotifs.map((notif) => (
            <div
              key={notif.id}
              onClick={() => handleNotificationClick(notif)}
              className={`p-3.5 flex items-start space-x-3 cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800/60 transition-colors ${
                !notif.isRead ? 'bg-blue-50/50 dark:bg-blue-950/20' : ''
              }`}
            >
              {/* Avatar with type badge */}
              <div className="relative flex-shrink-0">
                <img
                  src={notif.senderAvatar}
                  alt={notif.senderName}
                  className="w-10 h-10 rounded-full object-cover ring-1 ring-slate-200 dark:ring-slate-700"
                />
                <div className="absolute -bottom-1 -right-1 bg-white dark:bg-slate-900 rounded-full p-0.5 shadow-sm">
                  {getNotifIcon(notif.type, notif.reactionEmoji)}
                </div>
              </div>

              {/* Text content */}
              <div className="flex-1 min-w-0">
                <p className="text-xs text-slate-800 dark:text-slate-200 leading-snug">
                  <strong className="font-semibold text-slate-900 dark:text-white">
                    {notif.senderName}
                  </strong>{' '}
                  {notif.text}
                </p>
                <span className="text-[10px] text-blue-600 dark:text-blue-400 font-medium mt-1 inline-block">
                  {notif.createdAt}
                </span>
              </div>

              {/* Unread dot */}
              {!notif.isRead && (
                <div className="w-2.5 h-2.5 rounded-full bg-blue-600 flex-shrink-0 self-center" />
              )}
            </div>
          ))
        )}
      </div>

      {/* Footer */}
      <div className="p-2.5 bg-slate-50 dark:bg-slate-900/80 border-t border-slate-100 dark:border-slate-800 text-center">
        <button
          onClick={onClose}
          className="text-xs text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 font-medium"
        >
          {language === 'bn' ? 'বন্ধ করুন' : 'Close'}
        </button>
      </div>
    </div>
  );
};
