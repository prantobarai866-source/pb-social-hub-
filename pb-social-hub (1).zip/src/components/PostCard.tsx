import React, { useState } from 'react';
import { Post, ReactionType, PostComment } from '../types';
import { useApp } from '../context/AppContext';
import { ShareModal } from './ShareModal';
import { EmojiPicker } from './EmojiPicker';
import { ImageLightboxModal } from './ImageLightboxModal';
import {
  Heart,
  MessageCircle,
  Share2,
  MoreHorizontal,
  Trash2,
  UserX,
  Smile,
  Send,
  CheckCircle2,
  Globe,
  Clock,
  Pin,
  Bookmark,
  BarChart2,
  Check,
  ImageIcon,
  Video,
  FileText,
  Maximize2,
} from 'lucide-react';

const REACTION_EMOJIS: Record<ReactionType, { emoji: string; label: string; color: string }> = {
  like: { emoji: '👍', label: 'Like', color: 'text-blue-600' },
  love: { emoji: '❤️', label: 'Love', color: 'text-red-500' },
  care: { emoji: '🥰', label: 'Care', color: 'text-amber-500' },
  haha: { emoji: '😂', label: 'Haha', color: 'text-yellow-500' },
  wow: { emoji: '😮', label: 'Wow', color: 'text-amber-500' },
  sad: { emoji: '😢', label: 'Sad', color: 'text-yellow-600' },
  angry: { emoji: '😡', label: 'Angry', color: 'text-orange-600' },
};

const COMMENT_REACTIONS: { type: ReactionType; emoji: string; label: string }[] = [
  { type: 'love', emoji: '❤️', label: 'Love' },
  { type: 'haha', emoji: '😂', label: 'Haha' },
  { type: 'wow', emoji: '😮', label: 'Wow' },
  { type: 'sad', emoji: '😢', label: 'Sad' },
  { type: 'angry', emoji: '😡', label: 'Angry' },
  { type: 'like', emoji: '👍', label: 'Like' },
];

interface PostCardProps {
  post: Post;
  onViewProfile?: (userId: string) => void;
}

export const PostCard: React.FC<PostCardProps> = ({ post, onViewProfile }) => {
  const {
    currentUser,
    deletePost,
    togglePostReaction,
    addComment,
    toggleCommentReaction,
    blockUser,
    isPostSaved,
    toggleSavePost,
    votePoll,
    language,
  } = useApp();

  const [showMenu, setShowMenu] = useState(false);
  const [showShareModal, setShowShareModal] = useState(false);
  const [showReactionsTray, setShowReactionsTray] = useState(false);
  const [commentText, setCommentText] = useState('');
  const [showCommentEmojiPicker, setShowCommentEmojiPicker] = useState(false);
  const [hoveredCommentId, setHoveredCommentId] = useState<string | null>(null);
  const [lightboxImage, setLightboxImage] = useState<string | null>(null);

  const isOwnPost = post.userId === currentUser.id;
  const isSaved = isPostSaved(post.id);

  const totalReactions = Object.values(post.reactions).reduce((a, b) => a + b, 0);

  // Top reaction emojis
  const activeReactions = (Object.keys(post.reactions) as ReactionType[])
    .filter((k) => post.reactions[k] > 0)
    .sort((a, b) => post.reactions[b] - post.reactions[a])
    .slice(0, 3);

  const handlePostComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!commentText.trim()) return;
    addComment(post.id, commentText);
    setCommentText('');
    setShowCommentEmojiPicker(false);
  };

  return (
    <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-sm border border-slate-200 dark:border-slate-800 mb-4 overflow-visible transition-all">
      {/* Pinned post banner */}
      {post.isPinned && (
        <div className="px-4 pt-3 pb-1 flex items-center space-x-1 text-xs font-semibold text-blue-600 dark:text-blue-400">
          <Pin className="w-3.5 h-3.5" />
          <span>{language === 'bn' ? 'পিন করা পোস্ট' : 'Pinned Post'}</span>
        </div>
      )}

      {/* Post Header */}
      <div className="p-4 pb-3 flex items-start justify-between">
        <div className="flex items-center space-x-3">
          <button
            onClick={() => onViewProfile && onViewProfile(post.userId)}
            className="relative group focus:outline-none"
          >
            <img
              src={post.userAvatar}
              alt={post.userName}
              className="w-10 h-10 rounded-full object-cover ring-1 ring-slate-200 dark:ring-slate-700 group-hover:ring-blue-500 transition-all"
            />
          </button>
          <div>
            <div className="flex items-center space-x-1.5 flex-wrap">
              <button
                onClick={() => onViewProfile && onViewProfile(post.userId)}
                className="font-semibold text-sm text-slate-900 dark:text-white hover:underline focus:outline-none"
              >
                {post.userName}
              </button>
              {post.userVerified && (
                <CheckCircle2 className="w-3.5 h-3.5 text-blue-500 fill-blue-500 text-white" />
              )}
              {post.groupName && (
                <span className="text-xs text-slate-500 dark:text-slate-400">
                  in <span className="font-semibold text-slate-700 dark:text-slate-300">{post.groupName}</span>
                </span>
              )}
              {isSaved && (
                <span className="inline-flex items-center text-amber-500 ml-1" title="Saved Item">
                  <Bookmark className="w-3.5 h-3.5 fill-amber-500" />
                </span>
              )}
            </div>
            <div className="flex items-center space-x-1.5 text-xs text-slate-400 dark:text-slate-500 mt-0.5 flex-wrap gap-y-0.5">
              <span>{post.createdAt}</span>
              <span>·</span>
              <Globe className="w-3 h-3" />
              {post.mediaType === 'image' && post.mediaUrl && (
                <>
                  <span>·</span>
                  <span className="inline-flex items-center space-x-1 px-1.5 py-0.2 rounded-md bg-blue-50 dark:bg-blue-950/40 text-blue-600 dark:text-blue-400 font-semibold text-[10px]">
                    <ImageIcon className="w-2.5 h-2.5" />
                    <span>{language === 'bn' ? 'ছবি' : 'Photo'}</span>
                  </span>
                </>
              )}
              {post.mediaType === 'video' && post.mediaUrl && (
                <>
                  <span>·</span>
                  <span className="inline-flex items-center space-x-1 px-1.5 py-0.2 rounded-md bg-purple-50 dark:bg-purple-950/40 text-purple-600 dark:text-purple-400 font-semibold text-[10px]">
                    <Video className="w-2.5 h-2.5" />
                    <span>{language === 'bn' ? 'ভিডিও' : 'Video'}</span>
                  </span>
                </>
              )}
              {!post.mediaUrl && !post.poll && (
                <>
                  <span>·</span>
                  <span className="inline-flex items-center space-x-1 px-1.5 py-0.2 rounded-md bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 dark:text-emerald-400 font-semibold text-[10px]">
                    <FileText className="w-2.5 h-2.5" />
                    <span>{language === 'bn' ? 'স্ট্যাটাস' : 'Status'}</span>
                  </span>
                </>
              )}
              {post.isScheduled && (
                <>
                  <span>·</span>
                  <span className="inline-flex items-center space-x-1 px-1.5 py-0.2 rounded-md bg-amber-100 dark:bg-amber-950/60 text-amber-700 dark:text-amber-300 font-semibold text-[10px]">
                    <Clock className="w-2.5 h-2.5 mr-0.5" />
                    <span>Scheduled</span>
                  </span>
                </>
              )}
            </div>
          </div>
        </div>

        {/* Post Options Menu */}
        <div className="relative">
          <button
            onClick={() => setShowMenu(!showMenu)}
            className="p-2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-full transition-colors"
          >
            <MoreHorizontal className="w-5 h-5" />
          </button>

          {showMenu && (
            <div className="absolute right-0 top-full mt-1 w-52 bg-white dark:bg-slate-800 rounded-xl shadow-xl border border-slate-200 dark:border-slate-700 py-1.5 z-40 animate-in fade-in zoom-in-95 duration-100">
              {/* Save / Bookmark Post option */}
              <button
                onClick={() => {
                  toggleSavePost(post.id);
                  setShowMenu(false);
                }}
                className="w-full px-4 py-2 text-left text-xs font-medium text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 flex items-center space-x-2"
              >
                <Bookmark
                  className={`w-4 h-4 ${
                    isSaved ? 'text-amber-500 fill-amber-500' : 'text-slate-500'
                  }`}
                />
                <span>
                  {isSaved
                    ? language === 'bn'
                      ? 'সংরক্ষণ তালিকা থেকে মুছুন'
                      : 'Remove from Saved'
                    : language === 'bn'
                    ? 'পোস্ট সংরক্ষণ করুন'
                    : 'Save post'}
                </span>
              </button>

              <button
                onClick={() => {
                  setShowShareModal(true);
                  setShowMenu(false);
                }}
                className="w-full px-4 py-2 text-left text-xs font-medium text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 flex items-center space-x-2"
              >
                <Share2 className="w-4 h-4 text-blue-500" />
                <span>{language === 'bn' ? 'শেয়ার করুন' : 'Share post'}</span>
              </button>

              {!isOwnPost && (
                <button
                  onClick={() => {
                    blockUser(post.userId);
                    setShowMenu(false);
                  }}
                  className="w-full px-4 py-2 text-left text-xs font-medium text-amber-600 dark:text-amber-400 hover:bg-amber-50 dark:hover:bg-amber-950/40 flex items-center space-x-2"
                >
                  <UserX className="w-4 h-4" />
                  <span>{language === 'bn' ? 'ব্যবহারকারী ব্লক করুন' : 'Block User'}</span>
                </button>
              )}

              {isOwnPost && (
                <button
                  onClick={() => {
                    deletePost(post.id);
                    setShowMenu(false);
                  }}
                  className="w-full px-4 py-2 text-left text-xs font-medium text-red-600 hover:bg-red-50 dark:hover:bg-red-950/40 flex items-center space-x-2"
                >
                  <Trash2 className="w-4 h-4" />
                  <span>{language === 'bn' ? 'পোস্ট ডিলিট করুন' : 'Delete post'}</span>
                </button>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Post Text */}
      {post.bgGradient ? (
        <div
          className={`mx-4 my-2.5 p-7 rounded-2xl ${post.bgGradient} flex items-center justify-center text-center shadow-md min-h-[140px]`}
        >
          <p className="text-base sm:text-lg font-bold text-white drop-shadow-md whitespace-pre-wrap break-words leading-relaxed max-w-lg">
            {post.content}
          </p>
        </div>
      ) : (
        <div className="px-4 py-1 text-sm text-slate-800 dark:text-slate-200 whitespace-pre-wrap break-words leading-relaxed font-normal">
          {post.content}
        </div>
      )}

      {/* Interactive Poll with Real-Time Vote Distribution Bars */}
      {post.poll && (
        <div className="mx-4 my-3 p-4 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200/80 dark:border-slate-700/60 space-y-3">
          <div className="flex items-start justify-between">
            <div className="flex items-center space-x-2">
              <div className="w-7 h-7 rounded-lg bg-blue-100 dark:bg-blue-950/50 text-blue-600 flex items-center justify-center">
                <BarChart2 className="w-4 h-4" />
              </div>
              <h4 className="font-bold text-sm text-slate-900 dark:text-white">
                {post.poll.question}
              </h4>
            </div>
            <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300">
              Poll
            </span>
          </div>

          <div className="space-y-2">
            {post.poll.options.map((option) => {
              const percentage =
                post.poll!.totalVotes > 0
                  ? Math.round((option.votes / post.poll!.totalVotes) * 100)
                  : 0;
              const isSelected = post.poll!.userVotedOptionId === option.id;

              return (
                <button
                  key={option.id}
                  onClick={() => votePoll(post.id, option.id)}
                  className={`w-full relative overflow-hidden rounded-xl border p-3 text-left transition-all group ${
                    isSelected
                      ? 'border-blue-500 bg-blue-50/40 dark:bg-blue-950/30 ring-1 ring-blue-500'
                      : 'border-slate-200 dark:border-slate-700 hover:border-slate-300 dark:hover:border-slate-600 bg-white dark:bg-slate-900'
                  }`}
                >
                  {/* Real-time vote distribution progress bar */}
                  <div
                    className={`absolute top-0 bottom-0 left-0 transition-all duration-500 ease-out rounded-xl ${
                      isSelected
                        ? 'bg-blue-500/20 dark:bg-blue-500/30'
                        : 'bg-slate-200/60 dark:bg-slate-700/50'
                    }`}
                    style={{ width: `${percentage}%` }}
                  />

                  {/* Option label & percentage indicator */}
                  <div className="relative z-10 flex items-center justify-between">
                    <div className="flex items-center space-x-2.5">
                      <div
                        className={`w-4 h-4 rounded-full border flex items-center justify-center transition-colors ${
                          isSelected
                            ? 'border-blue-600 bg-blue-600 text-white'
                            : 'border-slate-400 group-hover:border-slate-600'
                        }`}
                      >
                        {isSelected && <Check className="w-2.5 h-2.5 stroke-[3]" />}
                      </div>
                      <span className="text-xs font-semibold text-slate-800 dark:text-slate-200">
                        {option.text}
                      </span>
                    </div>

                    <div className="flex items-center space-x-2">
                      <span className="text-xs font-bold text-slate-700 dark:text-slate-300">
                        {percentage}%
                      </span>
                      <span className="text-[10px] text-slate-400">
                        ({option.votes})
                      </span>
                    </div>
                  </div>
                </button>
              );
            })}
          </div>

          <div className="flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400 pt-1">
            <span>
              {post.poll.totalVotes} {post.poll.totalVotes === 1 ? 'vote' : 'votes'} total
            </span>
            {post.poll.userVotedOptionId && (
              <span className="text-blue-600 dark:text-blue-400 font-medium">
                {language === 'bn' ? '✓ আপনার ভোট গৃহীত হয়েছে' : '✓ Vote recorded'}
              </span>
            )}
          </div>
        </div>
      )}

      {/* Media Attachment (Photo or Video) */}
      {post.mediaUrl && (
        <div className="relative mt-3 bg-black/5 dark:bg-black/40 overflow-hidden border-y border-slate-100 dark:border-slate-800/80 group">
          {post.mediaType === 'video' ? (
            <video
              src={post.mediaUrl}
              controls
              playsInline
              preload="metadata"
              className="w-full max-h-[500px] object-contain mx-auto bg-black"
            />
          ) : (
            <div
              className="relative cursor-pointer overflow-hidden"
              onClick={() => setLightboxImage(post.mediaUrl || null)}
              title={language === 'bn' ? 'ক্লিক করে পুরো ছবি দেখুন' : 'Click to view full photo'}
            >
              <img
                src={post.mediaUrl}
                alt="Post content"
                className="w-full max-h-[550px] object-cover mx-auto transition-transform duration-300 group-hover:scale-[1.01]"
                loading="lazy"
              />
              <div className="absolute bottom-3 right-3 opacity-0 group-hover:opacity-100 transition-opacity bg-black/70 backdrop-blur-md text-white text-[11px] font-semibold px-2.5 py-1 rounded-full flex items-center space-x-1.5 shadow-md">
                <Maximize2 className="w-3.5 h-3.5" />
                <span>{language === 'bn' ? 'বড় দেখুন' : 'Full View'}</span>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Fullscreen Photo Lightbox Modal */}
      {lightboxImage && (
        <ImageLightboxModal
          imageUrl={lightboxImage}
          caption={post.content}
          onClose={() => setLightboxImage(null)}
        />
      )}

      {/* Post Metrics Stats Row */}
      <div className="px-4 py-2.5 flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 border-b border-slate-100 dark:border-slate-800">
        <div className="flex items-center space-x-1.5">
          {activeReactions.length > 0 && (
            <div className="flex items-center -space-x-1">
              {activeReactions.map((r) => (
                <span
                  key={r}
                  className="inline-flex items-center justify-center w-5 h-5 rounded-full bg-white dark:bg-slate-800 shadow-xs text-xs"
                >
                  {REACTION_EMOJIS[r].emoji}
                </span>
              ))}
            </div>
          )}
          <span>{totalReactions > 0 ? totalReactions : ''}</span>
        </div>

        <div className="flex items-center space-x-3 text-xs">
          <span>
            {post.commentsCount} {language === 'bn' ? 'টি মন্তব্য' : 'comments'}
          </span>
          <span>·</span>
          <span>
            {post.sharesCount} {language === 'bn' ? 'টি শেয়ার' : 'shares'}
          </span>
        </div>
      </div>

      {/* Action Buttons Row with Reaction Hover Drawer */}
      <div className="relative px-2 py-1 flex items-center justify-between border-b border-slate-100 dark:border-slate-800">
        {/* Floating Reaction Selector Tray */}
        {showReactionsTray && (
          <div
            onMouseLeave={() => setShowReactionsTray(false)}
            className="absolute left-2 -top-12 z-30 bg-white dark:bg-slate-800 rounded-full shadow-2xl border border-slate-200 dark:border-slate-700 px-3 py-1.5 flex items-center space-x-2 animate-in fade-in slide-in-from-bottom-2 duration-150"
          >
            {(Object.keys(REACTION_EMOJIS) as ReactionType[]).map((r) => (
              <button
                key={r}
                onClick={() => {
                  togglePostReaction(post.id, r);
                  setShowReactionsTray(false);
                }}
                className="w-8 h-8 flex items-center justify-center text-2xl hover:scale-125 active:scale-95 transition-transform"
                title={REACTION_EMOJIS[r].label}
              >
                {REACTION_EMOJIS[r].emoji}
              </button>
            ))}
          </div>
        )}

        {/* Reaction trigger button */}
        <button
          onMouseEnter={() => setShowReactionsTray(true)}
          onClick={() => togglePostReaction(post.id, post.userReaction || 'like')}
          className={`flex-1 flex items-center justify-center space-x-2 py-2 rounded-xl text-xs font-semibold hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors ${
            post.userReaction
              ? REACTION_EMOJIS[post.userReaction].color
              : 'text-slate-600 dark:text-slate-400'
          }`}
        >
          {post.userReaction ? (
            <>
              <span className="text-base">{REACTION_EMOJIS[post.userReaction].emoji}</span>
              <span>{REACTION_EMOJIS[post.userReaction].label}</span>
            </>
          ) : (
            <>
              <Heart className="w-4 h-4" />
              <span>{language === 'bn' ? 'লাইক' : 'Like'}</span>
            </>
          )}
        </button>

        {/* Comment button */}
        <button
          onClick={() => {
            const el = document.getElementById(`comment_input_${post.id}`);
            el?.focus();
          }}
          className="flex-1 flex items-center justify-center space-x-2 py-2 rounded-xl text-xs font-semibold text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
        >
          <MessageCircle className="w-4 h-4" />
          <span>{language === 'bn' ? 'মন্তব্য' : 'Comment'}</span>
        </button>

        {/* Share button */}
        <button
          onClick={() => setShowShareModal(true)}
          className="flex-1 flex items-center justify-center space-x-2 py-2 rounded-xl text-xs font-semibold text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
        >
          <Share2 className="w-4 h-4" />
          <span>{language === 'bn' ? 'শেয়ার' : 'Share'}</span>
        </button>
      </div>

      {/* Comments Section */}
      <div className="p-4 bg-slate-50/50 dark:bg-slate-900/40 space-y-3">
        {/* Comment List */}
        {post.comments && post.comments.length > 0 && (
          <div className="space-y-3">
            {post.comments.map((comment) => {
              const hasReaction = Boolean(comment.userReaction);
              const commentReactionObj = comment.userReaction
                ? REACTION_EMOJIS[comment.userReaction]
                : null;

              return (
                <div
                  key={comment.id}
                  className="flex items-start space-x-2.5 group/comm relative"
                  onMouseEnter={() => setHoveredCommentId(comment.id)}
                  onMouseLeave={() => setHoveredCommentId(null)}
                >
                  <img
                    src={comment.userAvatar}
                    alt={comment.userName}
                    className="w-8 h-8 rounded-full object-cover ring-1 ring-slate-200 dark:ring-slate-700 flex-shrink-0 mt-0.5"
                  />

                  <div className="flex-1 min-w-0">
                    <div className="relative inline-block bg-slate-100 dark:bg-slate-800 px-3.5 py-2 rounded-2xl max-w-full">
                      <p className="font-semibold text-xs text-slate-900 dark:text-white">
                        {comment.userName}
                      </p>
                      <p className="text-xs text-slate-700 dark:text-slate-300 mt-0.5 whitespace-pre-wrap break-words">
                        {comment.content}
                      </p>

                      {/* Comment Reaction Counter Badge */}
                      {comment.likesCount > 0 && (
                        <div className="absolute -bottom-2 right-2 bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 rounded-full px-1.5 py-0.5 shadow-sm flex items-center space-x-1">
                          <Heart className="w-2.5 h-2.5 text-red-500 fill-red-500" />
                          <span className="text-[10px] font-semibold text-slate-600 dark:text-slate-300">
                            {comment.likesCount}
                          </span>
                        </div>
                      )}
                    </div>

                    {/* Comment Footer: Reactions & Time */}
                    <div className="flex items-center space-x-3 mt-1 ml-2 text-[11px] font-medium text-slate-500 dark:text-slate-400">
                      {/* Reaction trigger for Comment */}
                      <div className="relative inline-block">
                        <button
                          onClick={() =>
                            toggleCommentReaction(
                              post.id,
                              comment.id,
                              comment.userReaction || 'love'
                            )
                          }
                          className={`hover:underline font-semibold transition-colors ${
                            hasReaction
                              ? commentReactionObj?.color || 'text-red-500'
                              : 'hover:text-slate-800 dark:hover:text-slate-200'
                          }`}
                        >
                          {hasReaction ? (
                            <span>
                              {commentReactionObj?.emoji} {commentReactionObj?.label}
                            </span>
                          ) : (
                            <span className="flex items-center space-x-1">
                              <Heart className="w-3 h-3 text-slate-400" />
                              <span>{language === 'bn' ? 'লাইক/লাভ' : 'Love'}</span>
                            </span>
                          )}
                        </button>

                        {/* Comment Reaction Hover Popover with Love, Haha, Wow, Sad, Angry, Like */}
                        {hoveredCommentId === comment.id && (
                          <div className="absolute left-0 -top-8 z-40 bg-white dark:bg-slate-800 rounded-full shadow-xl border border-slate-200 dark:border-slate-700 px-2 py-1 flex items-center space-x-1 animate-in fade-in zoom-in-95 duration-100">
                            {COMMENT_REACTIONS.map((cr) => (
                              <button
                                key={cr.type}
                                onClick={() =>
                                  toggleCommentReaction(post.id, comment.id, cr.type)
                                }
                                className="w-6 h-6 flex items-center justify-center text-base hover:scale-125 active:scale-90 transition-transform"
                                title={cr.label}
                              >
                                {cr.emoji}
                              </button>
                            ))}
                          </div>
                        )}
                      </div>

                      <span>·</span>
                      <span>{comment.createdAt}</span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* Comment Input Box */}
        <form onSubmit={handlePostComment} className="flex items-center space-x-2 pt-1 relative">
          <img
            src={currentUser.avatar}
            alt={currentUser.name}
            className="w-8 h-8 rounded-full object-cover ring-1 ring-slate-200 dark:ring-slate-700 flex-shrink-0"
          />

          <div className="flex-1 relative flex items-center">
            <input
              id={`comment_input_${post.id}`}
              type="text"
              value={commentText}
              onChange={(e) => setCommentText(e.target.value)}
              placeholder={language === 'bn' ? 'একটি মন্তব্য লিখুন...' : 'Write a comment...'}
              className="w-full bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-white placeholder-slate-400 text-xs rounded-full pl-4 pr-16 py-2 border-none focus:outline-none focus:ring-2 focus:ring-blue-500"
            />

            <div className="absolute right-2 flex items-center space-x-1">
              <button
                type="button"
                onClick={() => setShowCommentEmojiPicker(!showCommentEmojiPicker)}
                className="p-1 text-slate-400 hover:text-amber-500 transition-colors"
                title="Insert emoji"
              >
                <Smile className="w-4 h-4" />
              </button>

              <button
                type="submit"
                disabled={!commentText.trim()}
                className="p-1 text-blue-600 disabled:opacity-40 hover:text-blue-700 transition-colors"
              >
                <Send className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Comment Emoji Picker */}
          {showCommentEmojiPicker && (
            <div className="absolute bottom-full right-0 mb-2 z-50">
              <EmojiPicker
                onSelect={(emoji) => {
                  setCommentText((prev) => prev + emoji);
                }}
                onClose={() => setShowCommentEmojiPicker(false)}
              />
            </div>
          )}
        </form>
      </div>

      {/* Share Modal */}
      <ShareModal
        post={post}
        isOpen={showShareModal}
        onClose={() => setShowShareModal(false)}
      />
    </div>
  );
};
