import React, { useState, useRef } from 'react';
import { useApp } from '../context/AppContext';
import { PostCard } from './PostCard';
import { CreatePostBox } from './CreatePostBox';
import { GoogleLogo } from './GoogleAuthModal';
import {
  Camera,
  Edit3,
  MapPin,
  Briefcase,
  GraduationCap,
  Calendar,
  Check,
  UserPlus,
  UserCheck,
  UserX,
  Phone,
  Video,
  MessageSquare,
  Sparkles,
  Image as ImageIcon,
  Film,
  Users,
  Grid,
  Bookmark,
  BookmarkCheck,
  Settings,
} from 'lucide-react';

const COVER_PRESETS = [
  'https://images.unsplash.com/photo-1707343843437-caacff5cfa74?w=1400&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1579546929518-9e396f3cc809?w=1400&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1506744038136-46273834b3fb?w=1400&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=1400&auto=format&fit=crop&q=80',
];

interface ProfileViewProps {
  userId?: string;
}

export const ProfileView: React.FC<ProfileViewProps> = ({ userId }) => {
  const {
    currentUser,
    setCurrentUser,
    friends,
    posts,
    reels,
    savedPostIds,
    blockUser,
    sendFriendRequest,
    startCall,
    setActiveChatUser,
    language,
    setActiveTab,
    setIsSettingsModalOpen,
    setIsGoogleAuthModalOpen,
  } = useApp();

  const isOwnProfile = !userId || userId === currentUser.id;
  const profileUser = isOwnProfile ? currentUser : friends.find((f) => f.id === userId) || currentUser;

  const [activeProfileTab, setActiveProfileTab] = useState<'posts' | 'photos' | 'reels' | 'friends' | 'saved'>('posts');
  const [isEditingBio, setIsEditingBio] = useState(false);
  const [bioInput, setBioInput] = useState(profileUser.bio);
  const [showCoverSelector, setShowCoverSelector] = useState(false);

  const coverInputRef = useRef<HTMLInputElement | null>(null);
  const avatarInputRef = useRef<HTMLInputElement | null>(null);

  const handleCoverUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onloadend = () => {
      setCurrentUser((prev) => ({ ...prev, coverPhoto: reader.result as string }));
    };
    reader.readAsDataURL(file);
  };

  const handleAvatarUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onloadend = () => {
      setCurrentUser((prev) => ({ ...prev, avatar: reader.result as string }));
    };
    reader.readAsDataURL(file);
  };

  const handleSaveBio = () => {
    setCurrentUser((prev) => ({ ...prev, bio: bioInput }));
    setIsEditingBio(false);
  };

  const handleBlockThisUser = () => {
    if (window.confirm(`Are you sure you want to block ${profileUser.name}? Their posts and messages will be hidden.`)) {
      blockUser(profileUser.id);
      setActiveTab('feed');
    }
  };

  const userPosts = posts.filter((p) => p.userId === profileUser.id);
  const userReels = reels.filter((r) => r.userId === profileUser.id);
  const savedPosts = posts.filter((p) => savedPostIds.includes(p.id));
  const isFriend = friends.some((f) => f.id === profileUser.id);

  return (
    <div className="max-w-4xl mx-auto pb-12 space-y-4">
      {/* Header Container */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl overflow-hidden border border-slate-200 dark:border-slate-800 shadow-sm">
        {/* Customizable Wide Cover Banner */}
        <div className="relative h-60 sm:h-72 w-full bg-slate-800 overflow-hidden group">
          <img
            src={profileUser.coverPhoto}
            alt="Cover banner"
            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-102"
          />
          <div className="absolute inset-0 bg-linear-to-b from-black/20 via-transparent to-black/60" />

          {/* Edit Cover Photo Button (Owner only) */}
          {isOwnProfile && (
            <div className="absolute bottom-4 right-4 flex items-center space-x-2">
              <button
                onClick={() => setShowCoverSelector(!showCoverSelector)}
                className="flex items-center space-x-1.5 px-4 py-2 bg-white/90 dark:bg-slate-900/90 hover:bg-white dark:hover:bg-slate-900 backdrop-blur-md text-slate-900 dark:text-white rounded-xl text-xs font-semibold shadow-md transition-all active:scale-95"
              >
                <Camera className="w-4 h-4 text-blue-600" />
                <span>{language === 'bn' ? 'কভার পরিবর্তন' : 'Edit Cover Photo'}</span>
              </button>

              <button
                onClick={() => coverInputRef.current?.click()}
                className="p-2 bg-white/90 dark:bg-slate-900/90 hover:bg-white dark:hover:bg-slate-900 backdrop-blur-md text-slate-900 dark:text-white rounded-xl shadow-md transition-all active:scale-95"
                title="Upload file"
              >
                <ImageIcon className="w-4 h-4 text-emerald-600" />
              </button>

              <input
                ref={coverInputRef}
                type="file"
                accept="image/*"
                onChange={handleCoverUpload}
                className="hidden"
              />
            </div>
          )}

          {/* Cover Presets Drawer */}
          {showCoverSelector && isOwnProfile && (
            <div className="absolute bottom-16 right-4 p-3 bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 flex items-center space-x-2 z-30 animate-in fade-in zoom-in-95">
              <span className="text-xs font-semibold text-slate-500 mr-1">Presets:</span>
              {COVER_PRESETS.map((url, i) => (
                <button
                  key={i}
                  onClick={() => {
                    setCurrentUser((p) => ({ ...p, coverPhoto: url }));
                    setShowCoverSelector(false);
                  }}
                  className="w-12 h-8 rounded-lg overflow-hidden border-2 border-transparent hover:border-blue-500 focus:border-blue-500 transition-all"
                >
                  <img src={url} className="w-full h-full object-cover" />
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Profile Info Bar */}
        <div className="px-6 pb-6 pt-0 relative">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between -mt-16 sm:-mt-20 gap-4 mb-4">
            {/* Avatar */}
            <div className="relative inline-block self-start">
              <img
                src={profileUser.avatar}
                alt={profileUser.name}
                className="w-32 h-32 sm:w-36 sm:h-36 rounded-full object-cover ring-4 ring-white dark:ring-slate-900 shadow-xl"
              />
              {isOwnProfile && (
                <button
                  onClick={() => avatarInputRef.current?.click()}
                  className="absolute bottom-1 right-1 p-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-full ring-2 ring-white dark:ring-slate-900 shadow-md transition-transform active:scale-95"
                  title="Update profile picture"
                >
                  <Camera className="w-4 h-4" />
                </button>
              )}
              <input
                ref={avatarInputRef}
                type="file"
                accept="image/*"
                onChange={handleAvatarUpload}
                className="hidden"
              />
            </div>

            {/* Profile Actions */}
            <div className="flex items-center space-x-2 flex-wrap gap-2">
              {!isOwnProfile ? (
                <>
                  {/* Friend status */}
                  <button
                    onClick={() => sendFriendRequest(profileUser.id)}
                    className="flex items-center space-x-1.5 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-semibold shadow-sm transition-colors"
                  >
                    {isFriend ? <UserCheck className="w-4 h-4" /> : <UserPlus className="w-4 h-4" />}
                    <span>{isFriend ? 'Friends' : 'Add Friend'}</span>
                  </button>

                  {/* Message */}
                  <button
                    onClick={() => setActiveChatUser(profileUser)}
                    className="flex items-center space-x-1.5 px-4 py-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 rounded-xl text-xs font-semibold transition-colors"
                  >
                    <MessageSquare className="w-4 h-4 text-blue-500" />
                    <span>Message</span>
                  </button>

                  {/* Audio Call */}
                  <button
                    onClick={() => startCall(profileUser, 'audio')}
                    className="p-2.5 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 dark:text-emerald-400 hover:bg-emerald-100 dark:hover:bg-emerald-900/60 rounded-xl transition-colors"
                    title="Audio Call"
                  >
                    <Phone className="w-4 h-4" />
                  </button>

                  {/* Video Call */}
                  <button
                    onClick={() => startCall(profileUser, 'video')}
                    className="p-2.5 bg-pink-50 dark:bg-pink-950/40 text-pink-600 dark:text-pink-400 hover:bg-pink-100 dark:hover:bg-pink-900/60 rounded-xl transition-colors"
                    title="Video Call"
                  >
                    <Video className="w-4 h-4" />
                  </button>

                  {/* Block User Button */}
                  <button
                    onClick={handleBlockThisUser}
                    className="flex items-center space-x-1 px-3 py-2 bg-red-50 dark:bg-red-950/40 text-red-600 hover:bg-red-100 dark:hover:bg-red-900/50 rounded-xl text-xs font-semibold transition-colors"
                    title="Block this user"
                  >
                    <UserX className="w-4 h-4" />
                    <span>{language === 'bn' ? 'ব্লক করুন' : 'Block'}</span>
                  </button>
                </>
              ) : (
                <div className="flex items-center space-x-2">
                  <button
                    onClick={() => setIsEditingBio(!isEditingBio)}
                    className="flex items-center space-x-1.5 px-3.5 py-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 rounded-xl text-xs font-semibold transition-colors"
                  >
                    <Edit3 className="w-4 h-4" />
                    <span>{language === 'bn' ? 'প্রোফাইল এডিট' : 'Edit Profile'}</span>
                  </button>

                  <button
                    onClick={() => setIsSettingsModalOpen(true)}
                    className="flex items-center space-x-1.5 px-3.5 py-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 rounded-xl text-xs font-semibold transition-colors"
                    title="Settings"
                  >
                    <Settings className="w-4 h-4 text-blue-500" />
                    <span>{language === 'bn' ? 'সেটিংস' : 'Settings'}</span>
                  </button>
                </div>
              )}
            </div>
          </div>

          {/* Name, Google Badge & Bio */}
          <div>
            <div className="flex items-center space-x-2 flex-wrap">
              <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white">
                {profileUser.name}
              </h2>

              {isOwnProfile && (
                <button
                  onClick={() => setIsGoogleAuthModalOpen(true)}
                  className="inline-flex items-center space-x-1 px-2.5 py-1 rounded-full bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 border border-slate-200 dark:border-slate-700 text-[11px] font-medium text-slate-700 dark:text-slate-300 transition-colors"
                  title="Google Account"
                >
                  <GoogleLogo className="w-3.5 h-3.5" />
                  <span className="truncate max-w-[170px]">{profileUser.email || 'prantoofficial46@gmail.com'}</span>
                </button>
              )}
            </div>
            <p className="text-xs text-slate-500 font-medium">@{profileUser.username}</p>

            {/* Bio */}
            {isEditingBio ? (
              <div className="mt-3 max-w-lg space-y-2">
                <textarea
                  value={bioInput}
                  onChange={(e) => setBioInput(e.target.value)}
                  rows={2}
                  className="w-full bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-white text-xs rounded-xl p-3 border-none outline-none focus:ring-1 focus:ring-blue-500"
                />
                <div className="flex space-x-2">
                  <button
                    onClick={handleSaveBio}
                    className="px-3.5 py-1.5 bg-blue-600 text-white rounded-lg text-xs font-semibold shadow-xs"
                  >
                    Save Bio
                  </button>
                  <button
                    onClick={() => setIsEditingBio(false)}
                    className="px-3.5 py-1.5 text-xs text-slate-500"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            ) : (
              <p className="mt-2 text-xs sm:text-sm text-slate-700 dark:text-slate-300 max-w-2xl leading-relaxed">
                {profileUser.bio}
              </p>
            )}

            {/* Metadata Badges */}
            <div className="flex flex-wrap items-center gap-x-4 gap-y-2 mt-3 text-xs text-slate-500 dark:text-slate-400">
              {profileUser.work && (
                <div className="flex items-center space-x-1.5">
                  <Briefcase className="w-3.5 h-3.5 text-slate-400" />
                  <span>{profileUser.work}</span>
                </div>
              )}
              {profileUser.location && (
                <div className="flex items-center space-x-1.5">
                  <MapPin className="w-3.5 h-3.5 text-slate-400" />
                  <span>{profileUser.location}</span>
                </div>
              )}
              {profileUser.education && (
                <div className="flex items-center space-x-1.5">
                  <GraduationCap className="w-3.5 h-3.5 text-slate-400" />
                  <span>{profileUser.education}</span>
                </div>
              )}
              <div className="flex items-center space-x-1.5">
                <Calendar className="w-3.5 h-3.5 text-slate-400" />
                <span>Joined {profileUser.joinedDate}</span>
              </div>
            </div>

            {/* Counts */}
            <div className="flex items-center space-x-6 mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 text-xs">
              <div>
                <strong className="font-bold text-slate-900 dark:text-white">
                  {profileUser.friendsCount}
                </strong>{' '}
                <span className="text-slate-500">Friends</span>
              </div>
              <div>
                <strong className="font-bold text-slate-900 dark:text-white">
                  {profileUser.followersCount.toLocaleString()}
                </strong>{' '}
                <span className="text-slate-500">Followers</span>
              </div>
              <div>
                <strong className="font-bold text-slate-900 dark:text-white">
                  {userPosts.length}
                </strong>{' '}
                <span className="text-slate-500">Posts</span>
              </div>
            </div>
          </div>
        </div>

        {/* Profile Navigation Tabs */}
        <div className="flex items-center space-x-1 px-6 border-t border-slate-100 dark:border-slate-800 overflow-x-auto">
          <button
            onClick={() => setActiveProfileTab('posts')}
            className={`py-3 px-4 text-xs font-bold border-b-2 transition-colors ${
              activeProfileTab === 'posts'
                ? 'border-blue-600 text-blue-600 dark:text-blue-400'
                : 'border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
            }`}
          >
            Posts
          </button>
          <button
            onClick={() => setActiveProfileTab('photos')}
            className={`py-3 px-4 text-xs font-bold border-b-2 transition-colors ${
              activeProfileTab === 'photos'
                ? 'border-blue-600 text-blue-600 dark:text-blue-400'
                : 'border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
            }`}
          >
            Photos
          </button>
          <button
            onClick={() => setActiveProfileTab('reels')}
            className={`py-3 px-4 text-xs font-bold border-b-2 transition-colors ${
              activeProfileTab === 'reels'
                ? 'border-blue-600 text-blue-600 dark:text-blue-400'
                : 'border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
            }`}
          >
            Reels ({userReels.length})
          </button>
          <button
            onClick={() => setActiveProfileTab('friends')}
            className={`py-3 px-4 text-xs font-bold border-b-2 transition-colors ${
              activeProfileTab === 'friends'
                ? 'border-blue-600 text-blue-600 dark:text-blue-400'
                : 'border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
            }`}
          >
            Friends
          </button>

          {isOwnProfile && (
            <button
              onClick={() => setActiveProfileTab('saved')}
              className={`py-3 px-4 text-xs font-bold border-b-2 flex items-center space-x-1.5 transition-colors whitespace-nowrap ${
                activeProfileTab === 'saved'
                  ? 'border-blue-600 text-blue-600 dark:text-blue-400'
                  : 'border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
              }`}
            >
              <Bookmark className="w-3.5 h-3.5" />
              <span>
                {language === 'bn'
                  ? `সংরক্ষিত (${savedPosts.length})`
                  : `Saved Items (${savedPosts.length})`}
              </span>
            </button>
          )}
        </div>
      </div>

      {/* Tab Contents */}
      {activeProfileTab === 'posts' && (
        <div className="space-y-4">
          {isOwnProfile && <CreatePostBox placeholder="Write something on your profile..." />}

          {userPosts.length === 0 ? (
            <div className="bg-white dark:bg-slate-900 rounded-2xl p-8 text-center border border-slate-200 dark:border-slate-800 text-slate-400 text-xs">
              No posts shared yet.
            </div>
          ) : (
            userPosts.map((post) => <PostCard key={post.id} post={post} />)
          )}
        </div>
      )}

      {/* Saved Items Tab */}
      {activeProfileTab === 'saved' && (
        <div className="space-y-4">
          <div className="bg-white dark:bg-slate-900 rounded-3xl p-5 border border-slate-200 dark:border-slate-800 shadow-sm flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 rounded-2xl bg-amber-100 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400 flex items-center justify-center">
                <Bookmark className="w-5 h-5 fill-amber-500" />
              </div>
              <div>
                <h3 className="font-bold text-sm text-slate-900 dark:text-white">
                  {language === 'bn' ? 'সংরক্ষিত আইটেম' : 'Saved Items & Bookmarks'}
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  {language === 'bn'
                    ? 'আপনার বুকমার্ক করা সকল পোস্ট এখানে সংরক্ষিত রয়েছে'
                    : 'All posts and content you bookmarked to view later'}
                </p>
              </div>
            </div>
            <span className="text-xs font-bold px-3 py-1 bg-amber-50 dark:bg-amber-950/40 text-amber-700 dark:text-amber-300 rounded-full border border-amber-200 dark:border-amber-900/40">
              {savedPosts.length} {savedPosts.length === 1 ? 'item' : 'items'}
            </span>
          </div>

          {savedPosts.length === 0 ? (
            <div className="bg-white dark:bg-slate-900 rounded-2xl p-12 text-center border border-slate-200 dark:border-slate-800 text-slate-400 text-xs space-y-2">
              <Bookmark className="w-8 h-8 mx-auto text-slate-300 dark:text-slate-600" />
              <p className="font-semibold text-sm text-slate-600 dark:text-slate-300">
                {language === 'bn' ? 'কোনো সংরক্ষিত পোস্ট নেই' : 'No saved posts yet'}
              </p>
              <p className="text-slate-400 max-w-xs mx-auto">
                {language === 'bn'
                  ? 'যেকোনো পোস্টের ৩-ডট মেনু থেকে "পোস্ট সংরক্ষণ করুন" নির্বাচন করুন।'
                  : 'Select "Save post" from any post menu to bookmark content for later reading.'}
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              {savedPosts.map((post) => (
                <PostCard key={post.id} post={post} />
              ))}
            </div>
          )}
        </div>
      )}

      {activeProfileTab === 'photos' && (
        <div className="bg-white dark:bg-slate-900 rounded-3xl p-5 border border-slate-200 dark:border-slate-800 shadow-sm">
          <h3 className="font-bold text-sm text-slate-900 dark:text-white mb-3">Photos</h3>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            {userPosts
              .filter((p) => p.mediaUrl && p.mediaType !== 'video')
              .map((p) => (
                <div key={p.id} className="aspect-square rounded-2xl overflow-hidden bg-slate-100">
                  <img src={p.mediaUrl} className="w-full h-full object-cover hover:scale-105 transition-transform" />
                </div>
              ))}
          </div>
        </div>
      )}

      {activeProfileTab === 'reels' && (
        <div className="bg-white dark:bg-slate-900 rounded-3xl p-5 border border-slate-200 dark:border-slate-800 shadow-sm">
          <h3 className="font-bold text-sm text-slate-900 dark:text-white mb-3">Published Reels</h3>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            {userReels.map((reel) => (
              <div key={reel.id} className="relative aspect-9/16 rounded-2xl overflow-hidden bg-black group">
                <video src={reel.videoUrl} className="w-full h-full object-cover" />
                <div className="absolute inset-0 bg-linear-to-t from-black/80 via-transparent to-transparent flex flex-col justify-end p-3 text-white">
                  <p className="text-xs font-semibold truncate">{reel.caption}</p>
                  <p className="text-[10px] text-white/80">{reel.viewsCount} views</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {activeProfileTab === 'friends' && (
        <div className="bg-white dark:bg-slate-900 rounded-3xl p-5 border border-slate-200 dark:border-slate-800 shadow-sm">
          <h3 className="font-bold text-sm text-slate-900 dark:text-white mb-3">Friends List</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {friends.map((f) => (
              <div
                key={f.id}
                className="flex items-center justify-between p-3 bg-slate-50 dark:bg-slate-800/60 rounded-2xl"
              >
                <div className="flex items-center space-x-3">
                  <img src={f.avatar} className="w-10 h-10 rounded-full object-cover" />
                  <div>
                    <p className="font-bold text-xs text-slate-900 dark:text-white">{f.name}</p>
                    <p className="text-[11px] text-slate-400">@{f.username}</p>
                  </div>
                </div>
                <button
                  onClick={() => setActiveChatUser(f)}
                  className="px-3 py-1.5 bg-blue-50 dark:bg-blue-950/40 text-blue-600 dark:text-blue-400 text-xs font-semibold rounded-xl"
                >
                  Message
                </button>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
