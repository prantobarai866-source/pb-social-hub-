import React from 'react';
import { useApp } from '../context/AppContext';
import { Film, Play, Plus, ChevronRight, Eye, Music } from 'lucide-react';

export const ReelsShelf: React.FC = () => {
  const { reels, setActiveTab, setActiveReelIndex, setIsCreateReelModalOpen, language } = useApp();

  const handleWatchReels = (index = 0) => {
    setActiveReelIndex(index);
    setActiveTab('reels');
  };

  return (
    <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-sm border border-slate-200 dark:border-slate-800 p-4 mb-4 transition-all">
      {/* Shelf Header */}
      <div className="flex items-center justify-between mb-3.5">
        <div className="flex items-center space-x-2.5">
          <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-pink-500 to-rose-600 flex items-center justify-center text-white shadow-sm shadow-pink-500/30">
            <Film className="w-4 h-4" />
          </div>
          <div>
            <h3 className="font-bold text-sm text-slate-900 dark:text-white flex items-center space-x-1.5">
              <span>{language === 'bn' ? 'রিলস ও শর্ট ভিডিও' : 'Reels & Short Videos'}</span>
              <span className="px-1.5 py-0.5 text-[10px] font-bold bg-pink-100 dark:bg-pink-950/60 text-pink-600 dark:text-pink-400 rounded-full">
                {language === 'bn' ? 'ট্রেন্ডিং' : 'Hot'}
              </span>
            </h3>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 hidden sm:block">
              {language === 'bn' ? 'জনপ্রিয় ভিডিওগুলি ঘুরে দেখুন এবং বিনোদন উপভোগ করুন' : 'Watch trending reels and enjoy entertainment'}
            </p>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center space-x-2">
          {/* Main "রিল দেখুন / Watch Reels" button */}
          <button
            onClick={() => handleWatchReels(0)}
            className="flex items-center space-x-1.5 px-3 py-1.5 bg-gradient-to-r from-pink-600 to-rose-600 hover:from-pink-700 hover:to-rose-700 text-white rounded-xl text-xs font-bold shadow-md shadow-pink-600/20 active:scale-95 transition-all"
            title="Watch Reels Stream"
          >
            <Play className="w-3.5 h-3.5 fill-white" />
            <span>{language === 'bn' ? 'রিল দেখুন' : 'Watch Reels'}</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>

          {/* Create Reel shortcut */}
          <button
            onClick={() => setIsCreateReelModalOpen(true)}
            className="hidden sm:flex items-center space-x-1 px-2.5 py-1.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 rounded-xl text-xs font-semibold transition-colors"
            title="Create a Reel"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>{language === 'bn' ? 'নতুন রিল' : 'Create'}</span>
          </button>
        </div>
      </div>

      {/* Horizontal Reels Stream */}
      <div className="flex space-x-3 overflow-x-auto pb-1 scrollbar-thin scrollbar-thumb-slate-200 dark:scrollbar-thumb-slate-700">
        {reels.map((reel, index) => (
          <div
            key={reel.id}
            onClick={() => handleWatchReels(index)}
            className="group relative flex-shrink-0 w-32 sm:w-36 aspect-[9/15] rounded-2xl overflow-hidden cursor-pointer shadow-md bg-slate-900 border border-slate-800/80 hover:scale-[1.03] transition-all duration-200"
          >
            {/* Reel thumbnail or video poster */}
            <img
              src={reel.thumbnailUrl || reel.userAvatar}
              alt={reel.caption}
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
              loading="lazy"
            />

            {/* Gradient Overlays */}
            <div className="absolute inset-0 bg-gradient-to-b from-black/50 via-transparent to-black/80" />

            {/* Top Views count badge */}
            <div className="absolute top-2 left-2 flex items-center space-x-1 bg-black/60 backdrop-blur-md px-1.5 py-0.5 rounded-full text-[10px] font-semibold text-white">
              <Eye className="w-3 h-3 text-pink-400" />
              <span>
                {reel.viewsCount
                  ? reel.viewsCount > 1000
                    ? `${(reel.viewsCount / 1000).toFixed(1)}k`
                    : reel.viewsCount
                  : '1.2k'}
              </span>
            </div>

            {/* Center Play Button Overlay */}
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
              <div className="w-10 h-10 rounded-full bg-white/25 group-hover:bg-pink-600/90 backdrop-blur-md flex items-center justify-center text-white shadow-lg group-hover:scale-110 transition-all duration-200">
                <Play className="w-5 h-5 fill-white ml-0.5" />
              </div>
            </div>

            {/* Bottom Info */}
            <div className="absolute bottom-2 left-2 right-2 text-white">
              <div className="flex items-center space-x-1.5 mb-1">
                <img
                  src={reel.userAvatar}
                  alt={reel.userName}
                  className="w-5 h-5 rounded-full object-cover ring-1 ring-white"
                />
                <span className="text-[11px] font-bold truncate drop-shadow-md">
                  {reel.userName.split(' ')[0]}
                </span>
              </div>
              <p className="text-[10px] text-white/90 line-clamp-1 drop-shadow-sm font-medium">
                {reel.caption}
              </p>
            </div>
          </div>
        ))}

        {/* End of list Card: "সব রিল দেখুন" */}
        <div
          onClick={() => handleWatchReels(0)}
          className="flex-shrink-0 w-28 sm:w-32 aspect-[9/15] rounded-2xl bg-gradient-to-br from-pink-900/40 to-slate-900 border border-dashed border-pink-500/50 hover:border-pink-500 flex flex-col items-center justify-center text-center p-3 cursor-pointer group transition-all"
        >
          <div className="w-10 h-10 rounded-full bg-pink-600 text-white flex items-center justify-center mb-2 shadow-md group-hover:scale-110 transition-transform">
            <Film className="w-5 h-5" />
          </div>
          <span className="text-xs font-bold text-white group-hover:text-pink-300">
            {language === 'bn' ? 'সব রিল দেখুন' : 'Watch All'}
          </span>
          <span className="text-[10px] text-pink-400 mt-1">
            {reels.length} {language === 'bn' ? 'টি ভিডিও' : 'reels'}
          </span>
        </div>
      </div>
    </div>
  );
};
