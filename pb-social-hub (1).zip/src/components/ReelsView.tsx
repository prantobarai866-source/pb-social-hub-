import React, { useState, useRef } from 'react';
import { useApp } from '../context/AppContext';
import { Reel } from '../types';
import {
  Heart,
  MessageCircle,
  Share2,
  Volume2,
  VolumeX,
  Play,
  Pause,
  Music,
  Plus,
  BarChart3,
  TrendingUp,
  Eye,
  Clock,
  Check,
  X,
  Sparkles,
  ChevronUp,
  ChevronDown,
} from 'lucide-react';

export const ReelsView: React.FC = () => {
  const {
    reels,
    addReel,
    toggleReelLike,
    currentUser,
    language,
    activeReelIndex,
    setActiveReelIndex,
  } = useApp();
  const [isMuted, setIsMuted] = useState(false);
  const [isPlaying, setIsPlaying] = useState(true);
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [showInsightsModal, setShowInsightsModal] = useState(false);

  // Upload Form state
  const [uploadVideoUrl, setUploadVideoUrl] = useState('');
  const [uploadCaption, setUploadCaption] = useState('');
  const [uploadAudioTrack, setUploadAudioTrack] = useState('');
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const currentReel = reels[activeReelIndex] || reels[0];

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onloadend = () => {
      setUploadVideoUrl(reader.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handlePublishReel = () => {
    if (!uploadVideoUrl || !uploadCaption) return;
    addReel(uploadVideoUrl, uploadCaption, uploadAudioTrack || `Original Audio - ${currentUser.name}`);
    setUploadVideoUrl('');
    setUploadCaption('');
    setUploadAudioTrack('');
    setShowUploadModal(false);
  };

  // User's published reels for Insights
  const myReels = reels.filter((r) => r.userId === currentUser.id);
  const totalViews = myReels.reduce((acc, r) => acc + (r.viewsCount || 0), 0);
  const totalLikes = myReels.reduce((acc, r) => acc + (r.likesCount || 0), 0);
  const totalShares = myReels.reduce((acc, r) => acc + (r.sharesCount || 0), 0);
  const totalComments = myReels.reduce((acc, r) => acc + (r.commentsCount || 0), 0);

  const handlePrev = () => {
    if (activeReelIndex > 0) {
      setActiveReelIndex(activeReelIndex - 1);
    } else {
      setActiveReelIndex(reels.length - 1);
    }
  };

  const handleNext = () => {
    if (activeReelIndex < reels.length - 1) {
      setActiveReelIndex(activeReelIndex + 1);
    } else {
      setActiveReelIndex(0);
    }
  };

  return (
    <div className="max-w-xl mx-auto py-2">
      {/* Top Header with Create Reel & Insights */}
      <div className="flex items-center justify-between mb-4 bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm">
        <div>
          <h2 className="font-bold text-slate-900 dark:text-white text-lg flex items-center space-x-2">
            <span>{language === 'bn' ? 'রিলস ও শর্ট ভিডিও' : 'Reels'}</span>
            <span className="text-xs px-2 py-0.5 bg-pink-100 dark:bg-pink-950/60 text-pink-600 dark:text-pink-300 font-semibold rounded-full">
              Live
            </span>
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            {language === 'bn' ? 'স্বল্প দৈর্ঘ্যের ভিডিও দেখুন ও আপলোড করুন' : 'Watch & create engaging short videos'}
          </p>
        </div>

        <div className="flex items-center space-x-2">
          {/* Insights Button */}
          <button
            onClick={() => setShowInsightsModal(true)}
            className="flex items-center space-x-1.5 px-3 py-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 rounded-xl text-xs font-semibold transition-colors"
            title="View Reels Insights"
          >
            <BarChart3 className="w-4 h-4 text-purple-500" />
            <span className="hidden sm:inline">
              {language === 'bn' ? 'ইনসাইটস' : 'Insights'}
            </span>
          </button>

          {/* Upload Reel Button */}
          <button
            onClick={() => setShowUploadModal(true)}
            className="flex items-center space-x-1.5 px-3.5 py-2 bg-linear-to-r from-pink-600 to-rose-600 hover:from-pink-700 hover:to-rose-700 text-white rounded-xl text-xs font-semibold shadow-md transition-all active:scale-95"
          >
            <Plus className="w-4 h-4" />
            <span>{language === 'bn' ? 'রিল আপলোড' : 'Create Reel'}</span>
          </button>
        </div>
      </div>

      {/* Main Reels Viewer Card */}
      {currentReel ? (
        <div className="relative w-full aspect-9/16 max-h-[640px] bg-black rounded-3xl overflow-hidden shadow-2xl border border-slate-800 mx-auto select-none">
          {/* Video element */}
          <video
            src={currentReel.videoUrl}
            autoPlay
            loop
            playsInline
            muted={isMuted}
            className="w-full h-full object-cover"
            onClick={() => setIsPlaying(!isPlaying)}
          />

          {/* Top Control Bar */}
          <div className="absolute top-4 left-4 right-4 z-20 flex items-center justify-between text-white">
            <span className="text-xs font-bold bg-black/40 backdrop-blur-md px-3 py-1 rounded-full border border-white/10">
              Reel {activeReelIndex + 1} / {reels.length}
            </span>

            <button
              onClick={() => setIsMuted(!isMuted)}
              className="p-2 rounded-full bg-black/40 hover:bg-black/60 backdrop-blur-md transition-colors"
            >
              {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
            </button>
          </div>

          {/* Right Action Bar */}
          <div className="absolute right-3 bottom-16 z-20 flex flex-col items-center space-y-4 text-white">
            {/* Like */}
            <button
              onClick={() => toggleReelLike(currentReel.id)}
              className="flex flex-col items-center group"
            >
              <div
                className={`p-3 rounded-full backdrop-blur-md transition-all ${
                  currentReel.isLiked
                    ? 'bg-red-500 text-white shadow-lg scale-110'
                    : 'bg-black/40 hover:bg-black/60 text-white'
                }`}
              >
                <Heart
                  className={`w-6 h-6 ${currentReel.isLiked ? 'fill-white' : ''}`}
                />
              </div>
              <span className="text-[11px] font-bold mt-1 drop-shadow-md">
                {currentReel.likesCount}
              </span>
            </button>

            {/* Comments */}
            <button className="flex flex-col items-center">
              <div className="p-3 rounded-full bg-black/40 hover:bg-black/60 backdrop-blur-md transition-colors">
                <MessageCircle className="w-6 h-6" />
              </div>
              <span className="text-[11px] font-bold mt-1 drop-shadow-md">
                {currentReel.commentsCount}
              </span>
            </button>

            {/* Share */}
            <button className="flex flex-col items-center">
              <div className="p-3 rounded-full bg-black/40 hover:bg-black/60 backdrop-blur-md transition-colors">
                <Share2 className="w-6 h-6" />
              </div>
              <span className="text-[11px] font-bold mt-1 drop-shadow-md">
                {currentReel.sharesCount}
              </span>
            </button>
          </div>

          {/* Bottom Info Bar */}
          <div className="absolute left-4 right-16 bottom-4 z-20 text-white">
            <div className="flex items-center space-x-2 mb-2">
              <img
                src={currentReel.userAvatar}
                alt={currentReel.userName}
                className="w-9 h-9 rounded-full object-cover ring-2 ring-white shadow-md"
              />
              <div>
                <p className="font-bold text-xs leading-tight drop-shadow-md">
                  {currentReel.userName}
                </p>
                <p className="text-[10px] text-white/80 drop-shadow-xs">
                  {currentReel.createdAt}
                </p>
              </div>
            </div>

            <p className="text-xs text-white/95 drop-shadow-md mb-2 line-clamp-2">
              {currentReel.caption}
            </p>

            <div className="flex items-center space-x-1.5 text-[11px] text-white/80 bg-black/30 backdrop-blur-md px-2.5 py-1 rounded-full w-fit">
              <Music className="w-3 h-3 animate-spin" />
              <span className="truncate max-w-[200px]">{currentReel.audioTrack}</span>
            </div>
          </div>
        </div>
      ) : (
        <div className="p-8 text-center bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800">
          <p className="text-slate-500 text-sm">No reels uploaded yet.</p>
        </div>
      )}

      {/* Reel Selector & Navigation Buttons */}
      <div className="flex items-center justify-between mt-4 px-2">
        <button
          onClick={handlePrev}
          className="flex items-center space-x-1.5 px-3 py-1.5 rounded-xl bg-white dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 text-xs font-bold border border-slate-200 dark:border-slate-700 shadow-xs transition-colors"
          title="Previous Reel"
        >
          <ChevronUp className="w-4 h-4" />
          <span>{language === 'bn' ? 'পূর্ববর্তী রিল' : 'Previous'}</span>
        </button>

        <div className="flex items-center space-x-2">
          {reels.map((_, idx) => (
            <button
              key={idx}
              onClick={() => setActiveReelIndex(idx)}
              className={`h-2 rounded-full transition-all ${
                activeReelIndex === idx ? 'w-8 bg-pink-600' : 'w-2 bg-slate-300 dark:bg-slate-700'
              }`}
            />
          ))}
        </div>

        <button
          onClick={handleNext}
          className="flex items-center space-x-1.5 px-3 py-1.5 rounded-xl bg-pink-600 hover:bg-pink-700 text-white text-xs font-bold shadow-md shadow-pink-600/20 transition-colors"
          title="Next Reel"
        >
          <span>{language === 'bn' ? 'পরবর্তী রিল' : 'Next'}</span>
          <ChevronDown className="w-4 h-4" />
        </button>
      </div>

      {/* Upload Reel Modal */}
      {showUploadModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 animate-in fade-in duration-150">
          <div className="relative w-full max-w-md bg-white dark:bg-slate-900 rounded-3xl p-5 border border-slate-200 dark:border-slate-800 shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100 dark:border-slate-800">
              <h3 className="font-bold text-slate-900 dark:text-white text-base flex items-center space-x-2">
                <Sparkles className="w-4 h-4 text-pink-500" />
                <span>{language === 'bn' ? 'নতুন রিল আপলোড করুন' : 'Upload New Reel'}</span>
              </h3>
              <button
                onClick={() => setShowUploadModal(false)}
                className="p-1 rounded-full text-slate-400 hover:text-slate-600 hover:bg-slate-100 dark:hover:bg-slate-800"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Video preview / input */}
            {uploadVideoUrl ? (
              <div className="relative aspect-9/16 max-h-64 rounded-2xl overflow-hidden bg-black mx-auto">
                <video src={uploadVideoUrl} controls className="w-full h-full object-cover" />
                <button
                  onClick={() => setUploadVideoUrl('')}
                  className="absolute top-2 right-2 p-1.5 bg-black/70 text-white rounded-full"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
            ) : (
              <div
                onClick={() => fileInputRef.current?.click()}
                className="border-2 border-dashed border-slate-300 dark:border-slate-700 hover:border-pink-500 rounded-2xl p-6 text-center cursor-pointer transition-colors"
              >
                <div className="w-12 h-12 rounded-full bg-pink-50 dark:bg-pink-950/40 text-pink-600 flex items-center justify-center mx-auto mb-2">
                  <Plus className="w-6 h-6" />
                </div>
                <p className="text-xs font-semibold text-slate-800 dark:text-slate-200">
                  {language === 'bn' ? 'ভিডিও ফাইল সিলেক্ট করুন' : 'Click to browse MP4/WebM video'}
                </p>
                <p className="text-[11px] text-slate-400 mt-1">
                  Or select a sample clip to post immediately
                </p>
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    setUploadVideoUrl(
                      'https://assets.mixkit.co/videos/preview/mixkit-hands-of-a-man-working-on-a-computer-keyboard-41314-large.mp4'
                    );
                  }}
                  className="mt-3 px-3 py-1 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-xs font-medium text-slate-700 dark:text-slate-300 rounded-lg"
                >
                  Use High-Res Sample Clip
                </button>
              </div>
            )}

            <input
              ref={fileInputRef}
              type="file"
              accept="video/*"
              onChange={handleFileUpload}
              className="hidden"
            />

            {/* Caption */}
            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                {language === 'bn' ? 'ক্যাপশন' : 'Caption'}
              </label>
              <textarea
                value={uploadCaption}
                onChange={(e) => setUploadCaption(e.target.value)}
                placeholder="Write an engaging caption with hashtags..."
                rows={2}
                className="w-full bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-white text-xs rounded-xl p-3 border-none outline-none focus:ring-1 focus:ring-pink-500"
              />
            </div>

            {/* Audio Track */}
            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 flex items-center space-x-1">
                <Music className="w-3.5 h-3.5" />
                <span>{language === 'bn' ? 'অডিও ট্র্যাক' : 'Audio Track'}</span>
              </label>
              <input
                type="text"
                value={uploadAudioTrack}
                onChange={(e) => setUploadAudioTrack(e.target.value)}
                placeholder="e.g. Chill Lo-fi Beats - SynthWave"
                className="w-full bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-white text-xs rounded-xl px-3 py-2 border-none outline-none focus:ring-1 focus:ring-pink-500"
              />
            </div>

            {/* Action Buttons */}
            <div className="flex items-center justify-end space-x-2 pt-2">
              <button
                onClick={() => setShowUploadModal(false)}
                className="px-4 py-2 text-xs font-semibold text-slate-500 hover:text-slate-700 dark:text-slate-400"
              >
                Cancel
              </button>
              <button
                onClick={handlePublishReel}
                disabled={!uploadVideoUrl || !uploadCaption.trim()}
                className="flex items-center space-x-1.5 px-5 py-2 bg-pink-600 hover:bg-pink-700 disabled:opacity-50 text-white rounded-xl text-xs font-semibold shadow-md transition-colors"
              >
                <Check className="w-4 h-4" />
                <span>{language === 'bn' ? 'পাবলিশ করুন' : 'Publish Reel'}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Insights Modal */}
      {showInsightsModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 animate-in fade-in duration-150">
          <div className="relative w-full max-w-lg bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200 dark:border-slate-800 shadow-2xl space-y-5">
            {/* Header */}
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <div className="flex items-center space-x-2.5">
                <div className="w-10 h-10 rounded-2xl bg-purple-100 dark:bg-purple-950/60 text-purple-600 flex items-center justify-center">
                  <BarChart3 className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-slate-900 dark:text-white text-lg">
                    {language === 'bn' ? 'রিলস অ্যানালিটিক্স ও ইনসাইটস' : 'Reels Insights'}
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    Performance summary of your published content
                  </p>
                </div>
              </div>
              <button
                onClick={() => setShowInsightsModal(false)}
                className="p-1.5 rounded-full text-slate-400 hover:text-slate-600 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Metrics Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="bg-blue-50 dark:bg-blue-950/30 border border-blue-100 dark:border-blue-900/40 p-3.5 rounded-2xl">
                <div className="flex items-center space-x-1.5 text-blue-600 text-xs font-medium mb-1">
                  <Eye className="w-3.5 h-3.5" />
                  <span>Total Views</span>
                </div>
                <p className="text-xl font-bold text-slate-900 dark:text-white">
                  {totalViews.toLocaleString()}
                </p>
                <span className="text-[10px] text-emerald-600 font-semibold flex items-center mt-0.5">
                  <TrendingUp className="w-3 h-3 mr-0.5" /> +24% this week
                </span>
              </div>

              <div className="bg-red-50 dark:bg-red-950/30 border border-red-100 dark:border-red-900/40 p-3.5 rounded-2xl">
                <div className="flex items-center space-x-1.5 text-red-600 text-xs font-medium mb-1">
                  <Heart className="w-3.5 h-3.5" />
                  <span>Total Likes</span>
                </div>
                <p className="text-xl font-bold text-slate-900 dark:text-white">
                  {totalLikes.toLocaleString()}
                </p>
                <span className="text-[10px] text-emerald-600 font-semibold flex items-center mt-0.5">
                  <TrendingUp className="w-3 h-3 mr-0.5" /> +18%
                </span>
              </div>

              <div className="bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-100 dark:border-emerald-900/40 p-3.5 rounded-2xl">
                <div className="flex items-center space-x-1.5 text-emerald-600 text-xs font-medium mb-1">
                  <Share2 className="w-3.5 h-3.5" />
                  <span>Shares</span>
                </div>
                <p className="text-xl font-bold text-slate-900 dark:text-white">
                  {totalShares.toLocaleString()}
                </p>
                <span className="text-[10px] text-slate-500 mt-0.5">Viral reach</span>
              </div>

              <div className="bg-purple-50 dark:bg-purple-950/30 border border-purple-100 dark:border-purple-900/40 p-3.5 rounded-2xl">
                <div className="flex items-center space-x-1.5 text-purple-600 text-xs font-medium mb-1">
                  <Clock className="w-3.5 h-3.5" />
                  <span>Avg Watch</span>
                </div>
                <p className="text-xl font-bold text-slate-900 dark:text-white">
                  92.4%
                </p>
                <span className="text-[10px] text-emerald-600 font-semibold">
                  Retention High
                </span>
              </div>
            </div>

            {/* Published Reels Table/List */}
            <div className="space-y-2">
              <h4 className="text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider">
                Your Published Reels
              </h4>
              <div className="space-y-2 max-h-48 overflow-y-auto">
                {myReels.map((reel) => (
                  <div
                    key={reel.id}
                    className="flex items-center justify-between p-2.5 bg-slate-50 dark:bg-slate-800/60 rounded-xl"
                  >
                    <div className="flex items-center space-x-2.5 min-w-0">
                      <div className="w-10 h-10 rounded-lg bg-black overflow-hidden flex-shrink-0">
                        {reel.thumbnailUrl ? (
                          <img src={reel.thumbnailUrl} className="w-full h-full object-cover" />
                        ) : (
                          <video src={reel.videoUrl} className="w-full h-full object-cover" />
                        )}
                      </div>
                      <div className="min-w-0">
                        <p className="text-xs font-semibold text-slate-900 dark:text-white truncate">
                          {reel.caption}
                        </p>
                        <p className="text-[10px] text-slate-400">
                          {reel.audioTrack}
                        </p>
                      </div>
                    </div>

                    <div className="text-right flex-shrink-0 pl-3">
                      <p className="text-xs font-bold text-slate-900 dark:text-white">
                        {reel.viewsCount.toLocaleString()} views
                      </p>
                      <p className="text-[10px] text-slate-500">
                        {reel.likesCount} likes · {reel.sharesCount} shares
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Close button */}
            <div className="pt-2 text-right">
              <button
                onClick={() => setShowInsightsModal(false)}
                className="px-5 py-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 rounded-xl text-xs font-semibold transition-colors"
              >
                Close Insights
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
