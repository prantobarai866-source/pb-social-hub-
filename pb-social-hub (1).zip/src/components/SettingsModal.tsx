import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { GoogleLogo } from './GoogleAuthModal';
import {
  X,
  User,
  Shield,
  Palette,
  Bell,
  HardDrive,
  LogOut,
  Check,
  Moon,
  Sun,
  Globe,
  Lock,
  Eye,
  Trash2,
  Download,
  AlertCircle,
  Sparkles,
} from 'lucide-react';

export const SettingsModal: React.FC = () => {
  const {
    isSettingsModalOpen,
    setIsSettingsModalOpen,
    currentUser,
    setCurrentUser,
    theme,
    toggleTheme,
    language,
    setLanguage,
    blockedUserIds,
    setIsGoogleAuthModalOpen,
    logout,
  } = useApp();

  const [activeTab, setActiveTab] = useState<'account' | 'privacy' | 'appearance' | 'notifications' | 'data'>('account');

  // Form states for account editing
  const [name, setName] = useState(currentUser.name);
  const [username, setUsername] = useState(currentUser.username);
  const [bio, setBio] = useState(currentUser.bio);
  const [location, setLocation] = useState(currentUser.location || '');
  const [work, setWork] = useState(currentUser.work || '');
  const [showSavedToast, setShowSavedToast] = useState(false);

  // Privacy toggles
  const [postVisibility, setPostVisibility] = useState<'public' | 'friends' | 'private'>('public');
  const [friendRequestPrivacy, setFriendRequestPrivacy] = useState<'everyone' | 'friends_of_friends'>('everyone');

  // Notification toggles
  const [pushEnabled, setPushEnabled] = useState(true);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [emailDigest, setEmailDigest] = useState(false);

  if (!isSettingsModalOpen) return null;

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    setCurrentUser((prev) => ({
      ...prev,
      name,
      username,
      bio,
      location,
      work,
    }));
    setShowSavedToast(true);
    setTimeout(() => setShowSavedToast(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="relative w-full max-w-2xl bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col max-h-[90vh]">
        {/* Modal Top Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 dark:border-slate-800">
          <div className="flex items-center space-x-2.5">
            <div className="w-8 h-8 rounded-xl bg-blue-100 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 flex items-center justify-center">
              <Shield className="w-4 h-4" />
            </div>
            <div>
              <h2 className="font-bold text-base text-slate-900 dark:text-white">
                {language === 'bn' ? 'সেটিংস ও প্রাইভেসি' : 'Settings & Privacy'}
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                {language === 'bn' ? 'আপনার অ্যাকাউন্ট ও পছন্দসমূহ পরিচালনা করুন' : 'Manage your preferences and security'}
              </p>
            </div>
          </div>

          <button
            onClick={() => setIsSettingsModalOpen(false)}
            className="p-2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Saved Toast banner */}
        {showSavedToast && (
          <div className="bg-emerald-500 text-white px-4 py-2 text-xs font-semibold flex items-center justify-center space-x-1.5 animate-in slide-in-from-top duration-150">
            <Check className="w-4 h-4" />
            <span>{language === 'bn' ? 'পরিবর্তনসমূহ সংরক্ষিত হয়েছে!' : 'Settings updated successfully!'}</span>
          </div>
        )}

        <div className="flex-1 overflow-hidden flex flex-col md:flex-row">
          {/* Left Navigation Tabs */}
          <div className="w-full md:w-48 bg-slate-50/70 dark:bg-slate-800/40 p-2 md:p-3 border-b md:border-b-0 md:border-r border-slate-100 dark:border-slate-800 flex md:flex-col overflow-x-auto gap-1">
            <button
              onClick={() => setActiveTab('account')}
              className={`flex items-center space-x-2.5 px-3 py-2.5 rounded-xl text-xs font-semibold text-left transition-colors whitespace-nowrap cursor-pointer ${
                activeTab === 'account'
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'text-slate-700 dark:text-slate-300 hover:bg-slate-200/60 dark:hover:bg-slate-800'
              }`}
            >
              <User className="w-4 h-4" />
              <span>{language === 'bn' ? 'অ্যাকাউন্ট' : 'Account'}</span>
            </button>

            <button
              onClick={() => setActiveTab('privacy')}
              className={`flex items-center space-x-2.5 px-3 py-2.5 rounded-xl text-xs font-semibold text-left transition-colors whitespace-nowrap cursor-pointer ${
                activeTab === 'privacy'
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'text-slate-700 dark:text-slate-300 hover:bg-slate-200/60 dark:hover:bg-slate-800'
              }`}
            >
              <Lock className="w-4 h-4" />
              <span>{language === 'bn' ? 'প্রাইভেসি' : 'Privacy'}</span>
            </button>

            <button
              onClick={() => setActiveTab('appearance')}
              className={`flex items-center space-x-2.5 px-3 py-2.5 rounded-xl text-xs font-semibold text-left transition-colors whitespace-nowrap cursor-pointer ${
                activeTab === 'appearance'
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'text-slate-700 dark:text-slate-300 hover:bg-slate-200/60 dark:hover:bg-slate-800'
              }`}
            >
              <Palette className="w-4 h-4" />
              <span>{language === 'bn' ? 'থিম ও ভাষা' : 'Appearance'}</span>
            </button>

            <button
              onClick={() => setActiveTab('notifications')}
              className={`flex items-center space-x-2.5 px-3 py-2.5 rounded-xl text-xs font-semibold text-left transition-colors whitespace-nowrap cursor-pointer ${
                activeTab === 'notifications'
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'text-slate-700 dark:text-slate-300 hover:bg-slate-200/60 dark:hover:bg-slate-800'
              }`}
            >
              <Bell className="w-4 h-4" />
              <span>{language === 'bn' ? 'নোটিফিকেশন' : 'Alerts'}</span>
            </button>

            <button
              onClick={() => setActiveTab('data')}
              className={`flex items-center space-x-2.5 px-3 py-2.5 rounded-xl text-xs font-semibold text-left transition-colors whitespace-nowrap cursor-pointer ${
                activeTab === 'data'
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'text-slate-700 dark:text-slate-300 hover:bg-slate-200/60 dark:hover:bg-slate-800'
              }`}
            >
              <HardDrive className="w-4 h-4" />
              <span>{language === 'bn' ? 'ডেটা ও লগআউট' : 'Data & Auth'}</span>
            </button>
          </div>

          {/* Right Content Area */}
          <div className="flex-1 p-5 sm:p-6 overflow-y-auto space-y-6">
            {/* TAB 1: ACCOUNT SETTINGS */}
            {activeTab === 'account' && (
              <div className="space-y-5">
                {/* Connected Google Account banner */}
                <div className="bg-slate-50 dark:bg-slate-800/60 rounded-2xl p-4 border border-slate-200/80 dark:border-slate-700/60 flex items-center justify-between flex-wrap gap-3">
                  <div className="flex items-center space-x-3">
                    <div className="p-2.5 bg-white dark:bg-slate-800 rounded-xl shadow-xs border border-slate-200 dark:border-slate-700">
                      <GoogleLogo className="w-6 h-6" />
                    </div>
                    <div>
                      <div className="flex items-center space-x-1.5">
                        <span className="text-xs font-bold text-slate-900 dark:text-white">
                          Google Account Connected
                        </span>
                        <span className="w-2 h-2 rounded-full bg-emerald-500" />
                      </div>
                      <p className="text-xs text-slate-500 dark:text-slate-400">
                        {currentUser.email || 'prantoofficial46@gmail.com'}
                      </p>
                    </div>
                  </div>

                  <button
                    onClick={() => setIsGoogleAuthModalOpen(true)}
                    className="px-3 py-1.5 bg-white dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold transition-colors"
                  >
                    {language === 'bn' ? 'অ্যাকাউন্ট পরিবর্তন' : 'Switch Google Account'}
                  </button>
                </div>

                {/* Profile Form */}
                <form onSubmit={handleSaveProfile} className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                        {language === 'bn' ? 'নাম' : 'Display Name'}
                      </label>
                      <input
                        type="text"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-2 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                        {language === 'bn' ? 'ইউজারনেম' : 'Username'}
                      </label>
                      <input
                        type="text"
                        value={username}
                        onChange={(e) => setUsername(e.target.value)}
                        className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-2 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      {language === 'bn' ? 'বায়ো / বিবরণ' : 'Bio'}
                    </label>
                    <textarea
                      rows={2}
                      value={bio}
                      onChange={(e) => setBio(e.target.value)}
                      className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-2 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none"
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                        {language === 'bn' ? 'অবস্থান' : 'Location'}
                      </label>
                      <input
                        type="text"
                        value={location}
                        onChange={(e) => setLocation(e.target.value)}
                        placeholder="e.g. Dhaka, Bangladesh"
                        className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-2 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                        {language === 'bn' ? 'পেশা / কর্মস্থল' : 'Work'}
                      </label>
                      <input
                        type="text"
                        value={work}
                        onChange={(e) => setWork(e.target.value)}
                        placeholder="e.g. Software Engineer"
                        className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-2 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                      />
                    </div>
                  </div>

                  <div className="pt-2">
                    <button
                      type="submit"
                      className="px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-semibold transition-all active:scale-95 shadow-sm"
                    >
                      {language === 'bn' ? 'সংরক্ষণ করুন' : 'Save Changes'}
                    </button>
                  </div>
                </form>
              </div>
            )}

            {/* TAB 2: PRIVACY & SAFETY */}
            {activeTab === 'privacy' && (
              <div className="space-y-4">
                <div className="p-4 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-3">
                  <h4 className="text-xs font-bold text-slate-900 dark:text-white flex items-center space-x-1.5">
                    <Eye className="w-4 h-4 text-blue-500" />
                    <span>{language === 'bn' ? 'পোস্টের দর্শক' : 'Who can see your posts?'}</span>
                  </h4>
                  <div className="space-y-2">
                    {[
                      { id: 'public', label: 'Public (যেকেউ দেখতে পারবে)' },
                      { id: 'friends', label: 'Friends only (শুধুমাত্র বন্ধুরা)' },
                      { id: 'private', label: 'Only Me (শুধুমাত্র আমি)' },
                    ].map((opt) => (
                      <label key={opt.id} className="flex items-center space-x-2 text-xs cursor-pointer">
                        <input
                          type="radio"
                          name="postVisibility"
                          checked={postVisibility === opt.id}
                          onChange={() => setPostVisibility(opt.id as any)}
                          className="text-blue-600 focus:ring-blue-500"
                        />
                        <span className="text-slate-700 dark:text-slate-300">{opt.label}</span>
                      </label>
                    ))}
                  </div>
                </div>

                <div className="p-4 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-3">
                  <h4 className="text-xs font-bold text-slate-900 dark:text-white flex items-center space-x-1.5">
                    <Shield className="w-4 h-4 text-emerald-500" />
                    <span>{language === 'bn' ? 'ফ্রেন্ড রিকোয়েস্ট প্রাইভেসি' : 'Who can send you friend requests?'}</span>
                  </h4>
                  <div className="space-y-2">
                    {[
                      { id: 'everyone', label: 'Everyone (সবাই)' },
                      { id: 'friends_of_friends', label: 'Friends of friends (বন্ধুদের বন্ধুরা)' },
                    ].map((opt) => (
                      <label key={opt.id} className="flex items-center space-x-2 text-xs cursor-pointer">
                        <input
                          type="radio"
                          name="friendPrivacy"
                          checked={friendRequestPrivacy === opt.id}
                          onChange={() => setFriendRequestPrivacy(opt.id as any)}
                          className="text-blue-600 focus:ring-blue-500"
                        />
                        <span className="text-slate-700 dark:text-slate-300">{opt.label}</span>
                      </label>
                    ))}
                  </div>
                </div>

                <div className="p-4 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200 dark:border-slate-700 flex items-center justify-between">
                  <div>
                    <span className="text-xs font-bold text-slate-900 dark:text-white">
                      {language === 'bn' ? 'ব্লক করা ব্যবহারকারী' : 'Blocked Users'}
                    </span>
                    <p className="text-[11px] text-slate-500">
                      {blockedUserIds.length} {language === 'bn' ? 'জন ব্লক করা রয়েছে' : 'users currently blocked'}
                    </p>
                  </div>
                  <span className="text-xs font-semibold px-2.5 py-1 bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300 rounded-lg">
                    {blockedUserIds.length}
                  </span>
                </div>
              </div>
            )}

            {/* TAB 3: APPEARANCE & THEME */}
            {activeTab === 'appearance' && (
              <div className="space-y-4">
                {/* Theme selector */}
                <div className="p-4 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200 dark:border-slate-700 flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className="p-2.5 bg-white dark:bg-slate-800 rounded-xl shadow-xs">
                      {theme === 'dark' ? <Moon className="w-5 h-5 text-indigo-400" /> : <Sun className="w-5 h-5 text-amber-500" />}
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-slate-900 dark:text-white">
                        {language === 'bn' ? 'ডার্ক মোড' : 'Dark Mode'}
                      </h4>
                      <p className="text-[11px] text-slate-500">
                        {theme === 'dark' ? 'Dark theme is active' : 'Light theme is active'}
                      </p>
                    </div>
                  </div>

                  <button
                    onClick={toggleTheme}
                    className="px-3.5 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold transition-colors"
                  >
                    {theme === 'dark' ? 'Switch to Light' : 'Switch to Dark'}
                  </button>
                </div>

                {/* Language switcher */}
                <div className="p-4 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200 dark:border-slate-700 flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className="p-2.5 bg-white dark:bg-slate-800 rounded-xl shadow-xs text-blue-500">
                      <Globe className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-slate-900 dark:text-white">
                        {language === 'bn' ? 'ভাষা নির্বাচন' : 'Platform Language'}
                      </h4>
                      <p className="text-[11px] text-slate-500">
                        {language === 'bn' ? 'বাংলা ভাষা সক্রিয়' : 'English (US) is active'}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center space-x-1.5 bg-slate-200 dark:bg-slate-700 p-1 rounded-xl">
                    <button
                      onClick={() => setLanguage('bn')}
                      className={`px-3 py-1 rounded-lg text-xs font-bold transition-colors ${
                        language === 'bn'
                          ? 'bg-blue-600 text-white'
                          : 'text-slate-600 dark:text-slate-300'
                      }`}
                    >
                      বাংলা
                    </button>
                    <button
                      onClick={() => setLanguage('en')}
                      className={`px-3 py-1 rounded-lg text-xs font-bold transition-colors ${
                        language === 'en'
                          ? 'bg-blue-600 text-white'
                          : 'text-slate-600 dark:text-slate-300'
                      }`}
                    >
                      English
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* TAB 4: NOTIFICATIONS */}
            {activeTab === 'notifications' && (
              <div className="space-y-3">
                <div className="p-4 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200 dark:border-slate-700 flex items-center justify-between">
                  <div>
                    <h4 className="text-xs font-bold text-slate-900 dark:text-white">Push Notifications</h4>
                    <p className="text-[11px] text-slate-500">Get alerts for likes, comments, and reels</p>
                  </div>
                  <input
                    type="checkbox"
                    checked={pushEnabled}
                    onChange={(e) => setPushEnabled(e.target.checked)}
                    className="w-4 h-4 text-blue-600 rounded-sm"
                  />
                </div>

                <div className="p-4 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200 dark:border-slate-700 flex items-center justify-between">
                  <div>
                    <h4 className="text-xs font-bold text-slate-900 dark:text-white">Sound Effects</h4>
                    <p className="text-[11px] text-slate-500">Play sounds for incoming chats and calls</p>
                  </div>
                  <input
                    type="checkbox"
                    checked={soundEnabled}
                    onChange={(e) => setSoundEnabled(e.target.checked)}
                    className="w-4 h-4 text-blue-600 rounded-sm"
                  />
                </div>

                <div className="p-4 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200 dark:border-slate-700 flex items-center justify-between">
                  <div>
                    <h4 className="text-xs font-bold text-slate-900 dark:text-white">Email Digest</h4>
                    <p className="text-[11px] text-slate-500">Weekly activity summary to your Google account</p>
                  </div>
                  <input
                    type="checkbox"
                    checked={emailDigest}
                    onChange={(e) => setEmailDigest(e.target.checked)}
                    className="w-4 h-4 text-blue-600 rounded-sm"
                  />
                </div>
              </div>
            )}

            {/* TAB 5: DATA & LOGOUT */}
            {activeTab === 'data' && (
              <div className="space-y-4">
                <div className="p-4 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200 dark:border-slate-700 flex items-center justify-between">
                  <div>
                    <h4 className="text-xs font-bold text-slate-900 dark:text-white flex items-center space-x-1.5">
                      <Download className="w-4 h-4 text-blue-500" />
                      <span>Download Your Information</span>
                    </h4>
                    <p className="text-[11px] text-slate-500">Export a copy of your posts, stories, and photos</p>
                  </div>
                  <button
                    onClick={() => alert('Download package initiated!')}
                    className="px-3 py-1.5 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold hover:bg-slate-100"
                  >
                    Export
                  </button>
                </div>

                {/* Google Sign Out */}
                <div className="p-4 bg-red-50/50 dark:bg-red-950/20 rounded-2xl border border-red-200 dark:border-red-900/40 flex items-center justify-between">
                  <div>
                    <h4 className="text-xs font-bold text-red-600 dark:text-red-400 flex items-center space-x-1.5">
                      <LogOut className="w-4 h-4" />
                      <span>{language === 'bn' ? 'গুগল অ্যাকাউন্ট থেকে লগআউট' : 'Sign out of Google Account'}</span>
                    </h4>
                    <p className="text-[11px] text-slate-500">
                      {language === 'bn' ? 'সাইন আউট করে অন্য অ্যাকাউন্টে প্রবেশ করতে পারবেন' : 'Disconnect current session and switch account'}
                    </p>
                  </div>
                  <button
                    onClick={() => {
                      setIsSettingsModalOpen(false);
                      logout();
                    }}
                    className="px-3.5 py-1.5 bg-red-600 hover:bg-red-700 text-white rounded-xl text-xs font-semibold transition-colors"
                  >
                    {language === 'bn' ? 'লগআউট' : 'Sign Out'}
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
