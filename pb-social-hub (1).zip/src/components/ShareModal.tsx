import React, { useState } from 'react';
import { Post } from '../types';
import { useApp } from '../context/AppContext';
import {
  X,
  Share2,
  Copy,
  Check,
  Facebook,
  Twitter,
  Send,
  MessageCircle,
  Users,
} from 'lucide-react';

interface ShareModalProps {
  post: Post | null;
  isOpen: boolean;
  onClose: () => void;
}

export const ShareModal: React.FC<ShareModalProps> = ({ post, isOpen, onClose }) => {
  const { sharePost, groups, language } = useApp();
  const [copied, setCopied] = useState(false);
  const [selectedGroup, setSelectedGroup] = useState<string>('');
  const [sharedSuccess, setSharedSuccess] = useState(false);

  if (!isOpen || !post) return null;

  const postUrl = window.location.href;

  const handleCopyLink = () => {
    try {
      if (navigator && navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(postUrl).catch(() => {
          fallbackCopyText(postUrl);
        });
      } else {
        fallbackCopyText(postUrl);
      }
    } catch {
      fallbackCopyText(postUrl);
    }
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const fallbackCopyText = (text: string) => {
    try {
      const textArea = document.createElement('textarea');
      textArea.value = text;
      textArea.style.position = 'fixed';
      textArea.style.opacity = '0';
      document.body.appendChild(textArea);
      textArea.focus();
      textArea.select();
      document.execCommand('copy');
      document.body.removeChild(textArea);
    } catch (e) {
      console.warn('Fallback copy failed', e);
    }
  };

  const handleShareToFeed = () => {
    sharePost(post.id);
    setSharedSuccess(true);
    setTimeout(() => {
      setSharedSuccess(false);
      onClose();
    }, 1200);
  };

  const handleShareToGroup = () => {
    if (!selectedGroup) return;
    sharePost(post.id, selectedGroup);
    setSharedSuccess(true);
    setTimeout(() => {
      setSharedSuccess(false);
      onClose();
    }, 1200);
  };

  const shareExternal = (platform: string) => {
    const text = encodeURIComponent(`Check out this post on BondhuNet: ${post.content.slice(0, 80)}`);
    const url = encodeURIComponent(postUrl);
    let shareLink = '';

    switch (platform) {
      case 'whatsapp':
        shareLink = `https://api.whatsapp.com/send?text=${text}%20${url}`;
        break;
      case 'twitter':
        shareLink = `https://twitter.com/intent/tweet?text=${text}&url=${url}`;
        break;
      case 'telegram':
        shareLink = `https://t.me/share/url?url=${url}&text=${text}`;
        break;
      case 'facebook':
        shareLink = `https://www.facebook.com/sharer/sharer.php?u=${url}`;
        break;
    }

    if (shareLink) {
      window.open(shareLink, '_blank', 'noopener,noreferrer');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4 animate-in fade-in duration-150">
      <div className="relative w-full max-w-md bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 p-5 overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 rounded-full bg-blue-50 dark:bg-blue-900/40 text-blue-600 dark:text-blue-400 flex items-center justify-center">
              <Share2 className="w-4 h-4" />
            </div>
            <h3 className="font-semibold text-slate-900 dark:text-white text-base">
              {language === 'bn' ? 'শেয়ার করুন' : 'Share Post'}
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full text-slate-400 hover:text-slate-600 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {sharedSuccess ? (
          <div className="py-8 text-center flex flex-col items-center">
            <div className="w-12 h-12 rounded-full bg-emerald-100 dark:bg-emerald-950/60 text-emerald-600 flex items-center justify-center mb-3">
              <Check className="w-6 h-6" />
            </div>
            <h4 className="font-semibold text-slate-900 dark:text-white">
              {language === 'bn' ? 'সফলভাবে শেয়ার করা হয়েছে!' : 'Shared Successfully!'}
            </h4>
            <p className="text-xs text-slate-500 mt-1">
              {language === 'bn' ? 'পোস্টটি আপনার ফিডে যুক্ত হয়েছে' : 'Post has been added to your feed'}
            </p>
          </div>
        ) : (
          <div className="mt-4 space-y-4">
            {/* Quick Share to Feed Button */}
            <button
              onClick={handleShareToFeed}
              className="w-full flex items-center justify-center space-x-2 py-2.5 px-4 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-sm font-semibold shadow-sm transition-all active:scale-98"
            >
              <Share2 className="w-4 h-4" />
              <span>{language === 'bn' ? 'এখনই ফিডে শেয়ার করুন' : 'Share to Feed now'}</span>
            </button>

            {/* Share to Group */}
            <div className="space-y-1.5">
              <label className="text-xs font-medium text-slate-600 dark:text-slate-400 flex items-center space-x-1.5">
                <Users className="w-3.5 h-3.5" />
                <span>{language === 'bn' ? 'গ্রুপে শেয়ার করুন' : 'Share to a Group'}</span>
              </label>
              <div className="flex space-x-2">
                <select
                  value={selectedGroup}
                  onChange={(e) => setSelectedGroup(e.target.value)}
                  className="flex-1 bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-white text-xs rounded-xl px-3 py-2 border-none focus:ring-1 focus:ring-blue-500 outline-none"
                >
                  <option value="">{language === 'bn' ? 'একটি গ্রুপ নির্বাচন করুন...' : 'Select a group...'}</option>
                  {groups.map((g) => (
                    <option key={g.id} value={g.id}>
                      {g.name}
                    </option>
                  ))}
                </select>
                <button
                  onClick={handleShareToGroup}
                  disabled={!selectedGroup}
                  className="px-3 py-2 bg-slate-200 dark:bg-slate-700 disabled:opacity-50 text-slate-900 dark:text-white text-xs font-semibold rounded-xl hover:bg-slate-300 dark:hover:bg-slate-600 transition-colors"
                >
                  {language === 'bn' ? 'পাঠান' : 'Send'}
                </button>
              </div>
            </div>

            {/* Copy Link input */}
            <div className="space-y-1.5">
              <label className="text-xs font-medium text-slate-600 dark:text-slate-400">
                {language === 'bn' ? 'পোস্টের লিঙ্ক' : 'Post Link'}
              </label>
              <div className="flex items-center space-x-2">
                <input
                  type="text"
                  readOnly
                  value={postUrl}
                  className="flex-1 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 text-xs rounded-xl px-3 py-2 border-none focus:outline-none"
                />
                <button
                  onClick={handleCopyLink}
                  className="flex items-center space-x-1 px-3 py-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 text-xs font-semibold rounded-xl transition-colors"
                >
                  {copied ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copied ? (language === 'bn' ? 'কপি হয়েছে' : 'Copied!') : (language === 'bn' ? 'কপি' : 'Copy')}</span>
                </button>
              </div>
            </div>

            {/* External Social Buttons */}
            <div className="pt-2 border-t border-slate-100 dark:border-slate-800">
              <p className="text-[11px] font-medium text-slate-500 dark:text-slate-400 mb-2.5">
                {language === 'bn' ? 'অন্যান্য মাধ্যমে শেয়ার করুন:' : 'Share via external app:'}
              </p>
              <div className="grid grid-cols-4 gap-2">
                <button
                  onClick={() => shareExternal('whatsapp')}
                  className="flex flex-col items-center justify-center p-2 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 dark:text-emerald-400 hover:bg-emerald-100 dark:hover:bg-emerald-900/50 transition-colors"
                >
                  <MessageCircle className="w-5 h-5 mb-1" />
                  <span className="text-[10px] font-medium">WhatsApp</span>
                </button>
                <button
                  onClick={() => shareExternal('twitter')}
                  className="flex flex-col items-center justify-center p-2 rounded-xl bg-sky-50 dark:bg-sky-950/40 text-sky-600 dark:text-sky-400 hover:bg-sky-100 dark:hover:bg-sky-900/50 transition-colors"
                >
                  <Twitter className="w-5 h-5 mb-1" />
                  <span className="text-[10px] font-medium">Twitter / X</span>
                </button>
                <button
                  onClick={() => shareExternal('telegram')}
                  className="flex flex-col items-center justify-center p-2 rounded-xl bg-blue-50 dark:bg-blue-950/40 text-blue-600 dark:text-blue-400 hover:bg-blue-100 dark:hover:bg-blue-900/50 transition-colors"
                >
                  <Send className="w-5 h-5 mb-1" />
                  <span className="text-[10px] font-medium">Telegram</span>
                </button>
                <button
                  onClick={() => shareExternal('facebook')}
                  className="flex flex-col items-center justify-center p-2 rounded-xl bg-indigo-50 dark:bg-indigo-950/40 text-indigo-600 dark:text-indigo-400 hover:bg-indigo-100 dark:hover:bg-indigo-900/50 transition-colors"
                >
                  <Facebook className="w-5 h-5 mb-1" />
                  <span className="text-[10px] font-medium">Facebook</span>
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
