import React from 'react';
import { useApp } from '../context/AppContext';
import { GoogleLogo } from './GoogleAuthModal';
import {
  User,
  Users,
  Film,
  Gamepad2,
  Bookmark,
  Clock,
  Calendar,
  Sparkles,
  ChevronDown,
  Tv,
  HelpCircle,
  Settings,
  Video,
  Plus,
} from 'lucide-react';

export const SidebarLeft: React.FC = () => {
  const {
    currentUser,
    activeTab,
    setActiveTab,
    setSelectedUserId,
    language,
    setIsSettingsModalOpen,
    setIsCreateReelModalOpen,
    setIsGoogleAuthModalOpen,
  } = useApp();

  return (
    <aside className="hidden lg:block w-72 sticky top-16 h-[calc(100vh-4rem)] overflow-y-auto p-4 space-y-2 scrollbar-none select-none">
      {/* User Profile item */}
      <button
        onClick={() => {
          setActiveTab('profile');
          setSelectedUserId(null);
        }}
        className="w-full flex items-center space-x-3 p-2.5 rounded-2xl hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors text-left group"
      >
        <img
          src={currentUser.avatar}
          alt={currentUser.name}
          className="w-9 h-9 rounded-full object-cover ring-1 ring-slate-200 dark:ring-slate-700"
        />
        <span className="font-bold text-xs sm:text-sm text-slate-900 dark:text-white truncate">
          {currentUser.name}
        </span>
      </button>

      {/* Main navigation items */}
      <button
        onClick={() => {
          setActiveTab('friends');
          setSelectedUserId(null);
        }}
        className={`w-full flex items-center space-x-3 p-2.5 rounded-2xl transition-colors text-left ${
          activeTab === 'friends'
            ? 'bg-blue-50 dark:bg-blue-950/40 text-blue-600 dark:text-blue-400 font-bold'
            : 'hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300 font-semibold'
        }`}
      >
        <div className="w-8 h-8 rounded-xl bg-blue-100 dark:bg-blue-900/40 text-blue-600 flex items-center justify-center">
          <Users className="w-4 h-4" />
        </div>
        <span className="text-xs">{language === 'bn' ? 'বন্ধুরা' : 'Friends'}</span>
      </button>

      <button
        onClick={() => {
          setActiveTab('reels');
          setSelectedUserId(null);
        }}
        className={`w-full flex items-center justify-between p-2.5 rounded-2xl transition-colors text-left ${
          activeTab === 'reels'
            ? 'bg-pink-50 dark:bg-pink-950/40 text-pink-600 dark:text-pink-400 font-bold'
            : 'hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300 font-semibold'
        }`}
      >
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-pink-500 to-rose-600 text-white flex items-center justify-center shadow-xs">
            <Film className="w-4 h-4" />
          </div>
          <span className="text-xs">{language === 'bn' ? 'রিল দেখুন' : 'Watch Reels'}</span>
        </div>
        <span className="text-[10px] font-bold px-1.5 py-0.5 rounded-full bg-pink-100 dark:bg-pink-950/60 text-pink-600 dark:text-pink-400">
          {language === 'bn' ? 'হট' : 'Hot'}
        </span>
      </button>

      <button
        onClick={() => {
          setActiveTab('groups');
          setSelectedUserId(null);
        }}
        className={`w-full flex items-center space-x-3 p-2.5 rounded-2xl transition-colors text-left ${
          activeTab === 'groups'
            ? 'bg-indigo-50 dark:bg-indigo-950/40 text-indigo-600 dark:text-indigo-400 font-bold'
            : 'hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300 font-semibold'
        }`}
      >
        <div className="w-8 h-8 rounded-xl bg-indigo-100 dark:bg-indigo-900/40 text-indigo-600 flex items-center justify-center">
          <Users className="w-4 h-4" />
        </div>
        <span className="text-xs">{language === 'bn' ? 'গ্রুপসমূহ' : 'Groups & Communities'}</span>
      </button>

      <button
        onClick={() => {
          setActiveTab('gaming');
          setSelectedUserId(null);
        }}
        className={`w-full flex items-center space-x-3 p-2.5 rounded-2xl transition-colors text-left ${
          activeTab === 'gaming'
            ? 'bg-purple-50 dark:bg-purple-950/40 text-purple-600 dark:text-purple-400 font-bold'
            : 'hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300 font-semibold'
        }`}
      >
        <div className="w-8 h-8 rounded-xl bg-purple-100 dark:bg-purple-900/40 text-purple-600 flex items-center justify-center">
          <Gamepad2 className="w-4 h-4" />
        </div>
        <span className="text-xs">{language === 'bn' ? 'প্লে গেমস ও লবি' : 'Gaming & Playrooms'}</span>
      </button>

      {/* Create Reel Action Button in Sidebar */}
      <button
        onClick={() => setIsCreateReelModalOpen(true)}
        className="w-full flex items-center justify-between p-3 rounded-2xl bg-linear-to-r from-pink-500/10 via-rose-500/10 to-purple-500/10 hover:from-pink-500/20 hover:via-rose-500/20 hover:to-purple-500/20 border border-pink-200 dark:border-pink-900/40 text-pink-700 dark:text-pink-300 transition-all cursor-pointer group"
      >
        <div className="flex items-center space-x-2.5">
          <div className="w-7 h-7 rounded-xl bg-pink-600 text-white flex items-center justify-center shadow-xs group-hover:scale-105 transition-transform">
            <Video className="w-4 h-4" />
          </div>
          <span className="text-xs font-bold">
            {language === 'bn' ? 'রিলিস আপলোড করুন' : 'Create & Share Reel'}
          </span>
        </div>
        <Plus className="w-4 h-4 text-pink-600" />
      </button>

      {/* Auxiliary shortcuts */}
      <div className="pt-2 border-t border-slate-200/60 dark:border-slate-800/60 space-y-1">
        <button
          onClick={() => {
            setSelectedUserId(null);
            setActiveTab('profile');
          }}
          className="w-full flex items-center space-x-3 p-2.5 rounded-2xl hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer text-slate-600 dark:text-slate-400 text-left"
        >
          <Bookmark className="w-4 h-4 text-amber-500" />
          <span className="text-xs font-semibold">{language === 'bn' ? 'সংরক্ষিত আইটেম' : 'Saved Items'}</span>
        </button>

        {/* Settings button */}
        <button
          onClick={() => setIsSettingsModalOpen(true)}
          className="w-full flex items-center space-x-3 p-2.5 rounded-2xl hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer text-slate-600 dark:text-slate-400 text-left"
        >
          <Settings className="w-4 h-4 text-blue-500" />
          <span className="text-xs font-semibold">{language === 'bn' ? 'সেটিংস' : 'Settings & Privacy'}</span>
        </button>

        <div className="flex items-center space-x-3 p-2.5 rounded-2xl hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer text-slate-600 dark:text-slate-400">
          <Clock className="w-4 h-4 text-blue-500" />
          <span className="text-xs font-semibold">{language === 'bn' ? 'স্মৃতিচারণ' : 'Memories'}</span>
        </div>

        <div className="flex items-center space-x-3 p-2.5 rounded-2xl hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer text-slate-600 dark:text-slate-400">
          <Calendar className="w-4 h-4 text-red-500" />
          <span className="text-xs font-semibold">{language === 'bn' ? 'ইভেন্ট' : 'Events'}</span>
        </div>
      </div>

      {/* Google Account Quick Card */}
      <div className="pt-2">
        <div
          onClick={() => setIsGoogleAuthModalOpen(true)}
          className="p-3 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-blue-400 transition-all cursor-pointer shadow-xs group"
        >
          <div className="flex items-center space-x-2.5">
            <GoogleLogo className="w-5 h-5 flex-shrink-0" />
            <div className="min-w-0 flex-1">
              <p className="text-[11px] font-bold text-slate-800 dark:text-slate-200 truncate">
                {currentUser.name}
              </p>
              <p className="text-[10px] text-slate-400 truncate">
                {currentUser.email || 'prantoofficial46@gmail.com'}
              </p>
            </div>
          </div>
          <div className="mt-2 pt-2 border-t border-slate-100 dark:border-slate-800/80 flex items-center justify-between text-[10px] text-blue-600 dark:text-blue-400 font-semibold">
            <span>{language === 'bn' ? 'Google অ্যাকাউন্ট' : 'Google Account'}</span>
            <span className="group-hover:underline">
              {language === 'bn' ? 'পরিবর্তন' : 'Switch'}
            </span>
          </div>
        </div>
      </div>

      {/* Footer credits */}
      <div className="pt-3 px-2 text-[11px] text-slate-400 dark:text-slate-500 space-y-1">
        <p>BondhuNet Social Platform · 2026</p>
        <p className="text-[10px]">Privacy · Terms · Cookies · Settings</p>
      </div>
    </aside>
  );
};
