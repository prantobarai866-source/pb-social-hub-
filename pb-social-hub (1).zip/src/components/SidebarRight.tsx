import React from 'react';
import { useApp } from '../context/AppContext';
import {
  UserPlus,
  Phone,
  Video,
  Check,
  X,
  MessageSquare,
  Search,
  MoreHorizontal,
} from 'lucide-react';

export const SidebarRight: React.FC = () => {
  const {
    friends,
    friendRequests,
    acceptFriendRequest,
    rejectFriendRequest,
    startCall,
    setActiveChatUser,
    setSelectedUserId,
    setActiveTab,
    language,
  } = useApp();

  return (
    <aside className="hidden xl:block w-80 sticky top-16 h-[calc(100vh-4rem)] overflow-y-auto p-4 space-y-5 scrollbar-none select-none">
      {/* Friend Requests Section */}
      {friendRequests.length > 0 && (
        <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200 dark:border-slate-800 shadow-xs space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-xs uppercase tracking-wider text-slate-700 dark:text-slate-300 flex items-center space-x-1.5">
              <UserPlus className="w-3.5 h-3.5 text-blue-600" />
              <span>{language === 'bn' ? 'ফ্রেন্ড রিকুয়েস্ট' : 'Friend Requests'}</span>
            </h3>
            <span className="text-xs font-bold text-blue-600 dark:text-blue-400">
              {friendRequests.length}
            </span>
          </div>

          <div className="space-y-3">
            {friendRequests.map((req) => (
              <div key={req.id} className="space-y-2">
                <div className="flex items-center space-x-2.5">
                  <img
                    src={req.avatar}
                    alt={req.name}
                    className="w-10 h-10 rounded-full object-cover ring-1 ring-slate-200 dark:ring-slate-700"
                  />
                  <div className="min-w-0">
                    <p className="font-bold text-xs text-slate-900 dark:text-white truncate">
                      {req.name}
                    </p>
                    <p className="text-[11px] text-slate-400">{req.location || 'Dhaka, Bangladesh'}</p>
                  </div>
                </div>

                <div className="flex items-center space-x-2 pl-12">
                  <button
                    onClick={() => acceptFriendRequest(req.id)}
                    className="flex-1 py-1.5 px-3 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-semibold shadow-xs transition-colors"
                  >
                    {language === 'bn' ? 'অনুমোদন' : 'Confirm'}
                  </button>
                  <button
                    onClick={() => rejectFriendRequest(req.id)}
                    className="flex-1 py-1.5 px-3 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 rounded-xl text-xs font-semibold transition-colors"
                  >
                    {language === 'bn' ? 'মুছুন' : 'Delete'}
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Online Contacts List */}
      <div className="space-y-2">
        <div className="flex items-center justify-between px-2">
          <h3 className="font-bold text-xs uppercase tracking-wider text-slate-500 dark:text-slate-400">
            {language === 'bn' ? 'যোগাযোগ ও অনলাইন' : 'Contacts'}
          </h3>
          <div className="flex items-center space-x-1 text-slate-400">
            <Search className="w-3.5 h-3.5 hover:text-slate-600 cursor-pointer" />
            <MoreHorizontal className="w-3.5 h-3.5 hover:text-slate-600 cursor-pointer" />
          </div>
        </div>

        <div className="space-y-1">
          {friends.map((friend) => (
            <div
              key={friend.id}
              className="flex items-center justify-between p-2 rounded-2xl hover:bg-slate-100 dark:hover:bg-slate-800/80 transition-colors group cursor-pointer"
            >
              <div
                onClick={() => setActiveChatUser(friend)}
                className="flex items-center space-x-2.5 min-w-0 flex-1"
              >
                <div className="relative flex-shrink-0">
                  <img
                    src={friend.avatar}
                    alt={friend.name}
                    className="w-9 h-9 rounded-full object-cover ring-1 ring-slate-200 dark:ring-slate-700"
                  />
                  {friend.isOnline !== false && (
                    <span className="absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full bg-emerald-500 ring-2 ring-white dark:ring-slate-900" />
                  )}
                </div>
                <div className="min-w-0">
                  <p className="font-semibold text-xs text-slate-900 dark:text-white truncate group-hover:text-blue-600 transition-colors">
                    {friend.name}
                  </p>
                  <p className="text-[10px] text-slate-400 truncate">
                    {friend.isOnline !== false ? 'Online now' : 'Offline'}
                  </p>
                </div>
              </div>

              {/* Action buttons */}
              <div className="flex items-center space-x-1 opacity-0 group-hover:opacity-100 transition-opacity">
                {/* Audio call */}
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    startCall(friend, 'audio');
                  }}
                  className="p-1.5 rounded-lg hover:bg-emerald-50 dark:hover:bg-emerald-950/40 text-slate-400 hover:text-emerald-600"
                  title="Audio Call"
                >
                  <Phone className="w-3.5 h-3.5" />
                </button>

                {/* Video call */}
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    startCall(friend, 'video');
                  }}
                  className="p-1.5 rounded-lg hover:bg-pink-50 dark:hover:bg-pink-950/40 text-slate-400 hover:text-pink-600"
                  title="Video Call"
                >
                  <Video className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </aside>
  );
};
