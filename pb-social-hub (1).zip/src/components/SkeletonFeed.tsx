import React from 'react';

export const SkeletonFeed: React.FC = () => {
  return (
    <div className="space-y-4 animate-pulse">
      {[1, 2].map((i) => (
        <div
          key={i}
          className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200 dark:border-slate-800 shadow-sm"
        >
          {/* Header */}
          <div className="flex items-center space-x-3 mb-3">
            <div className="w-10 h-10 rounded-full bg-slate-200 dark:bg-slate-800" />
            <div className="space-y-2 flex-1">
              <div className="h-3.5 bg-slate-200 dark:bg-slate-800 rounded-md w-32" />
              <div className="h-2.5 bg-slate-200 dark:bg-slate-800 rounded-md w-20" />
            </div>
          </div>

          {/* Text lines */}
          <div className="space-y-2 mb-4">
            <div className="h-3 bg-slate-200 dark:bg-slate-800 rounded-md w-full" />
            <div className="h-3 bg-slate-200 dark:bg-slate-800 rounded-md w-4/5" />
            <div className="h-3 bg-slate-200 dark:bg-slate-800 rounded-md w-2/3" />
          </div>

          {/* Media box */}
          <div className="w-full h-56 bg-slate-200 dark:bg-slate-800 rounded-xl mb-4" />

          {/* Actions bar */}
          <div className="flex items-center justify-between pt-2 border-t border-slate-100 dark:border-slate-800">
            <div className="h-7 bg-slate-200 dark:bg-slate-800 rounded-lg w-20" />
            <div className="h-7 bg-slate-200 dark:bg-slate-800 rounded-lg w-20" />
            <div className="h-7 bg-slate-200 dark:bg-slate-800 rounded-lg w-20" />
          </div>
        </div>
      ))}
    </div>
  );
};
