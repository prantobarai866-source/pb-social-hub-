import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { CreateStoryModal } from './CreateStoryModal';
import { StoryViewerModal } from './StoryViewerModal';
import { Plus, Play, Sparkles } from 'lucide-react';

export const StoriesSection: React.FC = () => {
  const { currentUser, stories, language } = useApp();
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [activeStoryIndex, setActiveStoryIndex] = useState<number | null>(null);

  const ownStory = stories.find((s) => s.userId === currentUser.id);

  return (
    <div className="mb-4">
      <div className="flex space-x-2.5 overflow-x-auto pb-2 scrollbar-none snap-x">
        {/* Create / Add Story Card */}
        <div
          onClick={() => setIsCreateModalOpen(true)}
          className="relative flex-shrink-0 w-28 sm:w-32 h-44 sm:h-52 rounded-2xl overflow-hidden bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs cursor-pointer group hover:shadow-md transition-all flex flex-col justify-between select-none"
        >
          <div className="h-32 sm:h-38 w-full overflow-hidden relative">
            <img
              src={currentUser.avatar}
              alt={currentUser.name}
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
            />
            <div className="absolute inset-0 bg-black/10 group-hover:bg-transparent transition-colors" />
          </div>

          <div className="relative pt-4 pb-2 px-2 text-center bg-white dark:bg-slate-900 flex flex-col items-center">
            <div className="absolute -top-4 left-1/2 -translate-x-1/2 w-8 h-8 rounded-full bg-blue-600 group-hover:bg-blue-700 text-white flex items-center justify-center ring-4 ring-white dark:ring-slate-900 shadow-md transition-transform group-hover:scale-110">
              <Plus className="w-5 h-5 stroke-[2.5]" />
            </div>
            <span className="text-[11px] font-bold text-slate-800 dark:text-slate-200 truncate w-full">
              {language === 'bn' ? 'স্টোরি যোগ করুন' : 'Create story'}
            </span>
          </div>
        </div>

        {/* Stories list */}
        {stories.map((story, index) => {
          return (
            <div
              key={story.id}
              onClick={() => setActiveStoryIndex(index)}
              className="relative flex-shrink-0 w-28 sm:w-32 h-44 sm:h-52 rounded-2xl overflow-hidden shadow-xs cursor-pointer group hover:shadow-lg transition-all select-none border border-slate-200/50 dark:border-slate-800/80"
            >
              {/* Story preview image or video frame */}
              {story.mediaType === 'video' ? (
                <video
                  src={story.mediaUrl}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  muted
                  playsInline
                />
              ) : (
                <img
                  src={story.mediaUrl}
                  alt={story.userName}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
              )}

              {/* Dark Gradient Overlay */}
              <div className="absolute inset-0 bg-linear-to-b from-black/50 via-transparent to-black/80" />

              {/* Author Avatar with vibrant ring */}
              <div className="absolute top-2.5 left-2.5">
                <img
                  src={story.userAvatar}
                  alt={story.userName}
                  className="w-9 h-9 rounded-full object-cover ring-2 ring-blue-500 shadow-md"
                />
              </div>

              {/* Video indicator badge */}
              {story.mediaType === 'video' && (
                <div className="absolute top-3 right-3 p-1 rounded-full bg-black/60 backdrop-blur-xs text-white">
                  <Play className="w-2.5 h-2.5 fill-white" />
                </div>
              )}

              {/* Author Name */}
              <div className="absolute bottom-2.5 left-2.5 right-2.5">
                <p className="text-white text-xs font-semibold drop-shadow-md truncate">
                  {story.userName}
                </p>
                <p className="text-[10px] text-white/80 drop-shadow-xs">
                  {story.createdAt}
                </p>
              </div>
            </div>
          );
        })}
      </div>

      {/* Create Story Modal */}
      <CreateStoryModal
        isOpen={isCreateModalOpen}
        onClose={() => setIsCreateModalOpen(false)}
      />

      {/* Story Viewer Modal */}
      {activeStoryIndex !== null && (
        <StoryViewerModal
          stories={stories}
          initialIndex={activeStoryIndex}
          isOpen={activeStoryIndex !== null}
          onClose={() => setActiveStoryIndex(null)}
        />
      )}
    </div>
  );
};
