import React, { useState, useEffect, useRef } from 'react';
import { Story } from '../types';
import { useApp } from '../context/AppContext';
import confetti from 'canvas-confetti';
import {
  X,
  Play,
  Pause,
  Volume2,
  VolumeX,
  ChevronLeft,
  ChevronRight,
  Flame,
  Heart,
  Laugh,
  PartyPopper,
  Sparkles,
} from 'lucide-react';

interface StoryViewerModalProps {
  stories: Story[];
  initialIndex: number;
  isOpen: boolean;
  onClose: () => void;
}

const STORY_REACTIONS = [
  { emoji: '❤️', label: 'Love' },
  { emoji: '🔥', label: 'Fire' },
  { emoji: '😂', label: 'Laugh' },
  { emoji: '👏', label: 'Clap' },
  { emoji: '😮', label: 'Wow' },
  { emoji: '😢', label: 'Sad' },
];

export const StoryViewerModal: React.FC<StoryViewerModalProps> = ({
  stories,
  initialIndex,
  isOpen,
  onClose,
}) => {
  const { reactToStory, language } = useApp();
  const [currentIndex, setCurrentIndex] = useState(initialIndex);
  const [progress, setProgress] = useState(0);
  const [isPaused, setIsPaused] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [floatingReaction, setFloatingReaction] = useState<string | null>(null);

  const videoRef = useRef<HTMLVideoElement | null>(null);

  useEffect(() => {
    setCurrentIndex(initialIndex);
    setProgress(0);
  }, [initialIndex, isOpen]);

  const currentStory = stories[currentIndex];
  const storyDuration = (currentStory?.duration || 6) * 1000; // in ms

  // Progress timer for auto-advancing
  useEffect(() => {
    if (!isOpen || isPaused || !currentStory) return;

    const intervalTime = 50; // update every 50ms
    const step = (intervalTime / storyDuration) * 100;

    const timer = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          // Go to next story or close if last
          if (currentIndex < stories.length - 1) {
            setCurrentIndex((idx) => idx + 1);
            return 0;
          } else {
            onClose();
            return 100;
          }
        }
        return prev + step;
      });
    }, intervalTime);

    return () => clearInterval(timer);
  }, [isOpen, isPaused, currentIndex, storyDuration, stories.length, onClose, currentStory]);

  if (!isOpen || !currentStory) return null;

  const handleNext = () => {
    if (currentIndex < stories.length - 1) {
      setCurrentIndex((prev) => prev + 1);
      setProgress(0);
    } else {
      onClose();
    }
  };

  const handlePrev = () => {
    if (currentIndex > 0) {
      setCurrentIndex((prev) => prev - 1);
      setProgress(0);
    }
  };

  const handleSendReaction = (emoji: string) => {
    reactToStory(currentStory.id, emoji);
    setFloatingReaction(emoji);

    // Trigger subtle celebratory animation
    confetti({
      particleCount: 25,
      spread: 60,
      origin: { y: 0.8 },
      colors: ['#ef4444', '#f59e0b', '#ec4899', '#3b82f6'],
    });

    setTimeout(() => {
      setFloatingReaction(null);
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/95 backdrop-blur-md p-0 sm:p-4 select-none animate-in fade-in duration-150">
      {/* Container */}
      <div className="relative w-full max-w-sm h-full sm:h-[88vh] max-h-[850px] bg-black sm:rounded-3xl overflow-hidden shadow-2xl flex flex-col justify-between">
        {/* Top Progress Bars */}
        <div className="absolute top-0 left-0 right-0 p-3 z-30 flex space-x-1.5 bg-linear-to-b from-black/80 via-black/40 to-transparent">
          {stories.map((s, idx) => {
            let barWidth = '0%';
            if (idx < currentIndex) barWidth = '100%';
            else if (idx === currentIndex) barWidth = `${progress}%`;

            return (
              <div
                key={s.id}
                className="h-1 flex-1 bg-white/30 rounded-full overflow-hidden"
              >
                <div
                  className="h-full bg-white transition-all ease-linear"
                  style={{ width: barWidth }}
                />
              </div>
            );
          })}
        </div>

        {/* Story Header (Author + Controls) */}
        <div className="absolute top-6 left-0 right-0 px-4 py-2 z-30 flex items-center justify-between text-white">
          <div className="flex items-center space-x-2.5">
            <img
              src={currentStory.userAvatar}
              alt={currentStory.userName}
              className="w-9 h-9 rounded-full object-cover ring-2 ring-blue-500"
            />
            <div>
              <p className="text-xs font-bold leading-tight drop-shadow-md">
                {currentStory.userName}
              </p>
              <p className="text-[10px] text-white/80 drop-shadow-md">
                {currentStory.createdAt}
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            {/* Play/Pause */}
            <button
              onClick={() => setIsPaused(!isPaused)}
              className="p-1.5 rounded-full bg-black/40 hover:bg-black/60 backdrop-blur-md text-white transition-colors"
              title={isPaused ? 'Play' : 'Pause'}
            >
              {isPaused ? <Play className="w-4 h-4" /> : <Pause className="w-4 h-4" />}
            </button>

            {/* Sound Toggle for video */}
            {currentStory.mediaType === 'video' && (
              <button
                onClick={() => setIsMuted(!isMuted)}
                className="p-1.5 rounded-full bg-black/40 hover:bg-black/60 backdrop-blur-md text-white transition-colors"
                title={isMuted ? 'Unmute' : 'Mute'}
              >
                {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
              </button>
            )}

            {/* Close */}
            <button
              onClick={onClose}
              className="p-1.5 rounded-full bg-black/40 hover:bg-black/60 backdrop-blur-md text-white transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Media Container */}
        <div
          className="relative flex-1 w-full h-full flex items-center justify-center bg-black overflow-hidden"
          onMouseDown={() => setIsPaused(true)}
          onMouseUp={() => setIsPaused(false)}
          onTouchStart={() => setIsPaused(true)}
          onTouchEnd={() => setIsPaused(false)}
        >
          {currentStory.mediaType === 'video' ? (
            <video
              ref={videoRef}
              src={currentStory.mediaUrl}
              autoPlay
              playsInline
              loop
              muted={isMuted}
              className="w-full h-full object-cover"
            />
          ) : (
            <img
              src={currentStory.mediaUrl}
              alt="Story"
              className="w-full h-full object-cover"
            />
          )}

          {/* Floating animated reaction */}
          {floatingReaction && (
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-40 animate-in zoom-in-50 fade-out duration-1000">
              <span className="text-7xl drop-shadow-2xl">{floatingReaction}</span>
            </div>
          )}

          {/* Story Caption */}
          {currentStory.caption && (
            <div className="absolute bottom-20 left-4 right-4 bg-black/60 backdrop-blur-md px-4 py-2.5 rounded-2xl text-center text-white text-xs font-medium z-20">
              {currentStory.caption}
            </div>
          )}

          {/* Navigation Click Zones */}
          <div
            onClick={handlePrev}
            className="absolute left-0 top-16 bottom-20 w-1/3 z-10 cursor-pointer"
          />
          <div
            onClick={handleNext}
            className="absolute right-0 top-16 bottom-20 w-1/3 z-10 cursor-pointer"
          />
        </div>

        {/* Navigation Arrows for desktop */}
        {currentIndex > 0 && (
          <button
            onClick={handlePrev}
            className="hidden sm:flex absolute -left-14 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-white/20 hover:bg-white/40 text-white backdrop-blur-md items-center justify-center transition-all"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>
        )}

        {currentIndex < stories.length - 1 && (
          <button
            onClick={handleNext}
            className="hidden sm:flex absolute -right-14 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-white/20 hover:bg-white/40 text-white backdrop-blur-md items-center justify-center transition-all"
          >
            <ChevronRight className="w-6 h-6" />
          </button>
        )}

        {/* Reaction Bar Footer */}
        <div className="absolute bottom-0 left-0 right-0 p-3.5 z-30 bg-linear-to-t from-black via-black/80 to-transparent">
          <div className="flex items-center justify-around bg-white/15 backdrop-blur-md py-2 px-3 rounded-full border border-white/20">
            {STORY_REACTIONS.map((r) => (
              <button
                key={r.label}
                onClick={() => handleSendReaction(r.emoji)}
                className="text-2xl hover:scale-130 active:scale-95 transition-transform"
                title={`Send ${r.label}`}
              >
                {r.emoji}
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
