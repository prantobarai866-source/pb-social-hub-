import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  User,
  Post,
  Story,
  Reel,
  NotificationItem,
  Group,
  ReactionType,
  ActiveCall,
  ChatMessage,
  GameRoom,
} from '../types';
import {
  CURRENT_USER,
  INITIAL_FRIENDS,
  INITIAL_FRIEND_REQUESTS,
  INITIAL_POSTS,
  INITIAL_STORIES,
  INITIAL_REELS,
  INITIAL_NOTIFICATIONS,
  INITIAL_GROUPS,
  INITIAL_GAME_ROOMS,
  INITIAL_GOOGLE_ACCOUNTS,
} from '../data/initialData';
import { GoogleAccount } from '../types';

interface AppContextType {
  currentUser: User;
  setCurrentUser: React.Dispatch<React.SetStateAction<User>>;
  posts: Post[];
  stories: Story[];
  reels: Reel[];
  groups: Group[];
  friends: User[];
  friendRequests: User[];
  notifications: NotificationItem[];
  blockedUserIds: string[];
  gameRooms: GameRoom[];
  theme: 'light' | 'dark';
  setTheme: (theme: 'light' | 'dark') => void;
  toggleTheme: () => void;
  language: 'en' | 'bn';
  setLanguage: (lang: 'en' | 'bn') => void;
  activeTab: 'feed' | 'reels' | 'friends' | 'groups' | 'gaming' | 'profile';
  setActiveTab: (tab: 'feed' | 'reels' | 'friends' | 'groups' | 'gaming' | 'profile') => void;
  selectedUserId: string | null;
  setSelectedUserId: (userId: string | null) => void;
  selectedGroupId: string | null;
  setSelectedGroupId: (groupId: string | null) => void;
  activeReelIndex: number;
  setActiveReelIndex: (idx: number) => void;

  // Google Authentication
  isLoggedIn: boolean;
  googleAccounts: GoogleAccount[];
  isGoogleAuthModalOpen: boolean;
  setIsGoogleAuthModalOpen: (open: boolean) => void;
  loginWithGoogleAccount: (account: GoogleAccount) => void;
  signInWithNewGoogleEmail: (email: string, name: string) => void;
  logout: () => void;

  // Settings
  isSettingsModalOpen: boolean;
  setIsSettingsModalOpen: (open: boolean) => void;

  // Create Reel Modal
  isCreateReelModalOpen: boolean;
  setIsCreateReelModalOpen: (open: boolean) => void;
  
  // Saved Posts
  savedPostIds: string[];
  toggleSavePost: (postId: string) => void;
  isPostSaved: (postId: string) => boolean;

  // Post & Comment actions
  addPost: (
    content: string,
    mediaUrl?: string,
    mediaType?: 'image' | 'video',
    groupId?: string,
    pollData?: { question: string; options: string[] },
    scheduledFor?: string,
    bgGradient?: string
  ) => void;
  deletePost: (postId: string) => void;
  togglePostReaction: (postId: string, type: ReactionType) => void;
  votePoll: (postId: string, optionId: string) => void;
  addComment: (postId: string, content: string) => void;
  toggleCommentReaction: (postId: string, commentId: string, type: ReactionType) => void;
  sharePost: (postId: string, targetGroupId?: string) => void;
  
  // Story actions
  addStory: (mediaUrl: string, mediaType: 'image' | 'video', caption?: string, duration?: number) => void;
  reactToStory: (storyId: string, emoji: string) => void;
  
  // Reel actions
  addReel: (videoUrl: string, caption: string, audioTrack: string) => void;
  toggleReelLike: (reelId: string) => void;
  
  // Friend & Block actions
  sendFriendRequest: (userId: string) => void;
  acceptFriendRequest: (userId: string) => void;
  rejectFriendRequest: (userId: string) => void;
  blockUser: (userId: string) => void;
  unblockUser: (userId: string) => void;
  
  // Notifications
  markNotificationAsRead: (notifId: string) => void;
  markAllNotificationsAsRead: () => void;
  triggerActivityAlert: (type?: 'reaction' | 'comment') => void;
  
  // Groups
  joinGroup: (groupId: string) => void;
  leaveGroup: (groupId: string) => void;
  handleGroupJoinRequest: (groupId: string, requestId: string, accept: boolean) => void;
  
  // Calling
  activeCall: ActiveCall | null;
  startCall: (partner: User, type: 'audio' | 'video') => void;
  endCall: () => void;
  toggleCallMute: () => void;
  toggleCallVideo: () => void;
  
  // Messenger
  activeChatUser: User | null;
  setActiveChatUser: (user: User | null) => void;
  chatMessages: Record<string, ChatMessage[]>;
  sendMessage: (partnerId: string, text: string, mediaUrl?: string) => void;

  // Games
  joinGameRoom: (roomId: string) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

// Safe storage utilities to avoid Uncaught JSON SyntaxError and DOMException QuotaExceededError
function safeGetStorage<T>(key: string, fallback: T): T {
  try {
    const item = localStorage.getItem(key);
    if (!item || item === 'undefined' || item === 'null') return fallback;
    const parsed = JSON.parse(item);
    if (parsed === null || parsed === undefined) return fallback;
    return parsed;
  } catch (err) {
    console.warn(`[BondhuNet] Error loading "${key}" from storage:`, err);
    return fallback;
  }
}

function safeSetStorage(key: string, value: unknown): void {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch (err) {
    console.warn(`[BondhuNet] Error saving "${key}" to storage:`, err);
  }
}

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Theme state
  const [theme, setThemeState] = useState<'light' | 'dark'>(() => {
    try {
      const saved = localStorage.getItem('bondhu_theme');
      if (saved === 'dark' || saved === 'light') return saved;
      return window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
    } catch {
      return 'light';
    }
  });

  const [language, setLanguageState] = useState<'en' | 'bn'>(() => {
    try {
      return (localStorage.getItem('bondhu_lang') as 'en' | 'bn') || 'en';
    } catch {
      return 'en';
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem('bondhu_theme', theme);
    } catch (e) {
      console.warn('Storage set failed:', e);
    }
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [theme]);

  const setTheme = (newTheme: 'light' | 'dark') => {
    setThemeState(newTheme);
  };

  const toggleTheme = () => {
    setThemeState((prev) => (prev === 'light' ? 'dark' : 'light'));
  };

  const setLanguage = (lang: 'en' | 'bn') => {
    setLanguageState(lang);
    try {
      localStorage.setItem('bondhu_lang', lang);
    } catch (e) {
      console.warn('Storage set failed:', e);
    }
  };

  // State with safe localStorage backing & schema validation
  const [currentUser, setCurrentUser] = useState<User>(() => {
    const saved = safeGetStorage<Partial<User>>('bondhu_user', CURRENT_USER);
    return {
      ...CURRENT_USER,
      ...saved,
      name: saved?.name || CURRENT_USER.name,
      username: saved?.username || CURRENT_USER.username,
      avatar: saved?.avatar || CURRENT_USER.avatar,
      email: saved?.email || CURRENT_USER.email,
    };
  });

  const [posts, setPosts] = useState<Post[]>(() => {
    const saved = safeGetStorage<Post[]>('bondhu_posts', INITIAL_POSTS);
    return Array.isArray(saved) && saved.length > 0 ? saved : INITIAL_POSTS;
  });

  const [stories, setStories] = useState<Story[]>(() => {
    const saved = safeGetStorage<Story[]>('bondhu_stories', INITIAL_STORIES);
    return Array.isArray(saved) && saved.length > 0 ? saved : INITIAL_STORIES;
  });

  const [reels, setReels] = useState<Reel[]>(() => {
    const saved = safeGetStorage<Reel[]>('bondhu_reels', INITIAL_REELS);
    return Array.isArray(saved) && saved.length > 0 ? saved : INITIAL_REELS;
  });

  const [groups, setGroups] = useState<Group[]>(() => {
    const saved = safeGetStorage<Group[]>('bondhu_groups', INITIAL_GROUPS);
    return Array.isArray(saved) && saved.length > 0 ? saved : INITIAL_GROUPS;
  });

  const [friends, setFriends] = useState<User[]>(() => {
    const saved = safeGetStorage<User[]>('bondhu_friends', INITIAL_FRIENDS);
    return Array.isArray(saved) && saved.length > 0 ? saved : INITIAL_FRIENDS;
  });

  const [friendRequests, setFriendRequests] = useState<User[]>(() => {
    const saved = safeGetStorage<User[]>('bondhu_requests', INITIAL_FRIEND_REQUESTS);
    return Array.isArray(saved) ? saved : INITIAL_FRIEND_REQUESTS;
  });

  const [notifications, setNotifications] = useState<NotificationItem[]>(() => {
    const saved = safeGetStorage<NotificationItem[]>('bondhu_notifs', INITIAL_NOTIFICATIONS);
    return Array.isArray(saved) && saved.length > 0 ? saved : INITIAL_NOTIFICATIONS;
  });

  const [blockedUserIds, setBlockedUserIds] = useState<string[]>(() => {
    const saved = safeGetStorage<string[]>('bondhu_blocked', []);
    return Array.isArray(saved) ? saved : [];
  });

  const [gameRooms, setGameRooms] = useState<GameRoom[]>(() => {
    const saved = safeGetStorage<GameRoom[]>('bondhu_games', INITIAL_GAME_ROOMS);
    return Array.isArray(saved) && saved.length > 0 ? saved : INITIAL_GAME_ROOMS;
  });

  const [savedPostIds, setSavedPostIds] = useState<string[]>(() => {
    const saved = safeGetStorage<string[]>('bondhu_saved', ['post_1']);
    return Array.isArray(saved) ? saved : ['post_1'];
  });

  // Google Authentication & Accounts state
  const [isLoggedIn, setIsLoggedIn] = useState<boolean>(() => {
    return safeGetStorage<boolean>('bondhu_logged_in', true);
  });

  const [googleAccounts, setGoogleAccounts] = useState<GoogleAccount[]>(() => {
    const saved = safeGetStorage<GoogleAccount[]>('bondhu_google_accounts', INITIAL_GOOGLE_ACCOUNTS);
    return Array.isArray(saved) && saved.length > 0 ? saved : INITIAL_GOOGLE_ACCOUNTS;
  });

  const [isGoogleAuthModalOpen, setIsGoogleAuthModalOpen] = useState(false);
  const [isSettingsModalOpen, setIsSettingsModalOpen] = useState(false);
  const [isCreateReelModalOpen, setIsCreateReelModalOpen] = useState(false);

  useEffect(() => {
    safeSetStorage('bondhu_logged_in', isLoggedIn);
  }, [isLoggedIn]);

  useEffect(() => {
    safeSetStorage('bondhu_google_accounts', googleAccounts);
  }, [googleAccounts]);

  const loginWithGoogleAccount = (account: GoogleAccount) => {
    setGoogleAccounts((prev) =>
      prev.map((acc) => ({ ...acc, isActive: acc.id === account.id }))
    );
    setCurrentUser((prev) => ({
      ...prev,
      name: account.name,
      email: account.email,
      avatar: account.avatar,
      authProvider: 'google',
    }));
    setIsLoggedIn(true);
    setIsGoogleAuthModalOpen(false);

    // Add notification
    const welcomeNotif: NotificationItem = {
      id: `notif_${Date.now()}`,
      userId: currentUser.id,
      senderId: 'google_system',
      senderName: 'Google Security',
      senderAvatar: 'https://www.gstatic.com/images/branding/product/2x/googleg_48dp.png',
      type: 'system',
      text: `Signed in successfully with Google (${account.email})`,
      createdAt: 'Just now',
      isRead: false,
    };
    setNotifications((prev) => [welcomeNotif, ...prev]);
  };

  const signInWithNewGoogleEmail = (email: string, name: string) => {
    const newAcc: GoogleAccount = {
      id: `g_acc_${Date.now()}`,
      name: name.trim() || email.split('@')[0],
      email: email.trim(),
      avatar: `https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=400&auto=format&fit=crop&q=80`,
      isActive: true,
    };
    setGoogleAccounts((prev) => [
      newAcc,
      ...prev.map((acc) => ({ ...acc, isActive: false })),
    ]);
    setCurrentUser((prev) => ({
      ...prev,
      name: newAcc.name,
      email: newAcc.email,
      avatar: newAcc.avatar,
      authProvider: 'google',
    }));
    setIsLoggedIn(true);
    setIsGoogleAuthModalOpen(false);
  };

  const logout = () => {
    setIsLoggedIn(false);
    setIsGoogleAuthModalOpen(true);
  };

  const [activeTab, setActiveTab] = useState<'feed' | 'reels' | 'friends' | 'groups' | 'gaming' | 'profile'>('feed');
  const [selectedUserId, setSelectedUserId] = useState<string | null>(null);
  const [selectedGroupId, setSelectedGroupId] = useState<string | null>(null);
  const [activeReelIndex, setActiveReelIndex] = useState<number>(0);

  // Sync state changes to storage safely
  useEffect(() => {
    safeSetStorage('bondhu_user', currentUser);
  }, [currentUser]);

  useEffect(() => {
    safeSetStorage('bondhu_posts', posts);
  }, [posts]);

  useEffect(() => {
    safeSetStorage('bondhu_stories', stories);
  }, [stories]);

  useEffect(() => {
    safeSetStorage('bondhu_reels', reels);
  }, [reels]);

  useEffect(() => {
    safeSetStorage('bondhu_groups', groups);
  }, [groups]);

  useEffect(() => {
    safeSetStorage('bondhu_friends', friends);
  }, [friends]);

  useEffect(() => {
    safeSetStorage('bondhu_requests', friendRequests);
  }, [friendRequests]);

  useEffect(() => {
    safeSetStorage('bondhu_notifs', notifications);
  }, [notifications]);

  useEffect(() => {
    safeSetStorage('bondhu_blocked', blockedUserIds);
  }, [blockedUserIds]);

  useEffect(() => {
    safeSetStorage('bondhu_saved', savedPostIds);
  }, [savedPostIds]);

  const toggleSavePost = (postId: string) => {
    setSavedPostIds((prev) =>
      prev.includes(postId) ? prev.filter((id) => id !== postId) : [postId, ...prev]
    );
  };

  const isPostSaved = (postId: string) => savedPostIds.includes(postId);

  // Calling state
  const [activeCall, setActiveCall] = useState<ActiveCall | null>(null);

  // Messenger state
  const [activeChatUser, setActiveChatUser] = useState<User | null>(null);
  const [chatMessages, setChatMessages] = useState<Record<string, ChatMessage[]>>({
    user_1: [
      { id: 'm1', senderId: 'user_1', text: 'Hey Tanvir! Are you free for a quick call?', createdAt: '10:30 AM', isRead: true },
      { id: 'm2', senderId: 'user_me', text: 'Yes, just testing the new platform update!', createdAt: '10:32 AM', isRead: true },
    ],
    user_2: [
      { id: 'm3', senderId: 'user_2', text: 'Love the camera snapshot feature in the new post box!', createdAt: 'Yesterday', isRead: true },
    ],
  });

  // Post Actions
  const addPost = (
    content: string,
    mediaUrl?: string,
    mediaType?: 'image' | 'video',
    groupId?: string,
    pollData?: { question: string; options: string[] },
    scheduledFor?: string,
    bgGradient?: string
  ) => {
    const targetGroup = groupId ? groups.find((g) => g.id === groupId) : undefined;

    let pollObj: Post['poll'] = undefined;
    if (pollData && pollData.question.trim() && pollData.options && pollData.options.length >= 2) {
      const validOptions = pollData.options.filter((opt) => opt.trim());
      if (validOptions.length >= 2) {
        pollObj = {
          question: pollData.question.trim(),
          options: validOptions.map((optText, index) => ({
            id: `opt_${Date.now()}_${index}`,
            text: optText.trim(),
            votes: 0,
            voters: [],
          })),
          totalVotes: 0,
        };
      }
    }

    const newPost: Post = {
      id: `post_${Date.now()}`,
      userId: currentUser.id,
      userName: currentUser.name,
      userAvatar: currentUser.avatar,
      userVerified: currentUser.isVerified,
      content,
      mediaUrl,
      mediaType,
      bgGradient,
      createdAt: scheduledFor
        ? `Scheduled for ${new Date(scheduledFor).toLocaleDateString([], {
            month: 'short',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit',
          })}`
        : 'Just now',
      privacy: 'public',
      reactions: { like: 0, love: 0, care: 0, haha: 0, wow: 0, sad: 0, angry: 0 },
      commentsCount: 0,
      comments: [],
      sharesCount: 0,
      groupId,
      groupName: targetGroup?.name,
      poll: pollObj,
      scheduledFor,
      isScheduled: !!scheduledFor,
    };
    setPosts((prev) => [newPost, ...prev]);
  };

  const deletePost = (postId: string) => {
    setPosts((prev) => prev.filter((p) => p.id !== postId));
  };

  const votePoll = (postId: string, optionId: string) => {
    setPosts((prev) =>
      prev.map((post) => {
        if (post.id !== postId || !post.poll) return post;
        const currentPoll = post.poll;
        const currentVotedId = currentPoll.userVotedOptionId;

        // If clicking the already selected option, unvote
        if (currentVotedId === optionId) {
          const updatedOptions = currentPoll.options.map((opt) => {
            if (opt.id === optionId) {
              return {
                ...opt,
                votes: Math.max(0, opt.votes - 1),
                voters: opt.voters.filter((uid) => uid !== currentUser.id),
              };
            }
            return opt;
          });
          return {
            ...post,
            poll: {
              ...currentPoll,
              options: updatedOptions,
              totalVotes: Math.max(0, currentPoll.totalVotes - 1),
              userVotedOptionId: undefined,
            },
          };
        }

        // Vote for optionId (and unvote previous option if switched)
        const updatedOptions = currentPoll.options.map((opt) => {
          if (opt.id === optionId) {
            return {
              ...opt,
              votes: opt.votes + 1,
              voters: opt.voters.includes(currentUser.id) ? opt.voters : [...opt.voters, currentUser.id],
            };
          }
          if (currentVotedId && opt.id === currentVotedId) {
            return {
              ...opt,
              votes: Math.max(0, opt.votes - 1),
              voters: opt.voters.filter((uid) => uid !== currentUser.id),
            };
          }
          return opt;
        });

        const newTotalVotes = currentVotedId
          ? currentPoll.totalVotes
          : currentPoll.totalVotes + 1;

        return {
          ...post,
          poll: {
            ...currentPoll,
            options: updatedOptions,
            totalVotes: newTotalVotes,
            userVotedOptionId: optionId,
          },
        };
      })
    );
  };

  const togglePostReaction = (postId: string, type: ReactionType) => {
    setPosts((prev) =>
      prev.map((post) => {
        if (post.id !== postId) return post;
        const currentReaction = post.userReaction;
        const newReactions = { ...post.reactions };

        if (currentReaction === type) {
          // Deselect reaction
          newReactions[type] = Math.max(0, newReactions[type] - 1);
          return { ...post, reactions: newReactions, userReaction: undefined };
        }

        // If had a previous reaction, decrement that
        if (currentReaction) {
          newReactions[currentReaction] = Math.max(0, newReactions[currentReaction] - 1);
        }
        newReactions[type] = (newReactions[type] || 0) + 1;

        // If not own post, create notification
        if (post.userId !== currentUser.id) {
          const emojiMap: Record<ReactionType, string> = {
            like: '👍',
            love: '❤️',
            care: '🥰',
            haha: '😂',
            wow: '😮',
            sad: '😢',
            angry: '😡',
          };
          const newNotif: NotificationItem = {
            id: `notif_${Date.now()}`,
            userId: post.userId,
            senderId: currentUser.id,
            senderName: currentUser.name,
            senderAvatar: currentUser.avatar,
            type: 'like_post',
            text: `reacted ${emojiMap[type]} to your post`,
            targetId: post.id,
            createdAt: 'Just now',
            isRead: false,
            reactionEmoji: emojiMap[type],
          };
          setNotifications((n) => [newNotif, ...n]);
        }

        return { ...post, reactions: newReactions, userReaction: type };
      })
    );
  };

  const addComment = (postId: string, content: string) => {
    if (!content.trim()) return;
    const newComment = {
      id: `c_${Date.now()}`,
      postId,
      userId: currentUser.id,
      userName: currentUser.name,
      userAvatar: currentUser.avatar,
      content: content.trim(),
      createdAt: 'Just now',
      reactions: { like: 0, love: 0, care: 0, haha: 0, wow: 0, sad: 0, angry: 0 },
      likesCount: 0,
    };

    setPosts((prev) =>
      prev.map((post) => {
        if (post.id !== postId) return post;
        // If commenting on someone else's post, notify
        if (post.userId !== currentUser.id) {
          const newNotif: NotificationItem = {
            id: `notif_${Date.now()}`,
            userId: post.userId,
            senderId: currentUser.id,
            senderName: currentUser.name,
            senderAvatar: currentUser.avatar,
            type: 'comment_post',
            text: `commented on your post: "${content.slice(0, 30)}${content.length > 30 ? '...' : ''}"`,
            targetId: post.id,
            createdAt: 'Just now',
            isRead: false,
          };
          setNotifications((n) => [newNotif, ...n]);
        }
        return {
          ...post,
          commentsCount: post.commentsCount + 1,
          comments: [...post.comments, newComment],
        };
      })
    );
  };

  const toggleCommentReaction = (postId: string, commentId: string, type: ReactionType) => {
    setPosts((prev) =>
      prev.map((post) => {
        if (post.id !== postId) return post;

        const updatedComments = post.comments.map((comment) => {
          if (comment.id !== commentId) return comment;

          const currentReaction = comment.userReaction;
          const reactions = { ...comment.reactions };

          let newReaction: ReactionType | undefined = type;
          if (currentReaction === type) {
            reactions[type] = Math.max(0, reactions[type] - 1);
            newReaction = undefined;
          } else {
            if (currentReaction) {
              reactions[currentReaction] = Math.max(0, reactions[currentReaction] - 1);
            }
            reactions[type] = (reactions[type] || 0) + 1;
          }

          const totalLikes = Object.values(reactions).reduce((a, b) => a + b, 0);

          // Add notification for comment owner if someone else reacted
          if (newReaction && comment.userId !== currentUser.id) {
            const emojiMap: Record<ReactionType, string> = {
              like: '👍',
              love: '❤️',
              care: '🥰',
              haha: '😂',
              wow: '😮',
              sad: '😢',
              angry: '😡',
            };
            const newNotif: NotificationItem = {
              id: `notif_${Date.now()}`,
              userId: comment.userId,
              senderId: currentUser.id,
              senderName: currentUser.name,
              senderAvatar: currentUser.avatar,
              type: 'react_comment',
              text: `reacted ${emojiMap[type]} to your comment`,
              targetId: postId,
              createdAt: 'Just now',
              isRead: false,
              reactionEmoji: emojiMap[type],
            };
            setNotifications((n) => [newNotif, ...n]);
          }

          return {
            ...comment,
            reactions,
            userReaction: newReaction,
            likesCount: totalLikes,
          };
        });

        return { ...post, comments: updatedComments };
      })
    );
  };

  const sharePost = (postId: string, targetGroupId?: string) => {
    setPosts((prev) =>
      prev.map((p) => (p.id === postId ? { ...p, sharesCount: p.sharesCount + 1 } : p))
    );
    const originalPost = posts.find((p) => p.id === postId);
    if (!originalPost) return;

    // Create a new post representing the share
    const sharedPost: Post = {
      id: `post_${Date.now()}`,
      userId: currentUser.id,
      userName: currentUser.name,
      userAvatar: currentUser.avatar,
      userVerified: currentUser.isVerified,
      content: `Shared ${originalPost.userName}'s post:\n\n"${originalPost.content}"`,
      mediaUrl: originalPost.mediaUrl,
      mediaType: originalPost.mediaType,
      createdAt: 'Just now',
      privacy: 'public',
      reactions: { like: 0, love: 0, care: 0, haha: 0, wow: 0, sad: 0, angry: 0 },
      commentsCount: 0,
      comments: [],
      sharesCount: 0,
      groupId: targetGroupId,
    };
    setPosts((prev) => [sharedPost, ...prev]);

    if (originalPost.userId !== currentUser.id) {
      const newNotif: NotificationItem = {
        id: `notif_${Date.now()}`,
        userId: originalPost.userId,
        senderId: currentUser.id,
        senderName: currentUser.name,
        senderAvatar: currentUser.avatar,
        type: 'share_post',
        text: `shared your post to their timeline`,
        targetId: postId,
        createdAt: 'Just now',
        isRead: false,
      };
      setNotifications((n) => [newNotif, ...n]);
    }
  };

  // Story Actions
  const addStory = (mediaUrl: string, mediaType: 'image' | 'video', caption?: string, duration = 6) => {
    const newStory: Story = {
      id: `story_${Date.now()}`,
      userId: currentUser.id,
      userName: 'Your Story',
      userAvatar: currentUser.avatar,
      mediaUrl,
      mediaType,
      caption,
      duration,
      createdAt: 'Just now',
      viewsCount: 1,
      reactions: [],
    };
    // If user already has a story, replace or prepend
    setStories((prev) => [newStory, ...prev.filter((s) => s.userId !== currentUser.id)]);
  };

  const reactToStory = (storyId: string, emoji: string) => {
    setStories((prev) =>
      prev.map((s) => {
        if (s.id !== storyId) return s;
        const newReaction = {
          userId: currentUser.id,
          userName: currentUser.name,
          emoji,
          createdAt: 'Just now',
        };

        // If reacting to someone else's story, send notification
        if (s.userId !== currentUser.id) {
          const newNotif: NotificationItem = {
            id: `notif_${Date.now()}`,
            userId: s.userId,
            senderId: currentUser.id,
            senderName: currentUser.name,
            senderAvatar: currentUser.avatar,
            type: 'react_story',
            text: `reacted ${emoji} to your story`,
            targetId: storyId,
            createdAt: 'Just now',
            isRead: false,
            reactionEmoji: emoji,
          };
          setNotifications((n) => [newNotif, ...n]);
        }

        return {
          ...s,
          reactions: [...s.reactions, newReaction],
        };
      })
    );
  };

  // Reel Actions
  const addReel = (videoUrl: string, caption: string, audioTrack: string) => {
    const newReel: Reel = {
      id: `reel_${Date.now()}`,
      userId: currentUser.id,
      userName: currentUser.name,
      userAvatar: currentUser.avatar,
      videoUrl,
      caption,
      audioTrack: audioTrack || `Original Audio - ${currentUser.username}`,
      likesCount: 1,
      commentsCount: 0,
      sharesCount: 0,
      viewsCount: 12,
      isLiked: true,
      createdAt: 'Just now',
      watchTimeSeconds: 45,
    };
    setReels((prev) => [newReel, ...prev]);
  };

  const toggleReelLike = (reelId: string) => {
    setReels((prev) =>
      prev.map((reel) => {
        if (reel.id !== reelId) return reel;
        const isLiked = !reel.isLiked;
        return {
          ...reel,
          isLiked,
          likesCount: isLiked ? reel.likesCount + 1 : Math.max(0, reel.likesCount - 1),
        };
      })
    );
  };

  // Friend & Block actions
  const sendFriendRequest = (userId: string) => {
    // Notify or mark requested
    const targetUser = friends.find((u) => u.id === userId);
    if (!targetUser) return;

    const notif: NotificationItem = {
      id: `notif_${Date.now()}`,
      userId: userId,
      senderId: currentUser.id,
      senderName: currentUser.name,
      senderAvatar: currentUser.avatar,
      type: 'friend_request',
      text: 'sent you a friend request',
      createdAt: 'Just now',
      isRead: false,
    };
    setNotifications((n) => [notif, ...n]);
  };

  const acceptFriendRequest = (userId: string) => {
    const reqUser = friendRequests.find((r) => r.id === userId);
    if (!reqUser) return;

    setFriendRequests((prev) => prev.filter((r) => r.id !== userId));
    setFriends((prev) => [reqUser, ...prev]);
    setCurrentUser((prev) => ({ ...prev, friendsCount: prev.friendsCount + 1 }));

    // Send notification
    const notif: NotificationItem = {
      id: `notif_${Date.now()}`,
      userId: userId,
      senderId: currentUser.id,
      senderName: currentUser.name,
      senderAvatar: currentUser.avatar,
      type: 'friend_accept',
      text: 'accepted your friend request',
      createdAt: 'Just now',
      isRead: false,
    };
    setNotifications((n) => [notif, ...n]);
  };

  const rejectFriendRequest = (userId: string) => {
    setFriendRequests((prev) => prev.filter((r) => r.id !== userId));
  };

  const blockUser = (userId: string) => {
    if (!blockedUserIds.includes(userId)) {
      setBlockedUserIds((prev) => [...prev, userId]);
    }
    // Remove from friends
    setFriends((prev) => prev.filter((f) => f.id !== userId));
    // Close chat if open
    if (activeChatUser?.id === userId) {
      setActiveChatUser(null);
    }
    // Redirect to feed if viewing their profile
    if (selectedUserId === userId) {
      setSelectedUserId(null);
      setActiveTab('feed');
    }
  };

  const unblockUser = (userId: string) => {
    setBlockedUserIds((prev) => prev.filter((id) => id !== userId));
  };

  // Notification actions
  const markNotificationAsRead = (notifId: string) => {
    setNotifications((prev) =>
      prev.map((n) => (n.id === notifId ? { ...n, isRead: true } : n))
    );
  };

  const markAllNotificationsAsRead = () => {
    setNotifications((prev) => prev.map((n) => ({ ...n, isRead: true })));
  };

  const triggerActivityAlert = (type?: 'reaction' | 'comment') => {
    const friendList = friends.length > 0 ? friends : [
      { id: 'user_1', name: 'Nusrat Jahan', avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=400&auto=format&fit=crop&q=80' },
      { id: 'user_2', name: 'Rafiqul Islam', avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&auto=format&fit=crop&q=80' },
      { id: 'user_3', name: 'Sabrina Chowdhury', avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=400&auto=format&fit=crop&q=80' },
    ];
    const randomFriend = friendList[Math.floor(Math.random() * friendList.length)];
    const chosenType = type || (Math.random() > 0.5 ? 'reaction' : 'comment');

    const reactionEmojis = ['❤️', '👍', '🔥', '🥰', '👏', '😍'];
    const randomEmoji = reactionEmojis[Math.floor(Math.random() * reactionEmojis.length)];
    const comments = [
      'দারুণ পোস্ট করেছেন! অনেক ভালো লেগেছে 👌',
      'Awesome picture & wonderful caption! 🔥',
      'দারুণ লিখেছেন! আপনার সাথে সম্পূর্ণ একমত 👍',
      'What a wonderful moment! Keep it up ✨',
    ];
    const randomComment = comments[Math.floor(Math.random() * comments.length)];

    const newAlert: NotificationItem = {
      id: `notif_${Date.now()}`,
      userId: currentUser.id,
      senderId: randomFriend.id,
      senderName: randomFriend.name,
      senderAvatar: randomFriend.avatar,
      type: chosenType === 'reaction' ? 'react_comment' : 'comment_post',
      text: chosenType === 'reaction'
        ? `reacted ${randomEmoji} to your recent post`
        : `commented on your post: "${randomComment}"`,
      targetId: posts[0]?.id || 'post_1',
      createdAt: 'Just now',
      isRead: false,
      reactionEmoji: chosenType === 'reaction' ? randomEmoji : undefined,
    };

    setNotifications((prev) => [newAlert, ...prev]);
  };

  // Groups
  const joinGroup = (groupId: string) => {
    setGroups((prev) =>
      prev.map((g) =>
        g.id === groupId
          ? { ...g, isJoined: true, membersCount: g.membersCount + 1 }
          : g
      )
    );
  };

  const leaveGroup = (groupId: string) => {
    setGroups((prev) =>
      prev.map((g) =>
        g.id === groupId
          ? { ...g, isJoined: false, membersCount: Math.max(1, g.membersCount - 1) }
          : g
      )
    );
  };

  const handleGroupJoinRequest = (groupId: string, requestId: string, accept: boolean) => {
    setGroups((prev) =>
      prev.map((g) => {
        if (g.id !== groupId) return g;
        return {
          ...g,
          membersCount: accept ? g.membersCount + 1 : g.membersCount,
          joinRequests: g.joinRequests.filter((r) => r.id !== requestId),
        };
      })
    );
  };

  // Calling
  const startCall = (partner: User, type: 'audio' | 'video') => {
    setActiveCall({
      active: true,
      type,
      partnerId: partner.id,
      partnerName: partner.name,
      partnerAvatar: partner.avatar,
      status: 'calling',
      isMuted: false,
      isVideoOff: false,
      startTime: Date.now(),
    });
  };

  const endCall = () => {
    setActiveCall(null);
  };

  const toggleCallMute = () => {
    setActiveCall((prev) => (prev ? { ...prev, isMuted: !prev.isMuted } : null));
  };

  const toggleCallVideo = () => {
    setActiveCall((prev) => (prev ? { ...prev, isVideoOff: !prev.isVideoOff } : null));
  };

  // Messenger
  const sendMessage = (partnerId: string, text: string, mediaUrl?: string) => {
    const newMsg: ChatMessage = {
      id: `msg_${Date.now()}`,
      senderId: currentUser.id,
      text,
      mediaUrl,
      createdAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      isRead: true,
    };

    setChatMessages((prev) => ({
      ...prev,
      [partnerId]: [...(prev[partnerId] || []), newMsg],
    }));

    // Simulate smart friendly auto-reply after 2.5 seconds
    setTimeout(() => {
      const replies = [
        'That sounds wonderful! 👍',
        'Thanks for sharing this with me! 😊',
        'Awesome, let me know when you are free to chat or call! 📞',
        'Haha exactly what I was thinking! 🚀',
        'দারুণ! চলো বিকেলে কথা হবে।',
      ];
      const randomReply = replies[Math.floor(Math.random() * replies.length)];
      const botMsg: ChatMessage = {
        id: `msg_bot_${Date.now()}`,
        senderId: partnerId,
        text: randomReply,
        createdAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        isRead: false,
      };
      setChatMessages((p) => ({
        ...p,
        [partnerId]: [...(p[partnerId] || []), botMsg],
      }));
    }, 2500);
  };

  // Games
  const joinGameRoom = (roomId: string) => {
    setGameRooms((prev) =>
      prev.map((room) =>
        room.id === roomId
          ? {
              ...room,
              playersCount: Math.min(room.maxPlayers, room.playersCount + 1),
              status: room.playersCount + 1 >= room.maxPlayers ? 'in_progress' : 'waiting',
            }
          : room
      )
    );
  };

  // Filter posts to remove blocked users
  const visiblePosts = posts.filter((p) => !blockedUserIds.includes(p.userId));

  return (
    <AppContext.Provider
      value={{
        currentUser,
        setCurrentUser,
        posts: visiblePosts,
        stories: stories.filter((s) => !blockedUserIds.includes(s.userId)),
        reels: reels.filter((r) => !blockedUserIds.includes(r.userId)),
        groups,
        friends: friends.filter((f) => !blockedUserIds.includes(f.id)),
        friendRequests: friendRequests.filter((r) => !blockedUserIds.includes(r.id)),
        notifications,
        blockedUserIds,
        gameRooms,
        theme,
        setTheme,
        toggleTheme,
        language,
        setLanguage,
        activeTab,
        setActiveTab,
        selectedUserId,
        setSelectedUserId,
        selectedGroupId,
        setSelectedGroupId,
        activeReelIndex,
        setActiveReelIndex,
        isLoggedIn,
        googleAccounts,
        isGoogleAuthModalOpen,
        setIsGoogleAuthModalOpen,
        loginWithGoogleAccount,
        signInWithNewGoogleEmail,
        logout,
        isSettingsModalOpen,
        setIsSettingsModalOpen,
        isCreateReelModalOpen,
        setIsCreateReelModalOpen,
        savedPostIds,
        toggleSavePost,
        isPostSaved,
        addPost,
        deletePost,
        togglePostReaction,
        votePoll,
        addComment,
        toggleCommentReaction,
        sharePost,
        addStory,
        reactToStory,
        addReel,
        toggleReelLike,
        sendFriendRequest,
        acceptFriendRequest,
        rejectFriendRequest,
        blockUser,
        unblockUser,
        markNotificationAsRead,
        markAllNotificationsAsRead,
        triggerActivityAlert,
        joinGroup,
        leaveGroup,
        handleGroupJoinRequest,
        activeCall,
        startCall,
        endCall,
        toggleCallMute,
        toggleCallVideo,
        activeChatUser,
        setActiveChatUser,
        chatMessages,
        sendMessage,
        joinGameRoom,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
