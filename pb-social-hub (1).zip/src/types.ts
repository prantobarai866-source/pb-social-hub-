export type ReactionType = 'like' | 'love' | 'care' | 'haha' | 'wow' | 'sad' | 'angry';

export interface User {
  id: string;
  name: string;
  username: string;
  email?: string;
  avatar: string;
  coverPhoto: string;
  bio: string;
  location?: string;
  work?: string;
  education?: string;
  joinedDate: string;
  followersCount: number;
  followingCount: number;
  friendsCount: number;
  isVerified?: boolean;
  isOnline?: boolean;
  authProvider?: 'google' | 'email';
}

export interface GoogleAccount {
  id: string;
  name: string;
  email: string;
  avatar: string;
  isActive?: boolean;
}

export interface CommentReaction {
  userId: string;
  type: ReactionType;
}

export interface PostComment {
  id: string;
  postId: string;
  userId: string;
  userName: string;
  userAvatar: string;
  content: string;
  createdAt: string;
  reactions: Record<ReactionType, number>;
  userReaction?: ReactionType;
  likesCount: number;
}

export interface PostReaction {
  userId: string;
  type: ReactionType;
}

export interface PollOption {
  id: string;
  text: string;
  votes: number;
  voters: string[];
}

export interface PostPoll {
  question: string;
  options: PollOption[];
  totalVotes: number;
  userVotedOptionId?: string;
  expiresAt?: string;
}

export interface Post {
  id: string;
  userId: string;
  userName: string;
  userAvatar: string;
  userVerified?: boolean;
  content: string;
  mediaUrl?: string;
  mediaType?: 'image' | 'video';
  createdAt: string;
  privacy: 'public' | 'friends' | 'only_me';
  reactions: Record<ReactionType, number>;
  userReaction?: ReactionType;
  commentsCount: number;
  comments: PostComment[];
  sharesCount: number;
  groupId?: string;
  groupName?: string;
  isPinned?: boolean;
  poll?: PostPoll;
  scheduledFor?: string;
  isScheduled?: boolean;
  bgGradient?: string;
}

export interface Story {
  id: string;
  userId: string;
  userName: string;
  userAvatar: string;
  mediaUrl: string;
  mediaType: 'image' | 'video';
  duration?: number; // duration in seconds
  caption?: string;
  createdAt: string;
  viewsCount: number;
  reactions: {
    userId: string;
    userName: string;
    emoji: string;
    createdAt: string;
  }[];
}

export interface Reel {
  id: string;
  userId: string;
  userName: string;
  userAvatar: string;
  videoUrl: string;
  thumbnailUrl?: string;
  caption: string;
  audioTrack: string;
  likesCount: number;
  commentsCount: number;
  sharesCount: number;
  viewsCount: number;
  isLiked?: boolean;
  createdAt: string;
  watchTimeSeconds?: number;
}

export interface NotificationItem {
  id: string;
  userId: string; // recipient
  senderId: string;
  senderName: string;
  senderAvatar: string;
  type: 'like_post' | 'comment_post' | 'react_comment' | 'react_story' | 'friend_request' | 'friend_accept' | 'share_post' | 'system';
  text: string;
  targetId?: string; // postId, storyId, etc.
  createdAt: string;
  isRead: boolean;
  reactionEmoji?: string;
}

export interface Group {
  id: string;
  name: string;
  coverImage: string;
  icon: string;
  description: string;
  privacy: 'public' | 'private';
  membersCount: number;
  isJoined: boolean;
  isAdmin?: boolean;
  category: string;
  joinRequests: {
    id: string;
    userId: string;
    userName: string;
    userAvatar: string;
    requestedAt: string;
  }[];
}

export interface ChatMessage {
  id: string;
  senderId: string;
  text: string;
  mediaUrl?: string;
  mediaType?: 'image' | 'audio';
  createdAt: string;
  isRead: boolean;
}

export interface ChatThread {
  id: string;
  participantId: string;
  messages: ChatMessage[];
  lastMessageAt: string;
}

export interface ActiveCall {
  active: boolean;
  type: 'audio' | 'video';
  partnerId: string;
  partnerName: string;
  partnerAvatar: string;
  status: 'calling' | 'connected' | 'ended';
  isMuted: boolean;
  isVideoOff: boolean;
  startTime?: number;
}

export interface GameRoom {
  id: string;
  title: string;
  gameType: 'tictactoe' | 'memory' | 'speed';
  playersCount: number;
  maxPlayers: number;
  hostName: string;
  status: 'waiting' | 'in_progress';
}
