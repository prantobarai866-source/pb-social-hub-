# PB Social Hub Web

Clean web conversion/prototype of the PB Social Hub concept.

### Included
- Facebook-style feed layout
- Text posts
- Image/video attachment
- Delete post
- Refresh-safe browser storage
- PWA manifest
- GitHub Actions workflow for GitHub Pages

### Production note
Browser localStorage is not a server database. To make posts permanent across devices/users, add authentication, a backend API, a database, and media storage.
