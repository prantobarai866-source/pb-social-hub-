const KEY="pb_social_hub_posts_v2";
const $=id=>document.getElementById(id);
let posts=read();
let selected=null;

function read(){try{return JSON.parse(localStorage.getItem(KEY)||"[]")}catch{return[]}}
function write(){localStorage.setItem(KEY,JSON.stringify(posts))}
function esc(v){return String(v).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]))}
function when(ts){return new Date(ts).toLocaleString("bn-BD")}
function id(){return crypto.randomUUID?crypto.randomUUID():Date.now()+"-"+Math.random()}

function render(){
  const feed=$("feed");
  if(!posts.length){feed.innerHTML='<section class="card empty">এখনও কোনো পোস্ট নেই। প্রথম পোস্টটি আপনি করুন।</section>';return}
  feed.innerHTML=posts.map(p=>`
    <article class="card post">
      <div class="post-head"><div class="avatar">PB</div><div><div class="post-name">PB Social Hub</div><div class="post-time">${esc(when(p.createdAt))}</div></div></div>
      ${p.text?`<div class="post-text">${esc(p.text)}</div>`:""}
      ${p.media?(p.mediaType.startsWith("video/")?`<video class="post-media" controls src="${p.media}"></video>`:`<img class="post-media" src="${p.media}" alt="Post image">`):""}
      <div class="post-footer"><button class="ghost danger" onclick="removePost('${p.id}')">পোস্ট মুছুন</button></div>
    </article>`).join("")
}
window.removePost=function(pid){posts=posts.filter(p=>p.id!==pid);write();render()}

$("file").addEventListener("change",()=>{
  selected=$("file").files[0]||null;
  $("fileName").textContent=selected?selected.name:"কোনো ফাইল নেই";
  $("preview").classList.add("hidden");$("preview").innerHTML="";
  if(selected){
    const url=URL.createObjectURL(selected);
    $("preview").innerHTML=selected.type.startsWith("video/")?`<video controls src="${url}"></video>`:`<img src="${url}" alt="Preview">`;
    $("preview").classList.remove("hidden");
  }
});

$("publish").addEventListener("click",async()=>{
  const text=$("text").value.trim();
  if(!text&&!selected){alert("পোস্টে লেখা বা ছবি/ভিডিও দিন।");return}
  let media=null;
  if(selected){
    media=await new Promise((resolve,reject)=>{const r=new FileReader();r.onload=()=>resolve(r.result);r.onerror=reject;r.readAsDataURL(selected)})
  }
  const post={id:id(),text,media,mediaType:selected?.type||"",createdAt:Date.now()};
  posts.unshift(post);
  try{write()}catch(e){posts.shift();alert("Storage সীমা পূর্ণ হয়েছে। বড় মিডিয়ার জন্য server storage প্রয়োজন।");return}
  $("text").value="";$("file").value="";selected=null;$("fileName").textContent="কোনো ফাইল নেই";$("preview").classList.add("hidden");$("preview").innerHTML="";
  render();
});

$("clearAll").addEventListener("click",()=>{if(posts.length&&confirm("সব পোস্ট মুছে ফেলবেন?")){posts=[];write();render()}});
render();
